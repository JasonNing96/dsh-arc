import type { Context } from '@deepseek-ai/cordis';
import { Config, type AcpConfig } from '@deepseek-ai/dsh-acp';
import './index.js';
export { Config };
export declare const name = "arc-acp";
export declare const inject: string[];
export declare function apply(ctx: Context, config: AcpConfig): void;

/** In-process capability. Wire callers must authorize access before invoking it. */
import { Context, Service } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { SessionId } from '@deepseek-ai/dsh-session';
import { type Checkpoint } from './checkpoint.js';
export { type Checkpoint } from './checkpoint.js';
export declare const name = "arc-runtime";
export declare const inject: string[];
export interface StagedSession {
    sessionId: SessionId;
    cwd: string;
}
/** Stable public seam for the experimental checkpoint capability, not a transport. */
export interface ArcRuntimeApi {
    inspect(): {
        version: 1;
        capabilities: readonly ['checkpoint-export', 'checkpoint-stage'];
    };
    exportCheckpoint(agent: Agent, signal?: AbortSignal): Promise<Checkpoint>;
    stageCheckpoint(checkpoint: unknown, cwd: string, signal?: AbortSignal): Promise<StagedSession>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        arc: ArcRuntimeApi;
    }
}
export declare class ArcRuntime extends Service implements ArcRuntimeApi {
    private readonly state;
    constructor(ctx: Context);
    inspect(): ReturnType<ArcRuntimeApi['inspect']>;
    private assertOpen;
    private track;
    exportCheckpoint(agent: Agent, signal?: AbortSignal): Promise<Checkpoint>;
    /** Create a durable cold session; a surface owns its subsequent resume and drive. */
    stageCheckpoint(checkpoint: unknown, cwd: string, signal?: AbortSignal): Promise<StagedSession>;
}
export declare function apply(ctx: Context): void;

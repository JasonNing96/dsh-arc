/** Optional consumer of ARC and public human-command / TUI status capabilities. */
import type { Context } from '@deepseek-ai/cordis';
import './index.js';
export declare const name = "arc-tui";
export declare const inject: string[];
export declare function apply(ctx: Context): void;

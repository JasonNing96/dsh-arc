# dsh-arc — optional DSH plugin

ARC 的可选运行时能力包，使用官方 Cordis / Bundle / Profile 机制。当前版本 `1.0.0`，通过 `@jasonning/dsh-arc` 分发。验收基线与证据见 [插件拔插和 TUI 组合验收](../../docs/research/dsh-arc-plugin-acceptance-2026-09-15.md)。

## 包含什么

- `dsh-arc`：通过 `ctx.arc` 提供检查点导出和持久化导入，不依赖 TUI。
- `dsh-arc/checkpoint`：当前 MVP 的上下文校验与原生事件 seed 编解码。
- `dsh-arc/acp`：可选终端适配层。组合官方 ACP 的公开 `Stream` 入口，增加既有 `_dsh/checkpoint`、`_dsh/stream` 和检查点新会话请求；不读取或改写上游源码。
- `dsh-arc/tui`：可选工作台消费者，通过公开 `commands` 服务注册 `/arc status`、`/arc checkpoint`；存在 `tuiStatus` 时显示状态栏。

这些模块通过三个标准 Bundle 组装：`dsh-arc` 启用核心服务，`dsh-arc-acp` 启用 ACP 集成，`dsh-arc-tui` 启用命令和可选状态栏。后两个包仅包含配置，不复制核心实现，可以分别卸载。

导入先创建并落盘一个冷会话，释放写锁，再由原版 ACP 的 `session/resume` 接管。原版 ACP 继续管理模型选择、MCP、权限、取消和会话生命周期。普通工具插件无需依赖 ARC。

## 逻辑连线与 TUI 组装

以下是两种消费者接入同一种 ARC 核心服务的关系。原版 TUI 的命令通路位于同一个 DSH 进程；完整投切通路通过 ACP 连接独立 runtime，每个执行端各有自己的核心实例。

```mermaid
flowchart TB
  T["原版社区 TUI"] -->|"公开 commands 接口"| U["dsh-arc-tui：命令 / 可选状态栏"]
  U -->|"进程内调用"| A["dsh-arc：ctx.arc"]
  W["本项目 TUI + ARC 控制器"] -->|"本地 stdio 或 SSH / ACP"| P["dsh-arc-acp：协议集成"]
  P -->|"检查点请求"| A
  A --> D["DSH Agent / Session / Persistence"]
```

| 目标 | 组装方式 |
|---|---|
| 原版 TUI 使用 ARC 命令/状态 | 同一 Profile 安装社区 TUI、`dsh-arc`、`dsh-arc-tui`；用原版 `dsh --profile` 启动 |
| 同一对话跨本机/服务器投切 | 两端各装 `dsh-arc` + `dsh-arc-acp`；本项目 TUI 通过 ARC 控制器连接两端 |

完整的进程边界图、投切时序图、Profile 配置、安装命令和卸载步骤见 **[ARC × TUI 逻辑连线与组装指南](../../docs/arc-tui-assembly.md)**。原版 TUI 的公开接口组合与已有完整投切入口分别说明。

## 本地构建与验证

从 personal-dsh 仓库根目录执行：

```sh
npm --prefix plugins/dsh-arc ci --ignore-scripts
npm --prefix plugins/dsh-arc test
npm --prefix tui test
node tools/arc-plugin-smoke.mjs /tmp/arc-bundle-result.json
# Python 环境需安装 pyte；--tui-package 指向已安装的原版社区 TUI 包目录。
python tools/arc-native-tui-smoke.py \
  --tui-package /absolute/path/to/node_modules/@deepseek-harness-tui/dsh-tui \
  --output /tmp/arc-native-tui-result
```

第一项烟测在临时 DSH_HOME 安装 tarball，用两个独立进程验证现有 TUI 控制器的往返接力、流式输出、Home、草稿、重启恢复及卸载后标准 ACP 恢复已有会话。第二项在真实 PTY 中启动原版社区 TUI，验证命令、状态栏、实际检查点导出和两层卸载；前后校验上游源码哈希。模型均为本地确定性测试适配器，无外部模型请求，结束后清理临时运行目录。

## 安装到工作台

仅安装运行时服务，可使用标准命令：

```sh
npm pack ./plugins/dsh-arc --pack-destination ./plugins/dsh-arc
# 在目标 DSH_HOME 下：
dsh plugin --profile your-profile add ./plugins/dsh-arc/dsh-arc-0.1.0-experimental.1.tgz
```

给本项目 TUI 创建插件专用 ACP Profile，可运行安装助手：

```sh
node tools/install-arc-plugin.mjs \
  --dsh-home /absolute/path/to/runtime-home \
  --provider YOUR_EXISTING_PROVIDER_ROUTE \
  --model glm-5.3-flash \
  --profile arc-acp
```

`provider` 必须使用目标 runtime 已配置的路由名称。助手创建新 Profile，安装 `dsh-arc` 和 `dsh-arc-acp`，只在 Profile 补丁配置原 `acp` 的 provider/model。它拒绝覆盖同名 Profile，不复制密钥，也不修改原 `acp` Profile。两个构建包按内容哈希保存在目标 DSH_HOME 的 `artifacts/dsh-arc/` 中，后续重装不会依赖已经删除的临时文件。目标 DSH_HOME 的机器级补丁仍按官方优先级生效。

```sh
npm --prefix tui run start -- \
  --dsh-home /absolute/path/to/runtime-home \
  --arc-profile arc-acp
```

这个启动方式不加载 `runtime-hook.js`，且初始化必须确认 `dshArcPlugin: 1`。省略 `--arc-profile` 仍使用旧入口，便于分阶段迁移。

服务器上同样安装后，在已有远程 JSON 配置增加 `"arcProfile": "arc-acp"`。SSH 启动会选择该 Profile 并省去旧 `--import` 参数。当前自动验收用本机两个进程模拟两个执行端；本轮没有部署服务器或验证实际 SSH 网络。

### 与原版社区 TUI 组合

在已经包含 `@deepseek-harness-tui/dsh-tui` 的 Profile 中，添加核心及 TUI 集成 Bundle：

```sh
npm pack ./plugins/dsh-arc-tui --pack-destination ./plugins/dsh-arc-tui
dsh plugin --profile your-tui-profile add \
  ./plugins/dsh-arc/dsh-arc-0.1.0-experimental.1.tgz \
  ./plugins/dsh-arc-tui/dsh-arc-tui-0.1.0-experimental.1.tgz
dsh --profile your-tui-profile
```

原版 TUI 出现 `ARC ready` 状态栏。输入 `/arc status` 查看能力；输入 `/arc checkpoint` 导出当前空闲会话并显示消息数、字节数与 SHA256，不显示正文，不写出检查点文件，也不调用模型。命令生命周期由 DSH 记录，不进入模型消息。只依赖公共 commands 服务的其他工作台同样可消费该命令；状态栏是可选能力。

这条入口未修改 TUI 源码，未加载本项目 `community/loader.mjs`。**原版 TUI 的 Ctrl+R 仍是历史搜索**；完整跨端投切目前使用上面的 ACP 入口及本项目工作台控制器。

### 卸载与恢复

退出目标运行实例后，按所在 Profile 执行相应命令并重新启动：

```sh
# ACP Profile：恢复原 ACP 条目，保留其模型配置和原生会话。
dsh plugin --profile arc-acp remove dsh-arc-acp
# 社区 TUI Profile：撤销 ARC 命令/状态栏，保留 TUI 和核心服务。
dsh plugin --profile your-tui-profile remove dsh-arc-tui
# 不再有 ARC 消费者时，移除该 Profile 中的核心服务。
dsh plugin --profile your-profile remove dsh-arc
```

集成配置由 Bundle 自己拥有，无需手工删除 ARC 的 Profile 补丁行。各 Profile 是独立组合；先移除该 Profile 内依赖 ARC 的集成 Bundle，再移除核心。标准 CLI 安装/卸载验收以重启生效为准，进程内服务与命令的撤销/重新加载另有生命周期测试。

## 服务接口

消费者声明 `inject: ['arc']` 后，可以使用：

```ts
ctx.arc.inspect()
await ctx.arc.exportCheckpoint(authorizedLiveAgent, signal)
const staged = await ctx.arc.stageCheckpoint(checkpoint, targetCwd, signal)
// staged.sessionId 已持久化且不占用 live Agent / 写锁；由调用方的 surface 恢复它。
```

这是可信进程内接口，不是对任意会话的远程授权。网络或界面适配层必须先确认调用者可访问该会话；ACP 层只允许导出本连接拥有的 Agent，并拒绝回合运行期间的导出。

## 当前边界

- 固定兼容基线：Cordis `4.0.2`；DSH ACP / Agent / Session 等 `0.1.5-rc.2`；验证用 CLI 为 `0.1.5-rc.1`、Node `26.5.0`。尚未承诺其他版本兼容。
- 只支持空闲检查点。当前消息面、完整工具调用/结果可携带；文件、附件、权限、凭据和待办输入不会自动迁移。上限 2 MiB。
- 逻辑会话、Home 和草稿仍由现有工作台控制器持久化，runtime 插件负责导入导出。不能把“安装 runtime 插件”等同于“任意 UI 自动出现投切按钮”。
- 原版社区 TUI 的命令/状态集成无源码补丁。既有 `--ui community` 完整投切入口仍保留界面加载适配，不等同于这里的原版 TUI 组合入口。
- 冷会话落盘后若连接断开或后续 ACP 恢复失败，可能留下未被工作台采用的会话记录。源端不会因此被撤销；当前公开持久化接口没有提供通用删除操作，本插件不直接操作底层文件删除它。
- `Stream` 参数是公开导出的组合入口，但上游把它描述为运行时传输覆盖，仍需固定版本验证。此次未引入 Typert Remote：当前产品已有 ACP 流式客户端；其他 UI 可另行选择 Remote 适配层。

从旧 `experimental.0` 安装助手创建的 Profile 升级时，建议创建新的 `.1` Profile。旧版手写的 `arc-acp`/`acp.disabled` 补丁不会因为安装新 Bundle 自动消失；本版助手仍拒绝覆盖旧 Profile。

import React from 'react';
import type { ChannelUi as Channel } from '../adapter/channel/ui-policy.js';
import type { WaveBand } from '../dsh-adapter/types.js';
export declare function StatusLine({ channel, selectionActive, helpOpen, wake, }: {
    channel: Channel;
    selectionActive?: boolean;
    helpOpen?: boolean;
    /**
     * The session projected onto the status line's few columns, plus the
     * animation tick and the self-retiring key hint.
     *
     * A strip that shows the session's shape keeps earning its space in a way a
     * static label cannot, and it carries the failure signal in position rather
     * than as a count in the corner. Absent in headless embeds, where nothing
     * folds the event log.
     */
    wake?: {
        band: WaveBand;
        hint?: string;
        tick: number;
    };
}): React.JSX.Element;
type UsageSnapshot = {
    input: number;
    cacheRead: number;
    cacheWrite: number;
};
/** Return the prompt-cache hit rate, or nothing when usage is unavailable. */
export declare function formatCacheHitRate(usage: UsageSnapshot | undefined): string | undefined;
export {};
//# sourceMappingURL=StatusLine.d.ts.map
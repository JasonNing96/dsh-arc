import React from 'react';
import type { ChannelUi as Channel } from '../adapter/channel/ui-policy.js';
import type { QuestionStore } from '../dsh-adapter/questions.js';
import { TuiDialogStore } from '../dsh-adapter/dialogs.js';
import { TuiStatusStore } from '../dsh-adapter/status.js';
import type { TuiShortcutHost } from '../dsh-adapter/shortcuts.js';
import type { TuiThemeHost } from '../dsh-adapter/themes.js';
import { ApprovalStore } from '../dsh-adapter/approvals.js';
import type { InjectController } from '../dsh-adapter/inject-channel.js';
export declare function Chat({ channel, questionStore, approvalStore, extensionDialogs, extensionStatus, extensionShortcuts, themeHost, onExit, onUpdate, onRestart, fullscreen, trajectorySeen: trajectorySeenProp, injectControllerRef, renderScene, }: {
    channel: Channel;
    renderScene?: (id: string, channel: Channel) => React.ReactNode;
    questionStore: QuestionStore;
    /**
     * The approval seam's UI store. Optional: hosts without an approval
     * channel (headless scripts, older embeds) render Chat without it and
     * simply never see an approval panel — the question panel keeps its seat.
     */
    approvalStore?: ApprovalStore;
    /**
     * The managed plugin dialog queue (tuiDialogs service's store). Optional
     * for the same hosts as approvalStore; absent, plugin dialog requests
     * park unanswered (their `timeoutMs` is the plugin's guard).
     */
    extensionDialogs?: TuiDialogStore;
    /** Plugin text and bounded rich status contributions. */
    extensionStatus?: TuiStatusStore;
    /** Host-only keyboard shortcut dispatch path. */
    extensionShortcuts?: TuiShortcutHost;
    /** Optional runtime theme host; static JSON themes work without it. */
    themeHost?: TuiThemeHost;
    onExit: () => void;
    /** Update the installed package and restart the current TUI process. */
    onUpdate?: () => void;
    /** Restart the current TUI process and resume this session (no update). */
    onRestart?: () => void;
    /**
     * True when the host already wrapped this tree in `<AlternateScreen>`
     * (`fullscreen: true`). Both full-screen surfaces need this — the trajectory
     * scene and the session browser: entering the alt
     * screen a second time is harmless, but the inner unmount's DEC 1049 exit
     * would drop the whole app back to the main screen.
     */
    fullscreen?: boolean;
    /**
     * Whether the trajectory has been opened before on this machine.
     *
     * A prop rather than a filesystem read inside the component: a render
     * initializer touching disk is the wrong layer, and hosts that already know
     * (or tests that need determinism) can simply say. Falls back to the
     * persisted flag when the host does not supply one.
     */
    trajectorySeen?: boolean;
    /**
     * External injection controller (dsh-adapter/inject-channel.ts). When the
     * host runs the injection socket, Chat publishes `{ append, submit }` into
     * this ref every render so the adapter-owned socket drives the prompt input
     * without reaching into React state directly. Absent for hosts that do not
     * open the channel (headless scripts, bare embeds).
     */
    injectControllerRef?: React.RefObject<InjectController | null>;
}): React.JSX.Element | null;
//# sourceMappingURL=Chat.d.ts.map
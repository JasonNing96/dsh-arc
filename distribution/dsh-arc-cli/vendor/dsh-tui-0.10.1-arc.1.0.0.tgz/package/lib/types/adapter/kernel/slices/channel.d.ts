import type { KernelSlice } from './types.js';
export declare const channelSlice: KernelSlice;
//# sourceMappingURL=channel.d.ts.map
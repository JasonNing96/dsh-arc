import type { KernelSlice } from './types.js';
export declare const statusSlice: KernelSlice;
export declare const shortcutsSlice: KernelSlice;
export declare const renderersSlice: KernelSlice;
export declare const themesSlice: KernelSlice;
export declare const toastSlice: KernelSlice;
export declare const commandTreesSlice: KernelSlice;
//# sourceMappingURL=extensions.d.ts.map
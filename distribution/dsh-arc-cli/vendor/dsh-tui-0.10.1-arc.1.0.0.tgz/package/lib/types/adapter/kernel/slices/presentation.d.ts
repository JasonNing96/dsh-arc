import type { KernelSlice } from './types.js';
export declare const presentationSlice: KernelSlice;
//# sourceMappingURL=presentation.d.ts.map
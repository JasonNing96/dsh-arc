import type { KernelSlice } from './types.js';
export declare const decisionsSlice: KernelSlice;
//# sourceMappingURL=decisions.d.ts.map
export { name, TuiSceneRuntime } from './dsh-adapter/scenes.js';
export type { TuiSceneProps, TuiSceneDescriptor } from './dsh-adapter/scenes.js';
export { default } from './dsh-adapter/scenes.js';
//# sourceMappingURL=scenes.d.ts.map
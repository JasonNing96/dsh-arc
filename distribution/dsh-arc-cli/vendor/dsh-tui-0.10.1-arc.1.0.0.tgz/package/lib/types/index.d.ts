import './force-production-react.js';
export * from './dsh-adapter/index.js';
//# sourceMappingURL=index.d.ts.map
/**
 * dsh-tui color themes — Gentle Mist Blue (雾蓝) family.
 *
 * Two truecolor palettes share one identity: mist blues carry brand, focus,
 * and interaction; body text stays neutral. `light` uses white panel
 * surfaces (#FFFFFF) and ink text (#343945) for
 * light terminals; `dark` is its dark-terminal adaptation (warm off-white
 * text, accent-soft blues). `dark-ansi` is the 16-color fallback for
 * terminals without truecolor. The active palette is chosen at startup by
 * querying the terminal background (OSC 11) — see ThemeProvider.
 *
 * `auto` is a pseudo-theme, not a palette: it resolves to `light` or `dark`
 * from the terminal background detected via OSC 11 (which tracks the system
 * theme in terminals that follow it). ThemeProvider re-runs detection every
 * time `auto` is selected and pushes the result through setAutoThemeBase(),
 * so getTheme('auto') always serves the currently detected palette.
 */
export type Theme = {
    autoAccept: string;
    bashBorder: string;
    /** Primary brand/focus color. */
    accent: string;
    toolNameMutate: string;
    toolNameExec: string;
    /** Primary brand/focus shimmer color. */
    accentShimmer: string;
    /** Working activity indicator color. */
    activity: string;
    /** Working activity indicator shimmer color. */
    activityShimmer: string;
    permission: string;
    permissionShimmer: string;
    planMode: string;
    ide: string;
    promptBorder: string;
    promptBorderShimmer: string;
    text: string;
    inverseText: string;
    inactive: string;
    inactiveShimmer: string;
    subtle: string;
    suggestion: string;
    remember: string;
    background: string;
    success: string;
    error: string;
    warning: string;
    merged: string;
    warningShimmer: string;
    diffAdded: string;
    diffRemoved: string;
    diffAddedDimmed: string;
    diffRemovedDimmed: string;
    diffAddedWord: string;
    diffRemovedWord: string;
    toolCardBackground: string;
    toolCardBackgroundDim: string;
    toolDotExec: string;
    toolDotRead: string;
    toolDotWrite: string;
    toolDotWeb: string;
    toolDotTask: string;
    syntaxKeyword: string;
    syntaxString: string;
    syntaxComment: string;
    syntaxNumber: string;
    syntaxFunction: string;
    syntaxType: string;
    syntaxVariable: string;
    syntaxOperator: string;
    syntaxPunctuation: string;
    syntaxConstant: string;
    professionalBlue: string;
    chromeYellow: string;
    /** Mascot body color. */
    mascotBody: string;
    /** Input/editor background color. */
    inputBackground: string;
    userMessageBackground: string;
    userMessageBackgroundHover: string;
    messageActionsBackground: string;
    selectionBg: string;
    bashMessageBackgroundColor: string;
    memoryBackgroundColor: string;
    rate_limit_fill: string;
    rate_limit_empty: string;
    fastMode: string;
    fastModeShimmer: string;
    userPromptLabel: string;
    subagentBullet: string;
    subagentDescription: string;
    subagentModel: string;
    subagentElapsed: string;
    subagentToolName: string;
    subagentStatusRunning: string;
    subagentStatusCompleted: string;
    subagentStatusFailed: string;
};
/**
 * Theme keys used by pre-semantic theme files and plugin descriptors.
 * Keep this input compatibility surface separate from the resolved Theme
 * contract: palettes exposed to consumers contain semantic keys only.
 */
export type DeprecatedThemeKey = 'claude' | 'claudeShimmer' | 'claudeBlue_FOR_SYSTEM_SPINNER' | 'claudeBlueShimmer_FOR_SYSTEM_SPINNER' | 'clawd_body' | 'clawd_background' | 'briefLabelYou';
declare const RETIRED_THEME_KEYS: readonly ["briefLabelClaude", "red_FOR_SUBAGENTS_ONLY", "blue_FOR_SUBAGENTS_ONLY", "green_FOR_SUBAGENTS_ONLY", "yellow_FOR_SUBAGENTS_ONLY", "purple_FOR_SUBAGENTS_ONLY", "orange_FOR_SUBAGENTS_ONLY", "pink_FOR_SUBAGENTS_ONLY", "cyan_FOR_SUBAGENTS_ONLY", "rainbow_red", "rainbow_red_shimmer", "rainbow_orange", "rainbow_orange_shimmer", "rainbow_yellow", "rainbow_yellow_shimmer", "rainbow_green", "rainbow_green_shimmer", "rainbow_blue", "rainbow_blue_shimmer", "rainbow_indigo", "rainbow_indigo_shimmer", "rainbow_violet", "rainbow_violet_shimmer"];
export type RetiredThemeKey = (typeof RETIRED_THEME_KEYS)[number];
/** Obsolete, unused palette slots are accepted only at input boundaries. */
export declare function isRetiredThemeKey(value: string): value is RetiredThemeKey;
export type ThemeColorKey = keyof Theme | DeprecatedThemeKey | RetiredThemeKey;
export declare const DEPRECATED_THEME_KEY_ALIASES: Readonly<Record<DeprecatedThemeKey, keyof Theme>>;
/** Convert a legacy persisted/plugin key to its semantic key. */
export declare function normalizeThemeKey(value: string): keyof Theme | undefined;
/** Whether a key is accepted at a theme input boundary, including aliases. */
export declare function isThemeColorKey(value: unknown): value is ThemeColorKey;
/** The built-in theme names, in display order. */
export declare const THEME_NAMES: readonly ["dark", "dark-ansi", "light"];
/**
 * The `auto` pseudo-theme: not a palette, but a standing request to follow
 * the terminal background (OSC 11, which tracks the system theme in
 * terminals that follow it). Selectable everywhere a theme name is
 * (/theme, DSH_TUI_THEME, ~/.dsh-tui/theme.json); getTheme() resolves it to
 * the last detected `light`/`dark` palette via the auto base below.
 */
export declare const AUTO_THEME_NAME = "auto";
/**
 * Record the palette `auto` should resolve to. Called by ThemeProvider
 * after each terminal-background detection while `auto` is active.
 * @param name - The detected base palette.
 */
export declare function setAutoThemeBase(name: 'light' | 'dark'): void;
/** The palette `auto` currently resolves to (`light` or `dark`). */
export declare function getAutoThemeBase(): 'light' | 'dark';
/**
 * Any theme name: a built-in palette (`light`/`dark`/`dark-ansi`), a user
 * theme from ~/.dsh-tui/themes/<name>.json, or a host runtime contribution.
 * Always resolvable to a concrete color palette via getTheme() (unknown names
 * fall back to `dark`).
 */
export type ThemeName = string;
/**
 * Normalize a palette returned by an older resolver or plugin. Resolvers are
 * process-local extension points, so an already loaded plugin may still
 * return the pre-semantic keys after this package has been upgraded. Canonical
 * keys win when both forms are present; aliases are removed from the resolved
 * palette so every consumer sees one stable Theme shape.
 */
export declare function normalizeThemePalette(value: unknown): Theme | undefined;
/**
 * Resolve a theme name to its concrete color palette.
 * @param themeName - The theme to resolve (built-in, `auto`, or user theme
 *   name).
 * @returns The matching palette; `auto` resolves to the detected base
 *   (light/dark), unknown names fall back to `dark`.
 */
export declare function getTheme(themeName: ThemeName): Theme;
/** A resolver for a fully built palette. Undefined means “not mine”. */
export type ThemeResolver = (name: string) => Theme | undefined;
/**
 * Whether the active theme's RESOLVED palette renders on a light background.
 * Keyed off the resolved palette's IDENTITY for the built-ins (auto resolves
 * to the shared light/dark instance, so this covers auto-with-light-terminal
 * that theme-NAME comparisons miss) and off the ink-text luminance for
 * custom and runtime themes (light palettes pair with dark ink). The palette's
 * `background` field is a badge fill, not the terminal background — never a
 * lightness signal. Colour-pair variants (effort ignition hues) consume this.
 */
export declare function isLightThemeActive(themeName: ThemeName): boolean;
/**
 * Register the custom-theme resolver. Called once by ThemeProvider; the
 * resolver must return `undefined` for names it does not know so getTheme
 * falls back to `dark`.
 * @param resolver - Resolves a user theme name to a built palette.
 */
export declare function registerCustomThemeResolver(resolver: ThemeResolver): void;
/**
 * Register the host runtime resolver. The returned cleanup is generation-safe:
 * disposing an older registration cannot clear a resolver installed later;
 * nested registrations restore the previous live resolver when they leave.
 */
export declare function registerRuntimeThemeResolver(resolver: ThemeResolver): () => void;
/** Clear all runtime resolvers, primarily for isolated host teardown/tests. */
export declare function clearRuntimeThemeResolver(): void;
/**
 * Whether a name resolves through the built-ins, static custom resolver, or
 * the optional runtime resolver. This deliberately remains separate from
 * customTheme.isThemeAvailable(), whose contract is static-file-only.
 */
export declare function isThemeAvailable(themeName: ThemeName): boolean;
/**
 * Set the module-level active theme; ThemeProvider calls this once
 * background detection settles and on every runtime theme switch.
 * @param name - The theme to activate.
 */
export declare function setActiveThemeName(name: ThemeName): void;
/**
 * Resolve the currently active theme for non-React rendering.
 * @returns The palette of the module-level active theme.
 */
export declare function getActiveTheme(): Theme;
export {};
//# sourceMappingURL=theme.d.ts.map
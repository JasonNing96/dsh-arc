import React from 'react';
export type Props = {
    readonly count?: number;
};
/** Insert line separators inside a text container. */
export default function Newline({ count }: Props): React.JSX.Element;
//# sourceMappingURL=Newline.d.ts.map
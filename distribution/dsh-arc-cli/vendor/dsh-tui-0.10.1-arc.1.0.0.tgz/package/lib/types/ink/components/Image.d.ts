import React, { type ReactNode } from 'react';
import type { TerminalImageSource } from '../terminal-image.js';
export interface ImageProps {
    /**
     * Decoded immutable RGBA snapshot. Allocate a new buffer when pixels change;
     * invalid or oversized sources use the fallback.
     */
    readonly source?: TerminalImageSource;
    /** Width reserved in terminal columns. */
    readonly width: number;
    /** Height reserved in terminal rows. */
    readonly height: number;
    /** Text alternative. Use an empty string for a decorative image. */
    readonly alt: string;
    /** Opt into Sixel for a modal or scrollable transcript. Default keeps Kitty only. */
    readonly presentation?: 'preview' | 'transcript';
    /** Same-size terminal-cell fallback rendered when graphics are unavailable. */
    readonly children?: ReactNode;
}
/**
 * A renderer-owned terminal image with a deterministic cell fallback.
 *
 * The component never emits protocol bytes itself. It contributes a normal
 * Yoga leaf; the Ink host decides after layout whether to paint its fallback
 * children or attach a terminal-graphics placement over the same cells.
 */
export default function Image({ source, width, height, alt, presentation, children, }: ImageProps): React.ReactNode;
//# sourceMappingURL=Image.d.ts.map
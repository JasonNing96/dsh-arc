import { type TerminalCellSize, type TerminalImagePlacement, type TerminalImageSource } from './terminal-image.js';
export interface KittyGraphicsManagerOptions {
    /** Deterministic seed used by protocol tests; production chooses a random range. */
    readonly firstImageId?: number;
    /** Physical pixels per cell; defaults to a conventional 8×16 cell. */
    readonly cellSize?: TerminalCellSize;
}
/**
 * Reconcile renderer image requests with Kitty image/placement state.
 *
 * Pixel content owns an image id while each DOM node owns a placement id.
 * Equal immutable RGBA content is uploaded once and can back several nodes;
 * geometry changes replace only that node's placement without flicker.
 */
export declare class KittyGraphicsManager {
    private readonly images;
    private readonly placements;
    private readonly contentHashes;
    private nextImageId;
    private nextPlacementId;
    private cellSize;
    constructor(options?: KittyGraphicsManagerOptions);
    /** Update the physical cell ratio used by future image variants. */
    setCellSize(cellSize: TerminalCellSize): boolean;
    reconcile(placements: readonly TerminalImagePlacement[]): string;
    /** A clear/screen swap invalidated terminal-side data; resend next frame. */
    invalidateAll(): void;
    /** Delete every image owned by this renderer and forget their ids. */
    deleteAll(): string;
    private imageFor;
    private contentHash;
    private allocateImageId;
    private allocatePlacementId;
}
/** Zlib-compressed direct RGBA split into protocol-compliant base64 chunks. */
export declare function transmitKittyRgba(imageId: number, source: TerminalImageSource): string;
export declare function kittyPlacement(imageId: number, placementId: number, x: number, y: number, columns: number, rows: number, zIndex?: number): string;
export declare function deleteKittyPlacement(imageId: number, placementId: number): string;
export declare function deleteKittyImage(imageId: number): string;
export declare function kittyCommand(control: string, payload?: string): string;
//# sourceMappingURL=kitty-graphics.d.ts.map
import type { TerminalImageSource } from './terminal-image.js';
export interface SixelCrop {
    readonly left: number;
    readonly top: number;
    readonly width: number;
    readonly height: number;
}
export interface SixelEncodeRequest {
    readonly source: TerminalImageSource;
    readonly width: number;
    readonly height: number;
    readonly background: string;
    readonly presentation?: 'preview' | 'transcript';
    readonly crop?: SixelCrop;
}
export interface SixelWorkerRequest {
    readonly assetKey: string;
    readonly request: Omit<SixelEncodeRequest, 'source'> & {
        readonly source?: TerminalImageSource;
    };
}
export interface SixelWorkerResponse {
    readonly raster?: SixelRaster;
    readonly missing?: boolean;
    readonly preparedKeys?: string[];
    readonly quantized?: boolean;
}
export interface SixelRaster {
    readonly width: number;
    readonly height: number;
    readonly data: string;
}
/** CPU-heavy work: called in the image worker, never in the frame painter. */
export declare function encodeSixel(request: SixelEncodeRequest): Promise<SixelRaster>;
/** Worker-local LRU: scrolling reuses resized/quantized pixels, not just sources. */
export declare class SixelEncoderCache {
    private readonly images;
    private bytes;
    render({ assetKey, request }: SixelWorkerRequest): Promise<SixelWorkerResponse>;
}
//# sourceMappingURL=sixel-codec.d.ts.map
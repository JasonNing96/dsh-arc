export {};
//# sourceMappingURL=sixel-worker.d.ts.map
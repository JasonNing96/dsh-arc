import type { SixelEncodeRequest, SixelRaster } from './sixel-codec.js';
import { type TerminalCellSize, type TerminalImagePlacement } from './terminal-image.js';
import { type Screen } from './screen.js';
import type { Diff } from './frame.js';
type Encoder = (request: SixelEncodeRequest) => Promise<SixelRaster>;
/** Viewport-owned pixels. Encoding is shared; placement/erasure is per DOM node. */
export declare class SixelGraphicsManager {
    private readonly onReady;
    private readonly encoder?;
    private cell;
    private readonly ids;
    private nextId;
    private readonly cache;
    private cachedBytes;
    private readyBytes;
    private active;
    private pending;
    private readonly frame;
    private desired;
    private displayed;
    private nextDisplay;
    private readonly repaint;
    private worker;
    private workerKeys;
    private workerReject;
    private disposed;
    private dirty;
    private columns;
    private rows;
    private displayModeSet;
    constructor(onReady: () => void, encoder?: Encoder | undefined);
    get hasImage(): boolean;
    setDisplayMode(enabled: boolean): void;
    setCellSize(cell: TerminalCellSize): boolean;
    beginFrame(columns: number, rows: number): void;
    readonly prepare: (placement: TerminalImagePlacement) => boolean;
    private variant;
    /** Reconcile ALL old rectangles before diffing, with only one baseline copy. */
    reconcile(screen: Screen, previous: Screen, placements?: readonly TerminalImagePlacement[]): {
        erase: string;
        baseline: Screen;
    };
    /** Unchanged images have zero transport cost, including unrelated text ticks. */
    paint(diff: Diff): string;
    invalidateAll(): void;
    clear(): string;
    dispose(): string;
    private erase;
    private isUncovered;
    private textDamage;
    private drain;
    private complete;
    private encodeInWorker;
}
export {};
//# sourceMappingURL=sixel-graphics.d.ts.map
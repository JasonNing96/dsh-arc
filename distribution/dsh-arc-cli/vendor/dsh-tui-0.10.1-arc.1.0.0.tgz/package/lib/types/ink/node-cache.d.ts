import type { DOMElement } from './dom.js';
import type { Rectangle } from './layout/geometry.js';
/**
 * Cached layout bounds for each rendered node (used for blit + clearing).
 * `top` is the yoga-local getComputedTop() — stored so ScrollBox viewport
 * culling can skip yoga reads for clean children whose position hasn't
 * shifted (O(dirty) instead of O(mounted) first-pass).
 */
export type CachedLayout = {
    x: number;
    y: number;
    width: number;
    height: number;
    top?: number;
    /** Effective background color (own ?? inherited) at the last render.
     *  Renderer compares it per frame so a background change refuses the
     *  prevScreen blit — children would otherwise resurrect the stale color
     *  (stuck hover highlight). */
    bg?: string;
    /** Whether the node fills its whole rect (own backgroundColor or
     *  `opaque`). Only such an absolute node "covers" cells a previous
     *  overlay vacated; a transparent one leaves them stale (see
     *  hasOverlayVacatedCells). */
    opaque?: boolean;
};
/** Layout bounds cached per rendered node, used for blitting and clearing. */
export declare const nodeCache: WeakMap<DOMElement, CachedLayout>;
/** Current prepared text only: scrolling changes its position, not its lines.
 * Weak keys release unmounted nodes; mutations discard the previous version. */
export declare const textPaintCache: WeakMap<DOMElement, {
    maxWidth: number;
    background: string | undefined;
    paddingLeft: number;
    paddingTop: number;
    text: string;
    lines: readonly string[];
    softWrap: boolean[] | undefined;
}>;
/** Rects of removed children that need clearing on next render */
export declare const pendingClears: WeakMap<DOMElement, Rectangle[]>;
/**
 * Register a removed child's rect for clearing on the next render, and
 * flag the next frame when the removed node was absolutely positioned.
 * @param parent - the parent whose removed child rect to record.
 * @param rect - the removed child's last known bounds.
 * @param isAbsolute - whether the removed child was absolutely positioned; disables blit next frame.
 */
export declare function addPendingClear(parent: DOMElement, rect: Rectangle, isAbsolute: boolean): void;
/**
 * Read and clear the absolute-removal flag set by addPendingClear.
 * @returns whether an absolutely positioned node was removed since the last render.
 */
export declare function consumeAbsoluteRemovedFlag(): boolean;
//# sourceMappingURL=node-cache.d.ts.map
/** Terminal display cells, including ANSI, emoji and combining marks. */
export declare const stringWidth: (str: string) => number;
//# sourceMappingURL=stringWidth.d.ts.map
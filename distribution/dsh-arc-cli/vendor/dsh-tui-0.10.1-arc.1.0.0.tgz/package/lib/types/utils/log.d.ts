/**
 * Error logger for the renderer. Always writes to stderr so a render failure
 * never passes silently.
 * @param error - The error to log; its stack trace when available.
 */
export declare function logError(error: unknown): void;
//# sourceMappingURL=log.d.ts.map
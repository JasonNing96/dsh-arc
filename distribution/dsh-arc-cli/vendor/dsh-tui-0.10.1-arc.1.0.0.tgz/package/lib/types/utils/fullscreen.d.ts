/**
 * Whether mouse click handling is disabled. dsh-tui reads its own environment
 * flag (`DSH_TUI_DISABLE_MOUSE`) for this decision.
 * @returns True when DSH_TUI_DISABLE_MOUSE is set to a truthy value.
 */
export declare function isMouseClicksDisabled(): boolean;
//# sourceMappingURL=fullscreen.d.ts.map
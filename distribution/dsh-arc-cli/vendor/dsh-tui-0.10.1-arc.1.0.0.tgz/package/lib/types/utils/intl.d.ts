/**
 * Memoized `Intl.Segmenter` with grapheme granularity for width-aware string
 * handling in the renderer and terminal parser.
 * @returns The shared grapheme segmenter, created once on first use.
 */
export declare function getGraphemeSegmenter(): Intl.Segmenter;
//# sourceMappingURL=intl.d.ts.map
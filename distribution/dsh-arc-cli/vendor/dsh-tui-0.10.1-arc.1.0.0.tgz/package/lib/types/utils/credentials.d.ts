/** The DSH home that owns the credential store, following the launcher's rule. */
export declare function dshHomeDir(): string;
/**
 * Whether the DSH credential store declares a reference by this name.
 *
 * Only the top-level `refs:` block is inspected — the bare name also appears in
 * grants and payloads, where a match would be a false positive.
 * @param name - Reference name to look for (for example `DEEPSEEK_API_KEY`).
 * @param home - DSH home override; defaults to {@link dshHomeDir}.
 * @returns True when a `refs` entry with that name exists.
 */
export declare function credentialRefDeclared(name: string, home?: string): boolean;
//# sourceMappingURL=credentials.d.ts.map
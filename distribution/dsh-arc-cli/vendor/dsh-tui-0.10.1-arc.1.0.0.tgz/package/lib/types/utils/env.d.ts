/**
 * Minimal terminal-environment shim for terminal capability checks. The
 * renderer reads `env.terminal` to choose the OSC terminator for Kitty.
 */
export declare const env: {
    readonly terminal: string;
};
//# sourceMappingURL=env.d.ts.map
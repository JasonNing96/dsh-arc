/**
 * The renderer calls this once stdin handoff completes. Early-input capture is
 * not used by dsh-tui, so this is a no-op.
 */
export declare function stopCapturingEarlyInput(): void;
//# sourceMappingURL=earlyInput.d.ts.map
/**
 * Minimal semver `>=` comparison used when terminal capabilities depend on
 * `TERM_PROGRAM_VERSION`.
 * @param a - First version string (optional `v` prefix and pre-release suffix tolerated).
 * @param b - Second version string.
 * @returns True when `a` is greater than or equal to `b`.
 */
export declare function gte(a: string, b: string): boolean;
//# sourceMappingURL=semver.d.ts.map
/**
 * Shorten `text` to at most `maxWidth` terminal cells by replacing its
 * middle with `…`, keeping the head and the tail. A path keeps its root and
 * its file name; a file name keeps its stem's start and its extension.
 * Widths are display cells (CJK wide characters count as two), never
 * string lengths.
 */
export declare function truncateMiddle(text: string, maxWidth: number): string;
//# sourceMappingURL=truncateMiddle.d.ts.map
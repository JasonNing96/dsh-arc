import React from 'react';
import type { Color } from '../ink/styles.js';
import type { Theme } from '../theme.js';
import type { LocalCommand } from '../commands.js';
/**
 * The slash-command suggestion overlay, using the shared rounded
 * `SuggestionCard` for the command list:
 *
 *   ╭─ 命令 · 共 12 项 ──────────────────────╮
 *   │ ❯ compact  Summarize earlier turns…  │   ← 选中：❯ + 加粗 + suggestion 色
 *   │   compare  Compare selected messages … │   ← 名字里命中输入的段提亮
 *   │ ↑2 · ↓3                                 │   ← 仅当列表被窗口裁剪
 *   ╰─────────────────────────────────────────╯
 *
 * 未选中行整体 dim，唯独名字里匹配当前查询 token 的前缀以正常亮度提亮
 * （bold 与 dim 在终端互斥，故提亮用非 dim 而非加粗）；选中行整行
 * suggestion 色、名字加粗、前置 ❯ 指针。
 */
export declare function CommandSuggestions({ commands, selectedIndex, columns, query, accent, onPick, onWheelStep, }: {
    commands: readonly (LocalCommand & {
        descriptionKey?: string;
    })[];
    selectedIndex: number;
    columns: number;
    /** 原始 `/…` 输入；其最后一段 token 用于名字前缀高亮。 */
    query?: string;
    accent?: keyof Theme | Color;
    /** 鼠标点击行（fullscreen）：上报过滤后列表的绝对索引（与键盘
     *  selectedIndex 同一索引空间），接受路径由 PromptInput 复用。 */
    onPick?: (index: number) => void;
    /** 滚轮步进（fullscreen）：±1 移动选中行。 */
    onWheelStep?: (step: 1 | -1) => void;
}): React.ReactNode;
//# sourceMappingURL=CommandSuggestions.d.ts.map
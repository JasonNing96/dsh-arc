import React from 'react';
import type { ChannelUi as Channel } from '../adapter/channel/ui-policy.js';
import type { ChannelGoal } from '../dsh-adapter/channel.js';
/**
 * Compact goal chip for the status footer: phase glyph + rounds, colored by
 * phase. `minimal` swaps the glyph for a text form, per the minimal-mode
 * no-emoji contract.
 */
export declare function GoalStatusChip({ goal, minimal }: {
    goal: ChannelGoal;
    minimal?: boolean;
}): React.ReactNode;
/**
 * Live goal + todo panel above the prompt input. Data rides on the channel:
 * `channel.goal` is folded from `goal/change` context events and
 * `channel.todos` from `todo/write` whole-list snapshots, so every model
 * update re-renders this panel in real time (no polling). Renders nothing
 * while both slots are empty.
 *
 * The todo section folds two ways: completed rows fold automatically once
 * the agent goes idle (the header's `✓ done/total` count keeps the
 * summary), and `collapsed` folds the whole section to that single header
 * line any time — including mid-turn, where the line still previews the
 * in-progress task. `onToggle` is the click affordance for the header row;
 * the ctrl/cmd+q hotkey in Chat drives the same state.
 *
 * Goal elapsed time is the panel's own wall clock (started when the goal
 * id first appears, frozen on completion) — deliberately not derived from
 * session-event timestamps.
 */
export declare function GoalTodoPanel({ channel, collapsed, onToggle, }: {
    channel: Channel;
    /** Fold the whole todo section to its summary header line. */
    collapsed?: boolean;
    /** Toggle the fold (click on the header row; shares the hotkey state). */
    onToggle?: () => void;
}): React.ReactNode;
//# sourceMappingURL=GoalTodoPanel.d.ts.map
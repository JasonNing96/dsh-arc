import React from 'react';
import { type Tip } from '../tips.js';
import { type UpstreamDriftSummary } from '../dsh-adapter/contract.js';
import { type WhaleIntroId } from './whaleFrames.js';
/**
 * The header splash: one layout, two phases. The **opening** (~1.7–3.5s,
 * once) plays one of three whale intros — the classic blink + spout +
 * tail-wag combo, the heart pass, or the sleep-Z float — rolled on every
 * mount (see `pickOpeningSequence`): randomly at startup, and again
 * randomly on each `/deepseek` easter-egg replay — and runs the shimmer
 * sweeps; the **settled** header is the same tree frozen at t=0 — whale
 * on the standard pose, sweep highlights parked off-screen, clock
 * unsubscribed, zero timers.
 *
 * Layout: the 13-row pixel whale beside a text column of matching height —
 * the `✦ dsh-TUI` wordmark with version, the `DEEPSEEK`/`HARNESS` tagline in
 * the 5-row block font (brand-blue → ice gradient), the model/effort and
 * cwd in plain text (no brand-color highlight), the startup tip, and below
 * the whale the welcome tagline, centered under the art, in ice
 * blue. Narrow terminals drop the whale and keep the text column.
 */
export declare function LogoV2({ model, effort, cwd, skipIntro, intro, tip, whale, whaleIdle, working, drift, }: {
    model: string;
    effort?: string | undefined;
    cwd: string;
    /** Test seam: mount straight into the settled header (probes skip the intro). */
    skipIntro?: boolean;
    /** Test seam: pin the intro animation instead of rolling one at startup. */
    intro?: WhaleIntroId;
    /** Test seam: pin the startup tip line (probes need a deterministic tip). */
    tip?: Tip;
    /** Show the pixel whale art (settings `dsh-tui.whale`); off → text-only header. */
    whale?: boolean;
    /** Welcome-phase idle whale behaviors — fin flutters, tail thumps,
     * sleep after inactivity (settings `dsh-tui.whaleIdle`; on by default —
     * an explicit `false` keeps the settled header timer-free). Click-hearts
     * work regardless, until the freeze. */
    whaleIdle?: boolean;
    /** Whether an agent turn is active. The FIRST active turn permanently
     * freezes the whale to the static standard frame (the idle planner and
     * click-hearts are welcome-phase features); sustained !working before
     * that lets it fall asleep. */
    working?: boolean;
    /** Test seam: pin/suppress the upstream-drift notice (`null` forces it off;
     * `undefined` — the production default — auto-detects the install). */
    drift?: UpstreamDriftSummary | null;
}): React.ReactNode;
//# sourceMappingURL=LogoV2.d.ts.map
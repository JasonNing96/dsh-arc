import React from 'react';
/**
 * The dim "interrupted" row shown when the user stops a turn.
 */
export declare function TurnInterruptedRow(): React.ReactNode;
//# sourceMappingURL=TurnInterruptedRow.d.ts.map
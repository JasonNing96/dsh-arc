import React from 'react';
import type { PresetOption } from '../dsh-adapter/channel.js';
/**
 * Agent-preset picker (issue #8) using the ActivityPicker layout: a
 * permission-colored Pane listing every roster
 * preset with its display name and description, `❯` focus pointer and `✓`
 * on the preset the current session runs. Enter applies through
 * `channel.switchPreset`, Esc cancels. Broken presets are listed (the
 * roster's discovery contract) but marked with their reason; the roster
 * default is tagged.
 */
export declare function PresetPicker({ presets, focusIndex, currentPreset, onPick, }: {
    presets: readonly PresetOption[];
    focusIndex: number;
    currentPreset: string | undefined;
    /** Mouse pick (fullscreen): clicked row's absolute index (Chat applies
     *  the same code path as the keyboard Enter). */
    onPick?: (index: number) => void;
}): React.ReactNode;
//# sourceMappingURL=PresetPicker.d.ts.map
import React from 'react';
export declare function StreamingMarkdown({ children, dimColor, }: {
    children: string;
    dimColor?: boolean;
}): React.ReactNode;
//# sourceMappingURL=StreamingMarkdown.d.ts.map
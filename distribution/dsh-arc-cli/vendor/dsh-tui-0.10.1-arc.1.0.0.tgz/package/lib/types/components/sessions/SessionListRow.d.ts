import React from 'react';
import type { ClickEvent } from '../../ink/events/click-event.js';
import type { ContextMenuEvent } from '../../ink/events/context-menu-event.js';
import type { SessionSummary } from '../../dsh-adapter/sessions/index.js';
/**
 * One session in the browser's list: a title line and a metadata line.
 *
 * Two lines rather than one because the two carry different jobs. The title
 * answers "is this the conversation I mean"; the metadata answers "which of
 * the three that look alike is it" — when it was, on what branch, how big,
 * under which model. Folding both onto one line makes the title compete with
 * facts nobody reads first, and on a narrow terminal the title is what loses.
 *
 * Widths are resolved here rather than delegated to flexbox: the row must
 * stay exactly two lines at every terminal width, and a row that wraps
 * destroys the alignment that lets the eye scan a list at all.
 */
export declare function SessionListRow({ session, width, depth, focused, pinned, now, onClick, onContextMenu, onTogglePin, }: {
    session: SessionSummary;
    /** Columns available to the row, indentation included. */
    width: number;
    /** 0 for a conversation, 1 for a sub-agent run under its parent. */
    depth: number;
    focused: boolean;
    /** Whether the user pinned this session to the top of the browser. */
    pinned: boolean;
    /** Epoch ms used for every relative time in this render pass. */
    now: number;
    /** 鼠标点击行（fullscreen）：恢复该会话（与 Enter 同路径）。 */
    onClick?(event: ClickEvent): void;
    /** 鼠标右键（fullscreen）：在该行弹出操作菜单（打开/固定/重命名/删除）。 */
    onContextMenu?(event: ContextMenuEvent): void;
    /** 点击行内 ★/☆（fullscreen）：切换固定状态，不冒泡成"打开会话"。 */
    onTogglePin?(): void;
}): React.ReactNode;
//# sourceMappingURL=SessionListRow.d.ts.map
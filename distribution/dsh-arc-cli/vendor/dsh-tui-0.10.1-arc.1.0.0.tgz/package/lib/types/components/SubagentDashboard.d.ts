import React from 'react';
import type { SubagentState } from '../dsh-adapter/subagents.js';
export interface SubagentDashboardProps {
    subagents: SubagentState[];
    onClose: () => void;
    onSelect?: (agentId: string) => void;
}
/** 可点击 ✕ 退出按钮：整屏/浮层场景的鼠标退出通道（Esc 等价）。 */
export declare function ExitButton({ onClick }: {
    onClick: () => void;
}): React.ReactNode;
/**
 * SubagentDashboard — overlay panel showing all active/recent subagents.
 * Keyboard: up/down to navigate, Enter to view detail, Esc to close.
 */
export declare function SubagentDashboard({ subagents, onClose, onSelect }: SubagentDashboardProps): React.ReactNode;
//# sourceMappingURL=SubagentDashboard.d.ts.map
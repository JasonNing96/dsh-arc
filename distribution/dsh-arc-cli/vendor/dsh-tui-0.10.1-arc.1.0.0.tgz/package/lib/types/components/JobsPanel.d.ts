import React from 'react';
import { type BackgroundJobState } from '../dsh-adapter/jobs.js';
export interface JobsPanelProps {
    jobs: readonly BackgroundJobState[];
    onClose: () => void;
    /** Kill the focused live job (`job_kill` with the session's authority). */
    onKill: (id: string) => void;
}
/**
 * `/jobs` overlay panel — every background job of the current session with
 * live status, elapsed/total duration and terminal detail (exit code).
 * Keyboard: ↑/↓ move, k kills the focused live job, Esc closes; the focused
 * row expands a detail block (full label, start/finish times, mirrored
 * output tail). The panel is the deep view behind the transcript job cards.
 */
export declare function JobsPanel({ jobs, onClose, onKill }: JobsPanelProps): React.ReactNode;
//# sourceMappingURL=JobsPanel.d.ts.map
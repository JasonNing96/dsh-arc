export interface SessionComposer {
    initialText(): string;
    changed(text: string): void;
}
export declare const SessionComposerContext: import("react").Context<SessionComposer | undefined>;
//# sourceMappingURL=session-composer.d.ts.map
import React from 'react';
import type { SubagentState } from '../dsh-adapter/subagents.js';
export interface SubagentDetailSceneProps {
    subagent: SubagentState;
    onBack: () => void;
    onInterrupt?: (agentId: string) => void;
}
/**
 * SubagentDetailScene — full-screen paged detail view for one subagent.
 * Header block (identity + stats) stays fixed; the body pages through
 * 摘要 / 输出 / 工具 with ←/→. Follow-up delivery was removed: the official
 * seam only accepts continuable children, and one-shot spawn children are
 * disposed at settlement, so the affordance would be a dead control.
 */
export declare function SubagentDetailScene({ subagent, onBack, onInterrupt, }: SubagentDetailSceneProps): React.ReactNode;
//# sourceMappingURL=SubagentDetailScene.d.ts.map
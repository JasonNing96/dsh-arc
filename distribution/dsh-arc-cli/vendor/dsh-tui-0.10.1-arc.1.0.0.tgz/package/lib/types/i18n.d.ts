/**
 * dsh-tui localization — UI strings for Chinese (`zh`, the default) and
 * English (`en`).
 *
 * Resolution order mirrors the `/theme` mechanism (see themePrefs.ts):
 *
 *   1. `DSH_TUI_LANG` env var (`en` / `zh`) — pinned at process start
 *   2. `lang` cordis.yml config key (see Config in index.ts)
 *   3. the persisted `/lang` choice in `~/.dsh-tui/lang.json`
 *   4. the OS locale guess (`LC_ALL` / `LC_MESSAGES` / `LANG`)
 *   5. `zh` (the original hard-coded language)
 *
 * `/lang` switches at runtime and hot-swaps the whole UI. The dictionary is
 * a flat key → per-language text map; `t(key, params)` substitutes
 * `{{name}}` placeholders with the given params. A per-language value is
 * either a plain template or `{ one, other }` plural forms selected via
 * `Intl.PluralRules` on the `count` param (zh has no grammatical number and
 * always resolves to `other`). Missing keys render the key itself so a typo
 * is visible in the UI instead of silently blank.
 *
 * The dictionary shape is enforced at compile time (`satisfies` below):
 * every entry carries zh, and en is optional only for the `cmd-desc-*`
 * family whose en truth lives in the command registry (see {@link tOr}).
 * scripts/verify-i18n.ts adds the checks types cannot express: placeholder
 * parity between languages, single-brace typos, and dead keys.
 */
export type Lang = 'zh' | 'en';
/** The languages shipped with the plugin, in display order. */
export declare const LANGS: readonly ["zh", "en"];
/**
 * One dictionary value in one language: a plain `{{name}}` template, or
 * plural forms picked by the `count` param through `Intl.PluralRules`.
 * Only `one`/`other` exist because those are the only CLDR categories zh
 * and en use; a third shipped language may need more.
 */
export type I18nText = string | {
    one: string;
    other: string;
};
declare const dict: {
    readonly 'spinner-verb-analyzing': {
        readonly zh: "分析中";
        readonly en: "Analyzing";
    };
    readonly 'spinner-verb-thinking': {
        readonly zh: "思考中";
        readonly en: "Thinking";
    };
    readonly 'spinner-verb-working': {
        readonly zh: "工作中";
        readonly en: "Working";
    };
    readonly 'spinner-verb-considering': {
        readonly zh: "斟酌中";
        readonly en: "Considering";
    };
    readonly 'spinner-verb-reviewing': {
        readonly zh: "审阅中";
        readonly en: "Reviewing";
    };
    readonly 'spinner-verb-planning': {
        readonly zh: "规划中";
        readonly en: "Planning";
    };
    readonly 'spinner-verb-checking': {
        readonly zh: "检查中";
        readonly en: "Checking";
    };
    readonly 'spinner-verb-reading': {
        readonly zh: "读取中";
        readonly en: "Reading";
    };
    readonly 'spinner-verb-searching': {
        readonly zh: "检索中";
        readonly en: "Searching";
    };
    readonly 'spinner-verb-building': {
        readonly zh: "构建中";
        readonly en: "Building";
    };
    readonly 'spinner-verb-testing': {
        readonly zh: "测试中";
        readonly en: "Testing";
    };
    readonly 'spinner-verb-connecting': {
        readonly zh: "连接中";
        readonly en: "Connecting";
    };
    readonly 'spinner-verb-preparing': {
        readonly zh: "准备中";
        readonly en: "Preparing";
    };
    readonly 'spinner-verb-exploring': {
        readonly zh: "探索中";
        readonly en: "Exploring";
    };
    readonly 'spinner-verb-reasoning': {
        readonly zh: "推理中";
        readonly en: "Reasoning";
    };
    readonly 'spinner-verb-summarizing': {
        readonly zh: "总结中";
        readonly en: "Summarizing";
    };
    readonly 'spinner-verb-resolving': {
        readonly zh: "解析中";
        readonly en: "Resolving";
    };
    readonly 'spinner-verb-responding': {
        readonly zh: "回应中";
        readonly en: "Responding";
    };
    readonly 'activity-indicator-already': {
        readonly zh: "指示器已是：{{name}}";
        readonly en: "Indicator already set: {{name}}";
    };
    readonly 'activity-indicator-switched': {
        readonly zh: "指示器已切换：{{name}}（已保存）";
        readonly en: "Indicator switched: {{name}} (saved)";
    };
    readonly 'activity-pref-write-failed': {
        readonly zh: "无法写入 ~/.dsh-tui/working-activity.json，切换未保存";
        readonly en: "Cannot write ~/.dsh-tui/working-activity.json, switch not saved";
    };
    readonly 'model-pref-write-failed': {
        readonly zh: "无法写入 ~/.dsh-tui/model.json，模型选择不会保存到重启后";
        readonly en: "Cannot write ~/.dsh-tui/model.json, the model choice will not survive a restart";
    };
    readonly 'model-route-invalid': {
        readonly zh: "持久化的模型路由 {{provider}}/{{model}} 不在该 provider 的模型列表中，已整体回退到 {{fallback}}";
        readonly en: "Persisted model route {{provider}}/{{model}} is not advertised by that provider; fell back to {{fallback}}";
    };
    readonly 'unknown-activity-preset': {
        readonly zh: "未知预设「{{name}}」· /activity frames 查看全部";
        readonly en: "Unknown preset \"{{name}}\" · /activity frames to view all";
    };
    readonly 'preset-unavailable': {
        readonly zh: "Preset 不可用——当前组合未挂载 agent-presets 名册";
        readonly en: "Preset unavailable — the agent-presets roster is not mounted";
    };
    readonly 'preset-agent-running': {
        readonly zh: "Agent 运行中，无法切换 preset";
        readonly en: "Agent is running, cannot switch preset";
    };
    readonly 'preset-not-found': {
        readonly zh: "Preset「{{id}}」不存在 · {{err}}";
        readonly en: "Preset \"{{id}}\" not found · {{err}}";
    };
    readonly 'preset-load-failed': {
        readonly zh: "Preset「{{id}}」无法加载 · {{broken}}";
        readonly en: "Preset \"{{id}}\" failed to load · {{broken}}";
    };
    readonly 'preset-already-current': {
        readonly zh: "当前 preset 已是：{{id}}";
        readonly en: "Current preset already: {{id}}";
    };
    readonly 'preset-pref-write-failed': {
        readonly zh: "无法写入 ~/.dsh-tui/agent-preset.json，选择未保存";
        readonly en: "Cannot write ~/.dsh-tui/agent-preset.json, selection not saved";
    };
    readonly 'preset-locked-saved-default': {
        readonly zh: "会话已开始，preset 已锁定（当前：{{current}}）· 已保存为默认：{{id}}（/new 或下次启动生效）";
        readonly en: "Session already started, preset locked (current: {{current}}) · Saved as default: {{id}} (applies on /new or next start)";
    };
    readonly 'preset-switch-failed': {
        readonly zh: "Preset 切换失败 · {{err}}";
        readonly en: "Preset switch failed · {{err}}";
    };
    readonly 'preset-switched-pref-failed': {
        readonly zh: "Preset 已切换：{{id}}，但默认偏好写入失败（重启后不保留）";
        readonly en: "Preset switched: {{id}}, but writing the default preference failed (won't persist after restart)";
    };
    readonly 'preset-switched-saved': {
        readonly zh: "Preset 已切换：{{id}}（已保存为默认）";
        readonly en: "Preset switched: {{id}} (saved as default)";
    };
    readonly 'preset-name-standard': {
        readonly zh: "标准模式";
        readonly en: "Standard";
    };
    readonly 'preset-desc-standard': {
        readonly zh: "功能完整的编码 Agent，支持文件编辑、Shell、文件与网页检索、Skills、计划、目标、子代理和工作流。";
        readonly en: "Full-featured coding agent: file editing, shell, file & web search, skills, plans, goals, subagents and workflows.";
    };
    readonly 'preset-name-minimal': {
        readonly zh: "极简模式";
        readonly en: "Minimal";
    };
    readonly 'preset-desc-minimal': {
        readonly zh: "仅提供持久 bash 与 str_replace_editor 的双工具编码 Agent。";
        readonly en: "A two-tool coding agent exposing only persistent bash and str_replace_editor.";
    };
    readonly 'preset-name-code': {
        readonly zh: "PTC 模式";
        readonly en: "PTC";
    };
    readonly 'preset-desc-code': {
        readonly zh: "具备标准模式的全部能力，并通过 Code Mode SDK 呈现工具，让模型用一个 TypeScript 程序组合多步操作。";
        readonly en: "Everything standard mode offers, with tools exposed through the Code Mode SDK so the model composes multi-step operations in one TypeScript program.";
    };
    readonly 'preset-name-cordis': {
        readonly zh: "创造模式";
        readonly en: "Creation";
    };
    readonly 'preset-desc-cordis': {
        readonly zh: "用于创建自定义 Agent preset：具备标准模式的全部能力，并提供运行时检查、插件实验和 preset 创作指导。";
        readonly en: "For authoring custom agent presets: everything standard mode offers plus runtime inspection, plugin experiments and preset-authoring guidance.";
    };
    readonly 'preset-name-liangshen': {
        readonly zh: "梁神模式";
        readonly en: "Liangshen mode";
    };
    readonly 'preset-desc-liangshen': {
        readonly zh: "主 Agent 与子 Agent 首轮均保持 Minimal 双工具，首次工具调用后开放完整目录，压缩后重新锚定。";
        readonly en: "Root and delegated agents keep the minimal two-tool pair on the first turn; the full catalog opens after the first tool call and re-anchors after compaction.";
    };
    readonly 'mcp-none-configured': {
        readonly zh: "未配置 MCP 服务器。";
        readonly en: "No MCP servers configured.";
    };
    readonly 'mcp-insert-hint': {
        readonly zh: "在 profile 补丁层（~/.dsh/profiles/dsh-tui/cordis.patch.yml）insert 一行即可，例：";
        readonly en: "Insert one line in the profile patch layer (~/.dsh/profiles/dsh-tui/cordis.patch.yml), e.g.:";
    };
    readonly 'mcp-readme-hint': {
        readonly zh: "详见仓库 README 的 MCP 章节。";
        readonly en: "See the MCP section of the repo README.";
    };
    readonly 'mcp-server-tools': {
        readonly zh: "{{server}}（{{count}} 个工具）: {{tools}}";
        readonly en: "{{server}} ({{count}} tools): {{tools}}";
    };
    readonly 'child-stderr-line': {
        readonly zh: "子进程 stderr: {{line}}";
        readonly en: "Subprocess stderr: {{line}}";
    };
    readonly 'child-stderr-line-repeat': {
        readonly zh: "子进程 stderr: {{line}}（重复 {{count}} 次）";
        readonly en: "Subprocess stderr: {{line}} (repeated {{count}}×)";
    };
    readonly 'export-title': {
        readonly zh: "# dsh-tui 会话导出";
        readonly en: "# dsh-tui session export";
    };
    readonly 'export-time': {
        readonly zh: "- 导出时间: {{time}}";
        readonly en: "- Exported: {{time}}";
    };
    readonly 'export-model': {
        readonly zh: "- 模型: {{model}}";
        readonly en: "- Model: {{model}}";
    };
    readonly 'export-session': {
        readonly zh: "- 会话: {{id}}";
        readonly en: "- Session: {{id}}";
    };
    readonly 'export-dir': {
        readonly zh: "- 目录: {{cwd}}";
        readonly en: "- Directory: {{cwd}}";
    };
    readonly 'mentions-attached': {
        readonly zh: "已附加 {{count}} 个文件引用";
        readonly en: {
            readonly one: "Attached {{count}} file reference";
            readonly other: "Attached {{count}} file references";
        };
    };
    readonly 'mentions-missing': {
        readonly zh: "未找到引用: {{paths}}";
        readonly en: "References not found: {{paths}}";
    };
    readonly 'transcript-image': {
        readonly zh: "图片";
        readonly en: "Image";
    };
    readonly 'image-preview-previous': {
        readonly zh: "上一张";
        readonly en: "Previous image";
    };
    readonly 'image-preview-next': {
        readonly zh: "下一张";
        readonly en: "Next image";
    };
    readonly 'image-preview-open-original': {
        readonly zh: "打开原图";
        readonly en: "Open original";
    };
    readonly 'image-preview-opening': {
        readonly zh: "正在打开原图…";
        readonly en: "Opening original...";
    };
    readonly 'image-preview-open-failed': {
        readonly zh: "原图打开失败，点击重试";
        readonly en: "Could not open original; retry";
    };
    readonly 'image-preview-fit': {
        readonly zh: "适应";
        readonly en: "Fit";
    };
    readonly 'image-preview-actual': {
        readonly zh: "100% 原像素";
        readonly en: "Actual pixels (100%)";
    };
    readonly 'image-preview-no-metrics': {
        readonly zh: "终端未报告字符格像素尺寸";
        readonly en: "Terminal cell pixel size unavailable";
    };
    readonly 'image-preview-zoom-in': {
        readonly zh: "放大";
        readonly en: "Zoom in";
    };
    readonly 'image-preview-zoom-out': {
        readonly zh: "缩小";
        readonly en: "Zoom out";
    };
    readonly 'image-preview-left': {
        readonly zh: "向左平移";
        readonly en: "Pan left";
    };
    readonly 'image-preview-right': {
        readonly zh: "向右平移";
        readonly en: "Pan right";
    };
    readonly 'image-preview-up': {
        readonly zh: "向上平移";
        readonly en: "Pan up";
    };
    readonly 'image-preview-down': {
        readonly zh: "向下平移";
        readonly en: "Pan down";
    };
    readonly 'transcript-image-loading': {
        readonly zh: "正在加载 {{name}}";
        readonly en: "Loading {{name}}";
    };
    readonly 'transcript-image-ready': {
        readonly zh: "图片 · {{name}}";
        readonly en: "Image · {{name}}";
    };
    readonly 'transcript-image-unavailable': {
        readonly zh: "无法预览 {{name}}";
        readonly en: "Cannot preview {{name}}";
    };
    readonly 'transcript-image-message': {
        readonly zh: "{{count}} 张图片";
        readonly en: {
            readonly one: "{{count}} image";
            readonly other: "{{count}} images";
        };
    };
    readonly 'input-image-token-stale': {
        readonly zh: "{{token}} 已失效，发送时不会附带图片";
        readonly en: "{{token}} is no longer staged; no image will attach";
    };
    readonly 'input-images-staged': {
        readonly zh: "已附加 {{count}} 张图片";
        readonly en: {
            readonly one: "Attached {{count}} image";
            readonly other: "Attached {{count}} images";
        };
    };
    readonly 'send-failed': {
        readonly zh: "发送失败 · {{err}}";
        readonly en: "Send failed · {{err}}";
    };
    readonly 'export-user-section': {
        readonly zh: "## 用户";
        readonly en: "## User";
    };
    readonly 'export-thinking-section': {
        readonly zh: "## 思考";
        readonly en: "## Thinking";
    };
    readonly 'export-assistant-section': {
        readonly zh: "## 助手";
        readonly en: "## Assistant";
    };
    readonly 'export-tool-section': {
        readonly zh: "## 工具 · {{name}}";
        readonly en: "## Tool · {{name}}";
    };
    readonly 'export-result-section': {
        readonly zh: "### 结果";
        readonly en: "### Result";
    };
    readonly 'agentsmd-project': {
        readonly zh: "## 项目";
        readonly en: "## Project";
    };
    readonly 'agentsmd-project-body': {
        readonly zh: "（在此描述项目的目标、结构与约定——这份文件会注入给每个 agent 作为工作区上下文。）";
        readonly en: "(Describe the project's goals, structure and conventions here — this file is injected to every agent as workspace context.)";
    };
    readonly 'agentsmd-conventions': {
        readonly zh: "## 约定";
        readonly en: "## Conventions";
    };
    readonly 'agentsmd-convention-read': {
        readonly zh: "- 改动前先阅读相关模块";
        readonly en: "- Read the relevant modules before making changes";
    };
    readonly 'agentsmd-convention-style': {
        readonly zh: "- 保持与现有代码风格一致";
        readonly en: "- Keep consistent with the existing code style";
    };
    readonly 'doctor-api-key': {
        readonly zh: "API key: {{state}}";
        readonly en: "API key: {{state}}";
    };
    readonly 'doctor-key-configured-env': {
        readonly zh: "已配置（环境变量）";
        readonly en: "configured (environment)";
    };
    readonly 'doctor-key-configured-store': {
        readonly zh: "已配置（DSH 凭据库）";
        readonly en: "configured (DSH credential store)";
    };
    readonly 'doctor-key-missing': {
        readonly zh: "未配置（环境变量与 DSH 凭据库中都没有 DEEPSEEK_API_KEY）";
        readonly en: "not configured (neither DEEPSEEK_API_KEY nor a DSH credential-store ref)";
    };
    readonly 'doctor-model': {
        readonly zh: "模型: {{model}} · 提供方: {{provider}}";
        readonly en: "Model: {{model}} · Provider: {{provider}}";
    };
    readonly 'doctor-cwd': {
        readonly zh: "工作目录: {{cwd}}";
        readonly en: "Working directory: {{cwd}}";
    };
    readonly 'doctor-context-window': {
        readonly zh: "上下文窗口: {{window}} tokens";
        readonly en: "Context window: {{window}} tokens";
    };
    readonly 'doctor-unknown': {
        readonly zh: "未知";
        readonly en: "unknown";
    };
    readonly 'doctor-session': {
        readonly zh: "会话: {{id}}";
        readonly en: "Session: {{id}}";
    };
    readonly 'doctor-config': {
        readonly zh: "配置: {{candidate}} {{state}}";
        readonly en: "Config: {{candidate}} {{state}}";
    };
    readonly 'doctor-config-missing': {
        readonly zh: "（不存在）";
        readonly en: "(missing)";
    };
    readonly 'doctor-storage': {
        readonly zh: "会话存储: {{dir}} {{state}}";
        readonly en: "Session storage: {{dir}} {{state}}";
    };
    readonly 'doctor-storage-uninit': {
        readonly zh: "（未初始化）";
        readonly en: "(not initialized)";
    };
    readonly 'subagent-not-mounted': {
        readonly zh: "子代理服务未挂载（leaf 未启用 subagent）";
        readonly en: "Subagent service not mounted (leaf has no subagent)";
    };
    readonly 'subagent-none': {
        readonly zh: "当前会话暂无子代理";
        readonly en: "No subagents in the current session";
    };
    readonly 'subagent-resumable': {
        readonly zh: "可续";
        readonly en: "resumable";
    };
    readonly 'subagent-oneshot': {
        readonly zh: "一次性";
        readonly en: "one-shot";
    };
    readonly 'subagent-row': {
        readonly zh: "{{mode}} {{label}}{{activity}} · {{id}}";
        readonly en: "{{mode}} {{label}}{{activity}} · {{id}}";
    };
    readonly 'subagent-running': {
        readonly zh: " 运行中";
        readonly en: " running";
    };
    readonly 'subagent-archived': {
        readonly zh: " 已归档";
        readonly en: " archived";
    };
    readonly 'subagent-query-failed': {
        readonly zh: "查询失败 · {{err}}";
        readonly en: "Query failed · {{err}}";
    };
    readonly 'subagent-tools': {
        readonly zh: "工具";
        readonly en: "Tools";
    };
    readonly 'subagent-status-running': {
        readonly zh: "运行中";
        readonly en: "running";
    };
    readonly 'subagent-status-completed': {
        readonly zh: "已完成";
        readonly en: "completed";
    };
    readonly 'subagent-status-failed': {
        readonly zh: "失败";
        readonly en: "failed";
    };
    readonly 'agent-preset-switched': {
        readonly zh: "Agent preset 已切换：{{preset}}";
        readonly en: "Agent preset switched: {{preset}}";
    };
    readonly 'context-low-warning': {
        readonly zh: "上下文即将耗尽（剩余 {{percent}}%）· 运行 /clear 或新建会话";
        readonly en: "Context low ({{percent}}% remaining) · Run /clear or start a new session";
    };
    readonly 'rewind-unavailable': {
        readonly zh: "回退不可用——会话服务未加载";
        readonly en: "Rewind unavailable — session services not loaded";
    };
    readonly 'rewind-settling': {
        readonly zh: "无法回退——回合仍在收尾，请稍候再试";
        readonly en: "Cannot rewind — the turn is still settling, try again in a moment";
    };
    readonly 'rewind-fork-failed': {
        readonly zh: "无法回退到该处 · {{err}}";
        readonly en: "Cannot rewind to this point · {{err}}";
    };
    readonly 'rewind-create-failed': {
        readonly zh: "回退失败——无法创建替代会话";
        readonly en: "Rewind failed — could not create the replacement session";
    };
    readonly 'rewind-attach-failed': {
        readonly zh: "已回退，但工作区挂载失败 · {{err}}";
        readonly en: "Session rewound, but workspace attachment failed · {{err}}";
    };
    readonly 'rewind-no-persistence': {
        readonly zh: "回退不可用——持久化服务未加载";
        readonly en: "Rewind unavailable — session persistence not loaded";
    };
    readonly 'rewind-load-failed': {
        readonly zh: "无法读取该会话日志 · {{err}}";
        readonly en: "Could not read that session log · {{err}}";
    };
    readonly 'rewind-first-message': {
        readonly zh: "不能回退到第一条消息之前";
        readonly en: "Cannot rewind past the very first message";
    };
    readonly 'rewind-noop': {
        readonly zh: "该点之后没有可回退的内容";
        readonly en: "Nothing to rewind past this point";
    };
    readonly 'rewind-session-changed': {
        readonly zh: "会话已切换，回退已放弃";
        readonly en: "The session changed; the rewind was dropped";
    };
    readonly 'tree-unavailable': {
        readonly zh: "会话树不可用——持久化服务未加载";
        readonly en: "Session tree unavailable — session persistence not loaded";
    };
    readonly 'fork-unavailable': {
        readonly zh: "分叉不可用——会话服务未加载";
        readonly en: "Fork unavailable — session services not loaded";
    };
    readonly 'fork-while-working': {
        readonly zh: "回合运行中，无法分叉会话";
        readonly en: "Cannot fork while a turn is running";
    };
    readonly 'fork-failed': {
        readonly zh: "分叉失败 · {{err}}";
        readonly en: "Fork failed · {{err}}";
    };
    readonly 'fork-create-failed': {
        readonly zh: "分叉失败——无法创建分叉会话";
        readonly en: "Fork failed — could not create the forked session";
    };
    readonly 'fork-attach-failed': {
        readonly zh: "已分叉，但工作区挂载失败 · {{err}}";
        readonly en: "Session forked, but workspace attachment failed · {{err}}";
    };
    readonly 'fork-done': {
        readonly zh: "已分叉（{{id}}）——仍在原会话中\n新进程进入分叉：{{command}}";
        readonly en: "Forked ({{id}}) — still in the original session\nEnter the fork in a new process: {{command}}";
    };
    readonly 'tree-title': {
        readonly zh: "会话树";
        readonly en: "Session tree";
    };
    readonly 'tree-sessions': {
        readonly zh: "会话";
        readonly en: "sessions";
    };
    readonly 'tree-loading': {
        readonly zh: "正在加载会话树…";
        readonly en: "Loading the session tree…";
    };
    readonly 'tree-rewinding': {
        readonly zh: "正在分叉并切换…";
        readonly en: "Forking and switching…";
    };
    readonly 'tree-empty': {
        readonly zh: "没有可显示的条目";
        readonly en: "No entries to show";
    };
    readonly 'tree-truncated': {
        readonly zh: "已截断";
        readonly en: "truncated";
    };
    readonly 'tree-search': {
        readonly zh: "输入即搜索…";
        readonly en: "Type to search…";
    };
    readonly 'tree-filter-default': {
        readonly zh: "默认";
        readonly en: "default";
    };
    readonly 'tree-filter-no-tools': {
        readonly zh: "无工具";
        readonly en: "no tools";
    };
    readonly 'tree-filter-user-only': {
        readonly zh: "仅用户";
        readonly en: "user only";
    };
    readonly 'tree-filter-all': {
        readonly zh: "全部";
        readonly en: "all";
    };
    readonly 'tree-kind-user': {
        readonly zh: "用户消息";
        readonly en: "user message";
    };
    readonly 'tree-kind-assistant': {
        readonly zh: "助手回复";
        readonly en: "assistant message";
    };
    readonly 'tree-kind-tool': {
        readonly zh: "工具调用";
        readonly en: "tool call";
    };
    readonly 'tree-kind-compact': {
        readonly zh: "压缩检查点";
        readonly en: "compaction";
    };
    readonly 'tree-kind-interrupt': {
        readonly zh: "中断";
        readonly en: "interrupt";
    };
    readonly 'tree-kind-notice': {
        readonly zh: "通知";
        readonly en: "notice";
    };
    readonly 'tree-empty-fork': {
        readonly zh: "（空分叉）";
        readonly en: "(empty fork)";
    };
    readonly 'tree-unreadable': {
        readonly zh: "（日志无法读取）";
        readonly en: "(unreadable log)";
    };
    readonly 'tree-unloaded': {
        readonly zh: "（超出预算未加载）";
        readonly en: "(not loaded — over budget)";
    };
    readonly 'tree-first-message': {
        readonly zh: "不能回退到第一条消息之前";
        readonly en: "Cannot rewind past the very first message";
    };
    readonly 'tree-adopt-live': {
        readonly zh: "当前会话就在这条分支上";
        readonly en: "The live session is already on this branch";
    };
    readonly 'tree-adopt-unavailable': {
        readonly zh: "该分支无法整体切换（未加载到末端）";
        readonly en: "Cannot adopt this branch (its tip was not loaded)";
    };
    readonly 'tree-menu-rewind': {
        readonly zh: "回退到这里";
        readonly en: "Rewind here";
    };
    readonly 'tree-menu-rewind-detail': {
        readonly zh: "丢弃该轮对话，提示词回到输入框";
        readonly en: "Drops that turn; its prompt returns to the input";
    };
    readonly 'tree-menu-fork': {
        readonly zh: "从这分叉";
        readonly en: "Fork here";
    };
    readonly 'tree-menu-fork-detail': {
        readonly zh: "保留这条消息，从这里开新分支";
        readonly en: "Keeps this entry and branches here";
    };
    readonly 'tree-menu-adopt': {
        readonly zh: "切换到该分支";
        readonly en: "Adopt this branch";
    };
    readonly 'tree-menu-adopt-detail': {
        readonly zh: "保留整条分支并切换过去";
        readonly en: "Switches to the whole branch, content kept";
    };
    readonly 'tree-menu-cancel': {
        readonly zh: "取消";
        readonly en: "Cancel";
    };
    readonly 'tree-confirm-rewind': {
        readonly zh: "回退到「{{text}}」？";
        readonly en: "Rewind to \"{{text}}\"?";
    };
    readonly 'tree-confirm-drop': {
        readonly zh: "回退到「{{text}}」？该轮 {{n}} 条消息将丢弃";
        readonly en: "Rewind to \"{{text}}\"? Drops that turn ({{n}} entries)";
    };
    readonly 'tree-confirm-adopt': {
        readonly zh: "切换到「{{text}}」所在分支？";
        readonly en: "Switch to the branch of \"{{text}}\"?";
    };
    readonly 'tree-confirm-drops-branch': {
        readonly zh: "注意：该分支的全部内容都在这一轮里，回退后将看不到它们";
        readonly en: "Heads-up: this branch’s whole content is that one turn — it disappears from the fork";
    };
    readonly 'tree-hint': {
        readonly zh: "**Enter** 菜单 · **{{mod}}F** 从这分叉 · **{{mod}}B** 切到分支 · **{{mod}}O** 过滤 · 点击行出菜单 · 输入搜索 · Esc 退出";
        readonly en: "**Enter** menu · **{{mod}}F** fork here · **{{mod}}B** adopt branch · **{{mod}}O** filter · click a row for the menu · type to search · Esc exits";
    };
    readonly 'tree-hint-short': {
        readonly zh: "**Enter** 菜单 · 点击行出菜单 · Esc 退出";
        readonly en: "**Enter** menu · click a row · Esc exits";
    };
    readonly 'tree-hint-menu': {
        readonly zh: "**↑↓** 选择 · **Enter** 执行 · 首字母直达 · Esc 返回";
        readonly en: "**↑↓** move · **Enter** run · letter keys jump · Esc back";
    };
    readonly 'tree-hint-confirm': {
        readonly zh: "**Enter** 确认 · Esc 取消";
        readonly en: "**Enter** to confirm · Esc to cancel";
    };
    readonly 'tree-refused': {
        readonly zh: "操作未执行（原因已记录到会话通知）";
        readonly en: "Not executed — the reason was notified to the conversation";
    };
    readonly 'tree-rewind-failed': {
        readonly zh: "操作失败 · {{message}}";
        readonly en: "Action failed · {{message}}";
    };
    readonly 'tree-rewound': {
        readonly zh: "已回退——编辑后重新发送";
        readonly en: "Earlier turn restored — edit your message to continue";
    };
    readonly 'tree-forked': {
        readonly zh: "已从此处分叉";
        readonly en: "Forked from this point";
    };
    readonly 'tree-adopted': {
        readonly zh: "已切换到该分支";
        readonly en: "Switched to that branch";
    };
    readonly 'tree-preview-title': {
        readonly zh: "预览";
        readonly en: "Preview";
    };
    readonly 'tree-branch-live': {
        readonly zh: "当前会话";
        readonly en: "live session";
    };
    readonly 'resume-while-working': {
        readonly zh: "回合运行中，无法恢复会话";
        readonly en: "Cannot resume while a turn is running";
    };
    readonly 'resume-unavailable': {
        readonly zh: "恢复不可用——agents 服务未加载";
        readonly en: "Resume unavailable — agents service not loaded";
    };
    readonly 'resume-failed': {
        readonly zh: "恢复失败 · {{err}}";
        readonly en: "Resume failed · {{err}}";
    };
    readonly 'resume-attach-failed': {
        readonly zh: "已恢复会话，但工作区挂载失败 · {{err}}";
        readonly en: "Session resumed, but workspace attachment failed · {{err}}";
    };
    readonly 'resume-session-changed': {
        readonly zh: "会话已切换，恢复已放弃";
        readonly en: "The session changed; the resume was dropped";
    };
    readonly 'new-session-while-working': {
        readonly zh: "回合运行中，无法新建会话";
        readonly en: "Cannot start a new session while a turn is running";
    };
    readonly 'new-session-unavailable': {
        readonly zh: "新建会话不可用——agents 服务未加载";
        readonly en: "New session unavailable — agents service not loaded";
    };
    readonly 'new-session-failed': {
        readonly zh: "新建会话失败 · {{err}}";
        readonly en: "New session failed · {{err}}";
    };
    readonly 'new-session-attach-failed': {
        readonly zh: "会话已创建，但工作区挂载失败 · {{err}}";
        readonly en: "Session created, but workspace attachment failed · {{err}}";
    };
    readonly 'model-switch-while-working': {
        readonly zh: "回合运行中，无法切换模型";
        readonly en: "Cannot switch models while a turn is running";
    };
    readonly 'model-switch-unavailable': {
        readonly zh: "模型切换不可用——会话服务未加载";
        readonly en: "Model switch unavailable — session services not loaded";
    };
    readonly 'model-switch-fork-failed': {
        readonly zh: "无法切换模型 · {{err}}";
        readonly en: "Cannot switch models · {{err}}";
    };
    readonly 'model-switch-failed': {
        readonly zh: "模型切换失败 · {{err}}";
        readonly en: "Model switch failed · {{err}}";
    };
    readonly 'model-switch-attach-failed': {
        readonly zh: "模型已切换，但工作区挂载失败 · {{err}}";
        readonly en: "Model switched, but workspace attachment failed · {{err}}";
    };
    readonly 'model-usage': {
        readonly zh: "用法：/model <provider/model>（如 deepseek/deepseek-flash）";
        readonly en: "Usage: /model <provider/model> (e.g. deepseek/deepseek-flash)";
    };
    readonly 'model-unknown': {
        readonly zh: "未知模型「{{spec}}」· /model 查看全部";
        readonly en: "Unknown model \"{{spec}}\" · /model to view all";
    };
    readonly 'compact-unavailable': {
        readonly zh: "压缩不可用——当前 leaf 没有压缩服务";
        readonly en: "Compaction unavailable · no compaction service in this leaf";
    };
    readonly 'compact-while-working': {
        readonly zh: "回合运行中，无法压缩会话";
        readonly en: "Cannot compact while a turn is running";
    };
    readonly 'compact-working': {
        readonly zh: "正在压缩会话…";
        readonly en: "Summarizing earlier turns…";
    };
    readonly 'compact-done': {
        readonly zh: "会话已压缩";
        readonly en: "Session summary is ready";
    };
    readonly 'compact-nothing': {
        readonly zh: "没有可压缩的内容";
        readonly en: "Nothing to compact";
    };
    readonly 'compact-failed': {
        readonly zh: "压缩失败 · {{err}}";
        readonly en: "Compaction failed · {{err}}";
    };
    readonly 'compact-flush-failed': {
        readonly zh: "压缩已生效，但落盘检查失败——历史已由摘要替代，请留意会话状态";
        readonly en: "Compaction took effect, but its durability flush failed — history is now the summary";
    };
    readonly 'compact-cancelled-switch': {
        readonly zh: "压缩进行中，已取消并切换会话";
        readonly en: "In-flight compaction cancelled for the session switch";
    };
    readonly 'turn-failed': {
        readonly zh: "回合出错{{detail}}";
        readonly en: "Turn error{{detail}}";
    };
    readonly 'prompt-debug-saved': {
        readonly zh: "已写入 {{count}} 条最终 LLM 请求快照到 {{file}}。快照含敏感会话与提示词数据；文件位于当前工作区，若工作区在同步/共享目录请注意清理。";
        readonly en: {
            readonly one: "Wrote 1 final LLM request snapshot to {{file}}. It contains sensitive conversation and prompt data, and lives in the current workspace — clean it up promptly if the workspace is synced or shared.";
            readonly other: "Wrote {{count}} final LLM request snapshots to {{file}}. It contains sensitive conversation and prompt data, and lives in the current workspace — clean it up promptly if the workspace is synced or shared.";
        };
    };
    readonly 'questionnaire-answered': {
        readonly zh: "📋 问卷已答 · {{total}} 题";
        readonly en: "📋 Questionnaire answered · {{total}} questions";
    };
    readonly 'context-truncated': {
        readonly zh: "…（已截断）";
        readonly en: "… (truncated)";
    };
    readonly 'context-sections': {
        readonly zh: "系统提示词 {{n}} 段";
        readonly en: "System prompt {{n}} sections";
    };
    readonly 'context-files': {
        readonly zh: "工作区指令 ×{{n}}";
        readonly en: "Workspace instructions ×{{n}}";
    };
    readonly 'context-runtime': {
        readonly zh: "运行时上下文 {{n}} 项";
        readonly en: "Runtime context {{n}} items";
    };
    readonly 'context-skills': {
        readonly zh: "技能 {{n}}";
        readonly en: "Skills {{n}}";
    };
    readonly 'context-tools': {
        readonly zh: "工具 {{n}}";
        readonly en: "Tools {{n}}";
    };
    readonly 'skill-unavailable': {
        readonly zh: "技能 {{name}} 已不可用或未开放用户直调";
        readonly en: "Skill {{name}} is gone or not user-invocable";
    };
    readonly 'context-loaded': {
        readonly zh: "已加载上下文";
        readonly en: "Context loaded";
    };
    readonly 'context-panel-expand': {
        readonly zh: " 展开";
        readonly en: " to expand";
    };
    readonly 'context-panel-collapse': {
        readonly zh: " 折叠";
        readonly en: " to collapse";
    };
    readonly 'copied-chars': {
        readonly zh: "已复制 {{n}} 个字符";
        readonly en: "Copied {{n}} characters";
    };
    readonly 'activity-current-preset': {
        readonly zh: "当前预设  {{name}}";
        readonly en: "Current preset  {{name}}";
    };
    readonly 'activity-switch-hint': {
        readonly zh: "切换      /activity（选择器）或 /activity frames <名>";
        readonly en: "Switch      /activity (picker) or /activity frames <name>";
    };
    readonly 'activity-persist-hint': {
        readonly zh: "持久化    ~/.dsh-tui/working-activity.json（重启后仍生效）";
        readonly en: "Persisted    ~/.dsh-tui/working-activity.json (survives restart)";
    };
    readonly 'activity-current-direct': {
        readonly zh: "当前预设：{{name}} · /activity frames <名> 直接切换：";
        readonly en: "Current preset: {{name}} · /activity frames <name> to switch directly:";
    };
    readonly 'activity-random-each': {
        readonly zh: "每次随机";
        readonly en: "random each time";
    };
    readonly 'activity-current-marker': {
        readonly zh: "  ← 当前";
        readonly en: "  ← current";
    };
    readonly 'activity-usage': {
        readonly zh: "用法：/activity | /activity frames <名> | /activity status";
        readonly en: "Usage: /activity | /activity frames <name> | /activity status";
    };
    readonly 'preset-current': {
        readonly zh: "当前 preset  {{name}}";
        readonly en: "Current preset  {{name}}";
    };
    readonly 'preset-roster-missing': {
        readonly zh: "（未挂载名册）";
        readonly en: "(roster not mounted)";
    };
    readonly 'preset-switch-hint': {
        readonly zh: "切换        /preset（选择器）或 /preset <id>";
        readonly en: "Switch        /preset (picker) or /preset <id>";
    };
    readonly 'preset-persist-hint': {
        readonly zh: "持久化      ~/.dsh-tui/agent-preset.json（重启后仍生效；cordis.yml preset 优先）";
        readonly en: "Persisted      ~/.dsh-tui/agent-preset.json (survives restart; cordis.yml preset wins)";
    };
    readonly 'preset-lock-hint': {
        readonly zh: "锁定规则    已开始的会话不可切换（官方 blank-only 规则）";
        readonly en: "Lock rule     started sessions cannot switch (official blank-only rule)";
    };
    readonly 'preset-roster-unmounted': {
        readonly zh: "当前组合未挂载 agent-presets 名册（preset 不可用）";
        readonly en: "The agent-presets roster is not mounted (presets unavailable)";
    };
    readonly 'theme-current': {
        readonly zh: "当前主题  {{name}}";
        readonly en: "Current theme  {{name}}";
    };
    readonly 'theme-switch-hint': {
        readonly zh: "切换      /theme（选择器）或 /theme <名字>";
        readonly en: "Switch      /theme (picker) or /theme <name>";
    };
    readonly 'theme-persist-hint': {
        readonly zh: "持久化    ~/.dsh-tui/theme.json（重启后仍生效；DSH_TUI_THEME 优先）";
        readonly en: "Persisted    ~/.dsh-tui/theme.json (survives restart; DSH_TUI_THEME wins)";
    };
    readonly 'theme-custom-hint': {
        readonly zh: "自定义    静态 ~/.dsh-tui/themes/<名字>.json（插件也可提供运行时主题；见 README「自定义主题」）";
        readonly en: "Custom      static ~/.dsh-tui/themes/<name>.json (plugins may also provide runtime themes; see README \"Custom themes\")";
    };
    readonly 'theme-auto-resolved': {
        readonly zh: "自动解析  当前为 {{name}}（跟随终端背景）";
        readonly en: "Auto-resolved  currently {{name}} (follows terminal background)";
    };
    readonly 'theme-switched-saved': {
        readonly zh: "主题已切换：{{name}}（已保存）";
        readonly en: "Theme switched: {{name}} (saved)";
    };
    readonly 'theme-unknown': {
        readonly zh: "未知主题「{{name}}」· /theme 查看全部";
        readonly en: "Unknown theme \"{{name}}\" · /theme to view all";
    };
    readonly 'status-model': {
        readonly zh: "模型   {{model}}";
        readonly en: "Model   {{model}}";
    };
    readonly 'status-working': {
        readonly zh: "工作中";
        readonly en: "working";
    };
    readonly 'status-idle': {
        readonly zh: "空闲";
        readonly en: "idle";
    };
    readonly 'status-state': {
        readonly zh: "状态   {{state}}";
        readonly en: "Status   {{state}}";
    };
    readonly 'status-session': {
        readonly zh: "会话   {{id}}";
        readonly en: "Session   {{id}}";
    };
    readonly 'status-dir': {
        readonly zh: "目录   {{cwd}}";
        readonly en: "Directory   {{cwd}}";
    };
    readonly 'workspace-picker-title': {
        readonly zh: "工作区";
        readonly en: "Workspace";
    };
    readonly 'workspace-picker-hint': {
        readonly zh: "**Enter** 切换并新建会话 · Esc 退出 · 也可输入 /workspace open <路径或 URI>";
        readonly en: "**Enter** switch and start a new session · Esc to exit · or type /workspace open <path-or-URI>";
    };
    readonly 'workspace-none': {
        readonly zh: "没有可用工作区";
        readonly en: "No workspaces available";
    };
    readonly 'workspace-list-failed': {
        readonly zh: "读取工作区失败 · {{err}}";
        readonly en: "Failed to list workspaces · {{err}}";
    };
    readonly 'workspace-uri-invalid': {
        readonly zh: "无法解析工作区目标：{{uri}}";
        readonly en: "Cannot resolve workspace target: {{uri}}";
    };
    readonly 'workspace-uri-failed': {
        readonly zh: "加载工作区失败 · {{err}}";
        readonly en: "Failed to load workspace · {{err}}";
    };
    readonly 'workspace-switch-working': {
        readonly zh: "Agent 运行中，无法切换工作区";
        readonly en: "Cannot switch workspaces while the agent is running";
    };
    readonly 'workspace-open-invalid': {
        readonly zh: "无法打开工作区：{{target}} 不是存在的目录";
        readonly en: "Cannot open workspace: {{target}} is not an existing directory";
    };
    readonly 'workspace-switched': {
        readonly zh: "已切换工作区：{{target}}";
        readonly en: "Workspace switched: {{target}}";
    };
    readonly 'workspace-flow-hint': {
        readonly zh: "**Enter** 选择 · Esc 退出";
        readonly en: "**Enter** select · Esc to exit";
    };
    readonly 'workspace-flow-edit-hint': {
        readonly zh: "**Enter** 选择当前目录 · Tab 手动输入路径 · Esc 退出";
        readonly en: "**Enter** select current directory · Tab enter a path · Esc to exit";
    };
    readonly 'workspace-flow-input-hint': {
        readonly zh: "输入绝对路径 · **Enter** 读取目录 · Esc 返回";
        readonly en: "Enter an absolute path · **Enter** load directory · Esc back";
    };
    readonly 'workspace-flow-input-empty': {
        readonly zh: "目录路径不能为空";
        readonly en: "Directory path cannot be empty";
    };
    readonly 'workspace-flow-loading': {
        readonly zh: "正在连接并读取目录… · Esc 关闭";
        readonly en: "Connecting and loading directories… · Esc to close";
    };
    readonly 'workspace-menu-title': {
        readonly zh: "Workspace 操作";
        readonly en: "Workspace actions";
    };
    readonly 'workspace-menu-resume-desc': {
        readonly zh: "切换到另一个工作区";
        readonly en: "Switch to another workspace";
    };
    readonly 'workspace-menu-rename-desc': {
        readonly zh: "重命名当前工作区（需输入名称）";
        readonly en: "Rename the current workspace (needs a name)";
    };
    readonly 'workspace-menu-open-desc': {
        readonly zh: "打开路径或工作区 URI（需输入路径）";
        readonly en: "Open a path or workspace URI (needs a path)";
    };
    readonly 'workspace-open-usage': {
        readonly zh: "用法：/workspace open <路径或 URI>";
        readonly en: "Usage: /workspace open <path-or-URI>";
    };
    readonly 'workspace-rename-usage': {
        readonly zh: "用法：/workspace rename <名称>";
        readonly en: "Usage: /workspace rename <name>";
    };
    readonly 'workspace-command-unknown': {
        readonly zh: "未知的 workspace 子命令：{{command}}";
        readonly en: "Unknown workspace subcommand: {{command}}";
    };
    readonly 'workspace-command-empty': {
        readonly zh: "该 workspace 操作没有可选目标";
        readonly en: "This workspace action has no available targets";
    };
    readonly 'workspace-command-failed': {
        readonly zh: "workspace 操作失败 · {{err}}";
        readonly en: "Workspace action failed · {{err}}";
    };
    readonly 'workspace-renamed': {
        readonly zh: "工作区已重命名：{{title}}";
        readonly en: "Workspace renamed: {{title}}";
    };
    readonly 'workspace-rename-failed': {
        readonly zh: "工作区重命名失败 · {{err}}";
        readonly en: "Failed to rename workspace · {{err}}";
    };
    readonly 'cost-cache-rate': {
        readonly zh: "缓存率 {{rate}}% · {{read}} 读 / {{write}} 写";
        readonly en: "Cache rate {{rate}}% · {{read}} read / {{write}} write";
    };
    readonly 'cost-context': {
        readonly zh: "上下文 {{pct}}%";
        readonly en: "Context {{pct}}%";
    };
    readonly 'status-title': {
        readonly zh: "标题   {{title}}";
        readonly en: "Title   {{title}}";
    };
    readonly 'cost-cache-hit-rate': {
        readonly zh: "缓存命中率 {{rate}}% · 缓存 {{read}} 读 / {{write}} 写";
        readonly en: "Cache hit rate {{rate}}% · cache {{read}} read / {{write}} write";
    };
    readonly 'cost-note': {
        readonly zh: "注：DSH 不提供 API 费用计量，以上为 token 用量（按 provider 账单计费）";
        readonly en: "Note: DSH provides no API cost metering; the above is token usage (billed by your provider)";
    };
    readonly 'status-cost-label': {
        readonly zh: "≈";
        readonly en: "≈";
    };
    readonly 'status-cost-note': {
        readonly zh: "估算（官方单价，非账单）";
        readonly en: "estimate (official rates, not a bill)";
    };
    readonly 'cost-peak-name': {
        readonly zh: "梁文峰";
        readonly en: "peak";
    };
    readonly 'cost-idle-name': {
        readonly zh: "梁文谷";
        readonly en: "idle";
    };
    readonly 'cost-now-peak': {
        readonly zh: "峰";
        readonly en: "peak";
    };
    readonly 'cost-now-idle': {
        readonly zh: "谷";
        readonly en: "idle";
    };
    readonly 'balance-summary-loading': {
        readonly zh: "DeepSeek 余额 · 查询中…";
        readonly en: "DeepSeek balance · querying…";
    };
    readonly 'balance-summary-ok': {
        readonly zh: "DeepSeek 余额 ¥{{total}} · {{state}}";
        readonly en: "DeepSeek balance ¥{{total}} · {{state}}";
    };
    readonly 'balance-summary-state-ok': {
        readonly zh: "可用";
        readonly en: "available";
    };
    readonly 'balance-summary-state-off': {
        readonly zh: "不可用";
        readonly en: "unavailable";
    };
    readonly 'balance-summary-fail': {
        readonly zh: "DeepSeek 余额 · 查询失败";
        readonly en: "DeepSeek balance · query failed";
    };
    readonly 'balance-currency': {
        readonly zh: "{{currency}} 总额 ¥{{total}} · 赠送 ¥{{granted}} · 充值 ¥{{toppedUp}}";
        readonly en: "{{currency}} total ¥{{total}} · granted ¥{{granted}} · topped up ¥{{toppedUp}}";
    };
    readonly 'balance-no-key': {
        readonly zh: "未配置 DeepSeek API key（DEEPSEEK_API_KEY）";
        readonly en: "No DeepSeek API key configured (DEEPSEEK_API_KEY)";
    };
    readonly 'balance-unauthorized': {
        readonly zh: "认证失败——key 无效或已被撤销";
        readonly en: "Authentication failed — the key is invalid or revoked";
    };
    readonly 'balance-network-error': {
        readonly zh: "网络错误或请求超时";
        readonly en: "Network error or request timeout";
    };
    readonly 'balance-http-error': {
        readonly zh: "余额接口返回 HTTP {{status}}";
        readonly en: "Balance endpoint returned HTTP {{status}}";
    };
    readonly 'balance-invalid': {
        readonly zh: "余额接口响应格式异常";
        readonly en: "Unexpected balance endpoint response";
    };
    readonly 'balance-fail-hint': {
        readonly zh: "仅 DeepSeek 官方 API key 可查询；/login 可查看凭据状态";
        readonly en: "Only a DeepSeek official API key can be queried; /login shows credential status";
    };
    readonly 'balance-hover-tokens': {
        readonly zh: "本会话 tokens {{input}} in → {{output}} out · ≈¥{{cost}}（{{peakName}} ¥{{peak}} / {{idleName}} ¥{{idle}}）";
        readonly en: "Session tokens {{input}} in → {{output}} out · ≈¥{{cost}} ({{peakName}} ¥{{peak}} / {{idleName}} ¥{{idle}})";
    };
    readonly 'balance-current-rate': {
        readonly zh: "当前时段：{{name}} · 输入 ¥{{input}}/百万 · 输出 ¥{{output}}/百万";
        readonly en: "Current window: {{name}} · input ¥{{input}}/M · output ¥{{output}}/M";
    };
    readonly 'balance-refresh': {
        readonly zh: "点击刷新";
        readonly en: "click to refresh";
    };
    readonly 'balance-retry': {
        readonly zh: "点击重试";
        readonly en: "click to retry";
    };
    readonly 'balance-close': {
        readonly zh: "关闭";
        readonly en: "dismiss";
    };
    readonly 'balance-hint': {
        readonly zh: "余额查询免费 · 以 DeepSeek 平台为准";
        readonly en: "balance queries are free · authoritative on the DeepSeek platform";
    };
    readonly 'doctor-example-config': {
        readonly zh: "示例配置  {{path}}";
        readonly en: "Example config  {{path}}";
    };
    readonly 'doctor-user-config': {
        readonly zh: "用户配置  {{path}}";
        readonly en: "User config  {{path}}";
    };
    readonly 'doctor-launch-hint': {
        readonly zh: "启动方式  dsh-tui.cmd / dsh --profile dsh-tui";
        readonly en: "Launch      dsh-tui.cmd / dsh --profile dsh-tui";
    };
    readonly 'doctor-route-hint': {
        readonly zh: "模型路由  由 cordis.yml 的 llm-deepseek 段决定（/model 仅提示重启生效）";
        readonly en: "Model route  set by the llm-deepseek block in cordis.yml (/model only hints at restart)";
    };
    readonly 'export-failed': {
        readonly zh: "导出失败（无法写入工作目录）";
        readonly en: "Export failed (cannot write to working directory)";
    };
    readonly 'export-saved': {
        readonly zh: "已导出: {{target}}（文件位于当前工作区，若工作区在同步/共享目录请注意清理）";
        readonly en: "Exported: {{target}} (the file lives in the current workspace — clean it up promptly if the workspace is synced or shared)";
    };
    readonly 'agentsmd-create-failed': {
        readonly zh: "创建 AGENTS.md 失败";
        readonly en: "Failed to create AGENTS.md";
    };
    readonly 'agentsmd-exists': {
        readonly zh: "AGENTS.md 已存在，未覆盖";
        readonly en: "AGENTS.md already exists, not overwritten";
    };
    readonly 'agentsmd-created': {
        readonly zh: "已创建 {{result}}";
        readonly en: "Created {{result}}";
    };
    readonly 'login-api-key': {
        readonly zh: "API key: {{status}}";
        readonly en: "API key: {{status}}";
    };
    readonly 'login-key-configured': {
        readonly zh: "已配置（{{ref}}）";
        readonly en: "configured ({{ref}})";
    };
    readonly 'login-key-missing': {
        readonly zh: "未配置（DEEPSEEK_API_KEY）";
        readonly en: "not configured (DEEPSEEK_API_KEY)";
    };
    readonly 'login-credentials-unavailable': {
        readonly zh: "无法检查（credentials service 不可用）";
        readonly en: "unavailable (credentials service unavailable)";
    };
    readonly 'login-credential-source': {
        readonly zh: "凭据来源: {{source}}";
        readonly en: "Credential source: {{source}}";
    };
    readonly 'login-source-none': {
        readonly zh: "无";
        readonly en: "none";
    };
    readonly 'login-credential-storage': {
        readonly zh: "凭据存储: {{mode}}";
        readonly en: "Credential storage: {{mode}}";
    };
    readonly 'login-storage-writable': {
        readonly zh: "可写";
        readonly en: "writable";
    };
    readonly 'login-storage-read-only': {
        readonly zh: "只读";
        readonly en: "read-only";
    };
    readonly 'login-base-url': {
        readonly zh: "Base URL: {{url}}";
        readonly en: "Base URL: {{url}}";
    };
    readonly 'login-official-endpoint': {
        readonly zh: "官方端点";
        readonly en: "official endpoint";
    };
    readonly 'login-logout-hint': {
        readonly zh: "使用 /provider 管理 DSH 凭据；若来源为 env，请删除对应环境变量并重启 dsh-tui";
        readonly en: "Manage DSH credentials with /provider; for env sources, remove the corresponding environment variable and restart dsh-tui";
    };
    readonly 'login-oauth-heading': {
        readonly zh: "订阅账号（OAuth）:";
        readonly en: "Subscriptions (OAuth):";
    };
    readonly 'login-oauth-row': {
        readonly zh: "  {{provider}} — {{state}}";
        readonly en: "  {{provider}} — {{state}}";
    };
    readonly 'login-oauth-in': {
        readonly zh: "已登录 · 令牌到期 {{time}}";
        readonly en: "signed in · token expires {{time}}";
    };
    readonly 'login-oauth-expired': {
        readonly zh: "已登录但令牌已过期，重新登录可恢复";
        readonly en: "signed in but the token expired — sign in again to restore";
    };
    readonly 'login-oauth-signed-out': {
        readonly zh: "未登录";
        readonly en: "not signed in";
    };
    readonly 'login-oauth-hint': {
        readonly zh: "  登录/登出：/provider 订阅账号登录，或 /auth login <provider>";
        readonly en: "  Sign in/out: /provider subscription sign-in, or /auth login <provider>";
    };
    readonly 'permission-policy-hint': {
        readonly zh: "DSH 权限策略由 fs-policy / bash-sandbox 配置决定（当前 leaf：workspace 内读写、写入需已读文件）。";
        readonly en: "DSH permission policy is set by fs-policy / bash-sandbox config (current leaf: read/write in workspace, writes need a prior read).";
    };
    readonly 'permission-approval-hint': {
        readonly zh: "审批通道已挂载：命令申请权限提升（sandbox_permissions）时弹出审批条，Yes 放行一次、No / Esc 拒绝。";
        readonly en: "The approval channel is mounted: sandbox escalations (sandbox_permissions) raise an approval bar — Yes allows once, No / Esc rejects.";
    };
    readonly 'permission-root-hint': {
        readonly zh: "当前文件系统策略以工作目录为根：{{cwd}}";
        readonly en: "Current filesystem policy is rooted at the working directory: {{cwd}}";
    };
    readonly 'permission-path-hint': {
        readonly zh: "模型工具相对路径均解析自该目录；跨目录访问由 fs-policy 拦截。";
        readonly en: "Relative paths of model tools resolve from this directory; cross-directory access is blocked by fs-policy.";
    };
    readonly 'permission-current': {
        readonly zh: "当前预设  {{name}}";
        readonly en: "Current preset  {{name}}";
    };
    readonly 'permission-roster-unavailable': {
        readonly zh: "权限预设名册不可用";
        readonly en: "Permission preset roster unavailable";
    };
    readonly 'permission-picker-title': {
        readonly zh: "权限预设";
        readonly en: "Permission preset";
    };
    readonly 'permission-preset-readonly': {
        readonly zh: "只读";
        readonly en: "Read-only";
    };
    readonly 'permission-preset-readonly-desc': {
        readonly zh: "会话只读：不写文件、不执行命令";
        readonly en: "Read-only session: no file writes, no commands";
    };
    readonly 'permission-preset-workspace-write': {
        readonly zh: "工作区读写";
        readonly en: "Workspace read/write";
    };
    readonly 'permission-preset-workspace-write-desc': {
        readonly zh: "工作区内读写；写入需先读该文件";
        readonly en: "Read/write inside the workspace; writes need a prior read";
    };
    readonly 'permission-preset-full-access': {
        readonly zh: "完全访问";
        readonly en: "Full access";
    };
    readonly 'permission-preset-full-access-desc': {
        readonly zh: "不受限读写，无需审批";
        readonly en: "Unrestricted access, no approvals";
    };
    readonly 'plan-picker-title': {
        readonly zh: "计划模式";
        readonly en: "Plan mode";
    };
    readonly 'plan-mode-on': {
        readonly zh: "开启";
        readonly en: "On";
    };
    readonly 'plan-mode-on-desc': {
        readonly zh: "进入计划模式：只读，先规划后动手";
        readonly en: "Enter plan mode: read-only, plan before acting";
    };
    readonly 'plan-mode-off': {
        readonly zh: "关闭";
        readonly en: "Off";
    };
    readonly 'plan-mode-off-desc': {
        readonly zh: "退出计划模式，恢复正常执行";
        readonly en: "Exit plan mode, back to normal execution";
    };
    readonly 'hooks-not-mounted': {
        readonly zh: "DSH hooks（dsh-hooks-claude / dsh-hooks-codex）未在本 leaf 挂载。";
        readonly en: "DSH hooks (dsh-hooks-claude / dsh-hooks-codex) are not mounted in this leaf.";
    };
    readonly 'hooks-mount-hint': {
        readonly zh: "需要时可在 cordis.yml 挂载对应 hooks 插件。";
        readonly en: "Mount the matching hooks plugin in cordis.yml when needed.";
    };
    readonly 'update-unavailable': {
        readonly zh: "当前运行方式不支持自动更新（需经 dsh --profile 启动），请在终端执行 dsh plugin --profile <name> update @deepseek-harness-tui/dsh-tui";
        readonly en: "Automatic update is unavailable in this launch mode (needs dsh --profile). Run dsh plugin --profile <name> update @deepseek-harness-tui/dsh-tui in a terminal.";
    };
    readonly 'update-working': {
        readonly zh: "当前回合仍在运行，请等待完成后再更新 TUI。";
        readonly en: "The current turn is still running. Wait for it to finish before updating the TUI.";
    };
    readonly 'update-starting': {
        readonly zh: "正在更新 @deepseek-harness-tui/dsh-tui，完成后会自动重启并恢复当前会话……";
        readonly en: "Updating @deepseek-harness-tui/dsh-tui. The TUI will restart and resume this session when finished…";
    };
    readonly 'update-available': {
        readonly zh: "发现新版本：v{{latest}}（当前 v{{current}}）· 输入 /update 更新 TUI";
        readonly en: "New version available: v{{latest}} (current v{{current}}) · type /update to update the TUI";
    };
    readonly 'update-already-latest': {
        readonly zh: "当前已是最新版本（v{{current}}）。";
        readonly en: "Already on the latest version (v{{current}}).";
    };
    readonly 'update-check-failed': {
        readonly zh: "无法确认新版本（网络或 registry 不可达），已尝试直接更新……";
        readonly en: "Could not confirm a newer version (network or registry unreachable); attempting the update anyway…";
    };
    readonly 'update-refused-deadlock': {
        readonly zh: "已取消更新：镜像 registry 目前只能装到 v{{latest}}，而该版本在旧全局启动器的 patch 下会启动死锁（#183/#307）；官方最新为 v{{authoritative}}，待镜像同步后再 /update。";
        readonly en: "Update cancelled: the mirror registry can only serve v{{latest}}, which deadlocks boot under older global-launcher patches (#183/#307); official latest is v{{authoritative}} — retry /update after the mirror syncs.";
    };
    readonly 'update-mirror-lag': {
        readonly zh: "镜像 registry 滞后：本次安装 v{{latest}}；官方最新 v{{authoritative}}，镜像同步后可再 /update。";
        readonly en: "Mirror registry lag: installing v{{latest}} now; official latest is v{{authoritative}} — run /update again once the mirror syncs.";
    };
    readonly 'update-standalone-available': {
        readonly zh: "发现便携包新版本：v{{latest}}（当前 v{{current}}）· 输入 /update 自动更新";
        readonly en: "New standalone version available: v{{latest}} (current v{{current}}) · type /update to update";
    };
    readonly 'update-standalone-no-checksum': {
        readonly zh: "该版本未发布 SHA256 校验和，更新包完整性无法验证";
        readonly en: "this release publishes no SHA256 checksums; the update payload cannot be integrity-verified";
    };
    readonly 'update-standalone-starting': {
        readonly zh: "正在下载便携包新版本并自动替换，完成后会自动重启并恢复当前会话……";
        readonly en: "Downloading and replacing standalone binary. The TUI will restart and resume this session when finished…";
    };
    readonly 'reload-header': {
        readonly zh: "已重读偏好文件：";
        readonly en: "Preferences reloaded:";
    };
    readonly 'reload-applied': {
        readonly zh: "{{kind}}  {{from}} → {{to}}（已应用）";
        readonly en: "{{kind}}  {{from}} → {{to}} (applied)";
    };
    readonly 'reload-unchanged': {
        readonly zh: "{{kind}}  无变化";
        readonly en: "{{kind}}  unchanged";
    };
    readonly 'reload-skipped-env': {
        readonly zh: "{{kind}}  跳过：环境变量优先";
        readonly en: "{{kind}}  skipped: env override wins";
    };
    readonly 'reload-skipped-config': {
        readonly zh: "{{kind}}  跳过：显式配置优先";
        readonly en: "{{kind}}  skipped: explicit config wins";
    };
    readonly 'reload-skipped-invalid': {
        readonly zh: "{{kind}}  跳过：文件缺失或无效";
        readonly en: "{{kind}}  skipped: missing or invalid file";
    };
    readonly 'reload-footer': {
        readonly zh: "提示：settings.yaml / cordis.patch.yml 由 watcher 自动热重载；cordis.yml 根配置改动需 /restart";
        readonly en: "Note: settings.yaml / cordis.patch.yml hot-reload via watchers; cordis.yml root config changes need /restart";
    };
    readonly 'reload-kind-theme': {
        readonly zh: "主题";
        readonly en: "theme";
    };
    readonly 'reload-kind-lang': {
        readonly zh: "语言";
        readonly en: "language";
    };
    readonly 'reload-kind-preset': {
        readonly zh: "预设";
        readonly en: "preset";
    };
    readonly 'reload-kind-model': {
        readonly zh: "模型";
        readonly en: "model";
    };
    readonly 'reload-kind-activity': {
        readonly zh: "活动指示";
        readonly en: "activity";
    };
    readonly 'restart-starting': {
        readonly zh: "正在重启 dsh-tui，完成后自动恢复当前会话……";
        readonly en: "Restarting dsh-tui. The session resumes when it comes back…";
    };
    readonly 'restart-unavailable': {
        readonly zh: "当前运行方式不支持进程内重启（未挂载重启通道）。";
        readonly en: "Restart is unavailable in this launch mode (no restart channel mounted).";
    };
    readonly 'streaming-folded': {
        readonly zh: "…（前 {{count}} 字符流式期间已折叠，落定后完整显示）";
        readonly en: "…(first {{count}} chars folded while streaming; full text renders once the turn settles)";
    };
    readonly 'vim-on': {
        readonly zh: "vim 模式已开启（Esc 切 normal，i/a/o 回 insert）";
        readonly en: "vim mode on (Esc = normal, i/a/o = insert)";
    };
    readonly 'vim-off': {
        readonly zh: "vim 模式已关闭";
        readonly en: "vim mode off";
    };
    readonly 'terminal-setup-hint': {
        readonly zh: "推荐 Windows Terminal（≥110 列、等宽字体、TrueColor）。";
        readonly en: "Recommended: Windows Terminal (≥110 columns, monospace, TrueColor).";
    };
    readonly 'terminal-paste-hint': {
        readonly zh: "{{mod}}V 或 Alt+V 粘贴文本、文件路径或图片；Ctrl+Shift+V 终端原生粘贴；右键粘贴同样可用；快捷键可在 /settings 修改。";
        readonly en: "{{mod}}V or Alt+V pastes text, file paths, or images; Ctrl+Shift+V is native terminal paste; right-click paste also works; remappable via /settings.";
    };
    readonly 'connect-none': {
        readonly zh: "当前环境未提供远程连接服务。";
        readonly en: "No remote connection service is available in this environment.";
    };
    readonly 'theme-switch-failed': {
        readonly zh: "主题「{{name}}」切换失败（无法写入 ~/.dsh-tui/theme.json）";
        readonly en: "Theme \"{{name}}\" switch failed (cannot write ~/.dsh-tui/theme.json)";
    };
    readonly 'interrupt-delivered': {
        readonly zh: "已打断当前回合，{{n}} 条消息立即处理";
        readonly en: "Interrupted current turn, {{n}} messages processed immediately";
    };
    readonly 'btw-usage': {
        readonly zh: "用法：/btw <问题> —— 不打断当前对话的快速侧问";
        readonly en: "Usage: /btw <question> — quick side question without interrupting the conversation";
    };
    readonly 'btw-answering': {
        readonly zh: "思考中…";
        readonly en: "Answering…";
    };
    readonly 'btw-hint-loading': {
        readonly zh: "Esc 取消";
        readonly en: "Esc cancel";
    };
    readonly 'btw-hint-done': {
        readonly zh: "↑/↓ 滚动 · Space/Enter/Esc 关闭 · c 复制";
        readonly en: "↑/↓ scroll · Space/Enter/Esc dismiss · c copy";
    };
    readonly 'btw-llm-unavailable': {
        readonly zh: "侧问不可用（llm 服务未挂载）";
        readonly en: "Side question unavailable (llm service not mounted)";
    };
    readonly 'recap-llm-unavailable': {
        readonly zh: "recap 不可用（llm 服务未挂载）";
        readonly en: "Recap unavailable (llm service not mounted)";
    };
    readonly 'recap-no-activity': {
        readonly zh: "会话还没有可总结的活动";
        readonly en: "No session activity to recap yet";
    };
    readonly 'recap-answering': {
        readonly zh: "正在总结最近活动…";
        readonly en: "Summarizing recent activity…";
    };
    readonly 'recap-title-label': {
        readonly zh: "建议标题";
        readonly en: "Suggested title";
    };
    readonly 'recap-apply-title': {
        readonly zh: "应用";
        readonly en: "Apply";
    };
    readonly 'recap-title-applied': {
        readonly zh: "已应用";
        readonly en: "Applied";
    };
    readonly 'recap-title-applied-notify': {
        readonly zh: "已将会话标题设为「{{title}}」";
        readonly en: "Session title set to \"{{title}}\"";
    };
    readonly 'recap-hint': {
        readonly zh: "↑/↓ 滚动 · Space/Enter/Esc 关闭 · c 复制{{apply}}";
        readonly en: "↑/↓ scroll · Space/Enter/Esc dismiss · c copy{{apply}}";
    };
    readonly 'recap-auto-hint': {
        readonly zh: "点击展开查看/应用";
        readonly en: "Click to expand & apply";
    };
    readonly 'recap-auto-close': {
        readonly zh: "关闭";
        readonly en: "Dismiss";
    };
    readonly 'recap-auto-line': {
        readonly zh: "回顾：{{summary}}";
        readonly en: "Recap: {{summary}}";
    };
    readonly 'recap-panel-title': {
        readonly zh: "会话回顾";
        readonly en: "Session recap";
    };
    readonly 'recap-panel-subtitle': {
        readonly zh: "最近活动的快速复盘";
        readonly en: "A quick recap of recent activity";
    };
    readonly 'color-current': {
        readonly zh: "当前会话颜色  {{name}}";
        readonly en: "Current session color  {{name}}";
    };
    readonly 'color-current-none': {
        readonly zh: "当前会话未设置颜色（用主题默认）";
        readonly en: "No session color set (theme default)";
    };
    readonly 'color-usage': {
        readonly zh: "用法：/color <{{list}}|reset> —— 颜色按会话保存，resume 后仍在";
        readonly en: "Usage: /color <{{list}}|reset> — per-session, survives resume";
    };
    readonly 'color-reset': {
        readonly zh: "已清除会话颜色，恢复主题默认";
        readonly en: "Session color cleared — back to the theme default";
    };
    readonly 'color-unknown': {
        readonly zh: "未知颜色「{{name}}」· 可选：{{list}}";
        readonly en: "Unknown color \"{{name}}\" · available: {{list}}";
    };
    readonly 'color-set': {
        readonly zh: "会话颜色已设为 {{name}}";
        readonly en: "Session color set to {{name}}";
    };
    readonly 'exit-press-again': {
        readonly zh: "再次按 Ctrl+C 退出";
        readonly en: "Press Ctrl+C again to exit";
    };
    readonly 'esc-again-rewind': {
        readonly zh: "再次按 Esc 时间回溯";
        readonly en: "Press Esc again to rewind";
    };
    readonly 'esc-again-clear': {
        readonly zh: "再次按 Esc 清空";
        readonly en: "Press Esc again to clear";
    };
    readonly 'new-session-started': {
        readonly zh: "已新建会话";
        readonly en: "New session started";
    };
    readonly 'command-not-found': {
        readonly zh: "/{{name}}：没有这个命令";
        readonly en: "/{{name}}: no such command";
    };
    readonly 'command-images-unsupported': {
        readonly zh: "/{{name}} 不接受图片；草稿已保留";
        readonly en: "/{{name}} does not accept images; the draft was preserved";
    };
    readonly 'command-images-runtime-unsupported': {
        readonly zh: "/{{name}}：当前命令运行时不支持图片；草稿已保留";
        readonly en: "/{{name}}: this command runtime cannot accept images; the draft was preserved";
    };
    readonly 'command-images-limit': {
        readonly zh: "/{{name}}：图片数量或总大小超过当前 profile 限制；草稿已保留";
        readonly en: "/{{name}}: the image batch exceeds this profile's limits; the draft was preserved";
    };
    readonly 'command-images-missing': {
        readonly zh: "/{{name}}：图片已失效或不可读取（{{paths}}）；草稿已保留";
        readonly en: "/{{name}}: images are stale or unreadable ({{paths}}); the draft was preserved";
    };
    readonly 'command-running': {
        readonly zh: "命令仍在执行，请等待本次结果";
        readonly en: "The command is still running; wait for this attempt to settle";
    };
    readonly 'command-changed': {
        readonly zh: "/{{name}} 在图片准备期间发生变化；未执行，草稿已保留";
        readonly en: "/{{name}} changed while its images were prepared; it was not run and the draft was preserved";
    };
    readonly 'shell-images-unsupported': {
        readonly zh: "Shell 命令不接受图片；草稿已保留";
        readonly en: "Shell commands do not accept images; the draft was preserved";
    };
    readonly 'thinking-toggled': {
        readonly zh: "思考过程：{{state}}";
        readonly en: "Thinking display: {{state}}";
    };
    readonly 'thinking-on': {
        readonly zh: "显示";
        readonly en: "shown";
    };
    readonly 'thinking-off': {
        readonly zh: "隐藏";
        readonly en: "hidden";
    };
    readonly 'tokens-usage': {
        readonly zh: "Tokens：{{in}} 输入 · {{out}} 输出";
        readonly en: "Tokens: {{in}} in · {{out}} out";
    };
    readonly 'tokens-usage-context': {
        readonly zh: "{{usage}} · 上下文 {{percent}}%";
        readonly en: "{{usage}} · {{percent}}% of context";
    };
    readonly 'update-aborted-no-profile': {
        readonly zh: "dsh-tui 更新中止：未解析到 dsh profile。";
        readonly en: "dsh-tui update aborted: no dsh profile resolved.";
    };
    readonly 'update-launcher-align-unknown': {
        readonly zh: "Profile 已更新到 v{{version}}。如果你平时使用全局 dsh-tui 命令启动，请同步更新全局启动器：\n  npm install -g --legacy-peer-deps @deepseek-harness-tui/dsh-tui@{{version}}\n（--legacy-peer-deps 可绕过 npm 12 的 peer 解析崩溃，全局启动器是瘦壳，跳过全局 peer 解析是安全的）";
        readonly en: "The profile is now v{{version}}. If you normally launch with the global dsh-tui command, align the global launcher too:\n  npm install -g --legacy-peer-deps @deepseek-harness-tui/dsh-tui@{{version}}\n(--legacy-peer-deps works around an npm 12 peer-resolution crash; the global launcher is a thin shim, so skipping global peer resolution is safe.)";
    };
    readonly 'update-launcher-outdated': {
        readonly zh: "Profile 已更新到 v{{profile}}，但全局启动器仍是 v{{launcher}}。请同步更新：\n  npm install -g --legacy-peer-deps @deepseek-harness-tui/dsh-tui@{{profile}}\n（--legacy-peer-deps 可绕过 npm 12 的 peer 解析崩溃，见 #459）";
        readonly en: "The profile is now v{{profile}}, but the global launcher is still v{{launcher}}. Align it with:\n  npm install -g --legacy-peer-deps @deepseek-harness-tui/dsh-tui@{{profile}}\n(--legacy-peer-deps works around an npm 12 peer-resolution crash, see #459.)";
    };
    readonly 'activity-ctx-warn': {
        readonly zh: "⚠ 上下文";
        readonly en: "⚠ ctx ";
    };
    readonly 'activity-random-each-preset': {
        readonly zh: "每次随机一个预设";
        readonly en: "random preset each time";
    };
    readonly 'preset-default-tag': {
        readonly zh: "（默认）";
        readonly en: " (default)";
    };
    readonly 'preset-broken-tag': {
        readonly zh: "（无法加载）";
        readonly en: " (failed to load)";
    };
    readonly 'effort-unavailable': {
        readonly zh: "推理等级切换不可用（llm 服务未挂载）";
        readonly en: "Reasoning effort switching unavailable (llm service not mounted)";
    };
    readonly 'effort-read-failed': {
        readonly zh: "推理等级读取失败 · {{error}}";
        readonly en: "Failed to read reasoning efforts · {{error}}";
    };
    readonly 'effort-single-tier': {
        readonly zh: "当前模型只有一档推理等级（{{name}}）";
        readonly en: "Current model has a single reasoning effort ({{name}})";
    };
    readonly 'effort-unsupported': {
        readonly zh: "当前模型不支持推理等级切换";
        readonly en: "Current model does not support reasoning effort switching";
    };
    readonly 'effort-switched': {
        readonly zh: "推理强度 → {{name}}";
        readonly en: "Reasoning effort → {{name}}";
    };
    readonly 'effort-invalid': {
        readonly zh: "未知推理等级 {{id}}（当前模型可选：{{ids}}）";
        readonly en: "Unknown reasoning effort {{id}} (this model offers: {{ids}})";
    };
    readonly 'effort-current': {
        readonly zh: "当前推理强度 {{name}}";
        readonly en: "Current reasoning effort {{name}}";
    };
    readonly 'effort-usage': {
        readonly zh: "用法：/effort（滑杆）| /effort <id> | /effort status";
        readonly en: "Usage: /effort (slider) | /effort <id> | /effort status";
    };
    readonly 'mode-switched': {
        readonly zh: "模式 → {{name}}";
        readonly en: "Mode → {{name}}";
    };
    readonly 'mode-default': {
        readonly zh: "默认";
        readonly en: "default";
    };
    readonly 'mode-plan': {
        readonly zh: "计划模式";
        readonly en: "plan mode";
    };
    readonly 'mode-full': {
        readonly zh: "完全访问";
        readonly en: "full access";
    };
    readonly 'mode-plan-unavailable': {
        readonly zh: "当前 preset 未注册 /plan 命令，无法切换计划模式";
        readonly en: "The active preset does not register /plan; cannot toggle plan mode";
    };
    readonly 'mode-permission-unregistered': {
        readonly zh: "当前 preset 未注册 /permission 命令，无法切换权限模式";
        readonly en: "The active preset does not register /permission; cannot switch the permission mode";
    };
    readonly 'mode-permission-invoke-failed': {
        readonly zh: "/permission 切换失败，请重试或查看日志";
        readonly en: "/permission switch failed; retry or check the logs";
    };
    readonly 'mode-permission-unconfirmed': {
        readonly zh: "权限切换未被 DSH 确认，模式未改变";
        readonly en: "The permission switch was not confirmed by DSH; the mode is unchanged";
    };
    readonly 'mode-permission-no-canonical': {
        readonly zh: "模式「{{name}}」的 sandbox/approval 组合没有对应权限预设，无法安全切换";
        readonly en: "Mode \"{{name}}\" has no matching permission preset for its sandbox/approval combo; cannot switch safely";
    };
    readonly 'cmd-desc-permission': {
        readonly zh: "切换权限预设（沙箱模式 + 审批策略）";
        readonly en: "Switch the permission preset (sandbox mode + approval policy)";
    };
    readonly 'logo-tagline': {
        readonly zh: "探索未至之境！";
        readonly en: "Explore the uncharted!";
    };
    readonly 'logo-tip-prefix': {
        readonly zh: "提示：";
        readonly en: "Tip: ";
    };
    readonly 'logo-tip-more': {
        readonly zh: "更多技巧";
        readonly en: "more tips";
    };
    readonly 'logo-drift-newer': {
        readonly zh: "dsh 引擎为 {{installed}}，比本界面验证过的 {{validated}} 新，可能出现兼容问题；求稳可执行 npm i -g @deepseek-ai/dsh@{{primary}} 降级，或等待 dsh-tui 适配新版。";
        readonly en: "The dsh engine ({{installed}}) is newer than the {{validated}} this UI is validated against, so issues are possible; downgrade via npm i -g @deepseek-ai/dsh@{{primary}} for stability, or wait for a dsh-tui update.";
    };
    readonly 'logo-drift-older': {
        readonly zh: "dsh 引擎为 {{installed}}，低于本界面验证过的 {{validated}}，部分功能可能不可用；建议执行 npm i -g @deepseek-ai/dsh@{{primary}} 升级。";
        readonly en: "The dsh engine ({{installed}}) is older than the {{validated}} this UI is validated against; some features may be missing. Upgrade via npm i -g @deepseek-ai/dsh@{{primary}}.";
    };
    readonly 'logo-drift-mixed': {
        readonly zh: "检测到 dsh 引擎多版本混装（{{installed}}），容易出现奇怪问题；建议执行 npm i -g @deepseek-ai/dsh@{{primary}} 统一版本。";
        readonly en: "Mixed dsh engine versions detected ({{installed}}), which can cause odd behavior; unify them via npm i -g @deepseek-ai/dsh@{{primary}}.";
    };
    readonly 'logo-drift-broken': {
        readonly zh: "dsh 引擎版本异常（{{installed}}），本界面验证过 {{validated}}；建议执行 npm i -g @deepseek-ai/dsh@{{primary}} 重装。";
        readonly en: "Unexpected dsh engine versions ({{installed}}); this UI is validated against {{validated}}. Reinstall via npm i -g @deepseek-ai/dsh@{{primary}}.";
    };
    readonly 'input-sent-after-turn': {
        readonly zh: "已发送，当前回合结束后处理";
        readonly en: "Sent, processed after the current turn";
    };
    readonly 'input-injected': {
        readonly zh: "已从编辑器发送";
        readonly en: "Sent from editor";
    };
    readonly 'input-interrupted-next': {
        readonly zh: "已插话 · 下一步立即处理";
        readonly en: "Interrupted · processed next";
    };
    readonly 'input-queued-after-turn': {
        readonly zh: "已排队 · 回合结束后处理";
        readonly en: "Queued · processed after the turn";
    };
    readonly 'input-cannot-retract': {
        readonly zh: "无法撤回：消息可能已被处理，或当前版本不支持";
        readonly en: "Cannot retract: the message may already be processed, or this version doesn't support it";
    };
    readonly 'input-retracted': {
        readonly zh: "已撤回，可编辑后重新发送";
        readonly en: "Retracted, editable and resendable";
    };
    readonly 'input-empty': {
        readonly zh: "输入为空，没有可发送的内容";
        readonly en: "Empty input, nothing to send";
    };
    readonly 'input-interrupt-immediate': {
        readonly zh: "已打断当前回合，正在立即处理";
        readonly en: "Interrupted current turn, processing immediately";
    };
    readonly 'input-clipboard-empty': {
        readonly zh: "剪贴板为空";
        readonly en: "Clipboard is empty";
    };
    readonly 'input-editor-unavailable': {
        readonly zh: "错误：未配置编辑器。请设置 $VISUAL 或 $EDITOR 环境变量。";
        readonly en: "Error: No editor configured. Set $VISUAL or $EDITOR environment variable.";
    };
    readonly 'input-editor-failed': {
        readonly zh: "外部编辑器失败：{{name}}";
        readonly en: "External editor failed: {{name}}";
    };
    readonly 'input-clipboard-read-failed': {
        readonly zh: "读取剪贴板失败";
        readonly en: "Failed to read the clipboard";
    };
    readonly 'input-clipboard-unavailable': {
        readonly zh: "无法读取剪贴板：没有可用的 wl-paste / xclip / xsel（未安装或会话不可连接）";
        readonly en: "Cannot read clipboard: no usable wl-paste / xclip / xsel (not installed or session unreachable)";
    };
    readonly 'input-image-pasted': {
        readonly zh: "已粘贴图片 {{token}}";
        readonly en: "Pasted image {{token}}";
    };
    readonly 'input-image-paste-failed': {
        readonly zh: "粘贴图片失败：{{err}}";
        readonly en: "Could not paste image: {{err}}";
    };
    readonly 'input-image-paste-limit': {
        readonly zh: "图片数量超过当前配置的单条消息上限";
        readonly en: "Image count exceeds the per-message limit for this profile";
    };
    readonly 'input-image-format-unsupported': {
        readonly zh: "剪贴板图片格式不受支持；请使用 PNG、JPEG、WebP 或 GIF";
        readonly en: "Clipboard image format is unsupported; use PNG, JPEG, WebP, or GIF";
    };
    readonly 'input-pending-steer-label': {
        readonly zh: "插话 · 下一步送达";
        readonly en: "Steer · delivered next";
    };
    readonly 'input-pending-queue-label': {
        readonly zh: "排队 · 回合结束后送达";
        readonly en: "Queued · delivered after the turn";
    };
    readonly 'input-pending-actions-hint': {
        readonly zh: "撤回 · Esc 打断并立即发送";
        readonly en: "Retract · Esc interrupts and sends immediately";
    };
    readonly 'input-fold-stats': {
        readonly zh: "{{lines}} 行 · {{chars}} 字";
        readonly en: "{{lines}} lines · {{chars}} chars";
    };
    readonly 'input-fold-hover': {
        readonly zh: "悬停查看";
        readonly en: "hover to peek";
    };
    readonly 'input-fold-peek-footer': {
        readonly zh: "… 共 {{lines}} 行 · 点击展开编辑";
        readonly en: "… {{lines}} lines total · click to edit";
    };
    readonly 'input-expand-editor-title': {
        readonly zh: "草稿编辑";
        readonly en: "Draft editor";
    };
    readonly 'input-expand-editor-position': {
        readonly zh: "行 {{line}} · 列 {{col}}";
        readonly en: "Ln {{line}}, Col {{col}}";
    };
    readonly 'input-expand-editor-scroll': {
        readonly zh: "滚轮翻动 · 光标行自动跟随";
        readonly en: "wheel scrolls · caret row follows";
    };
    readonly 'input-expand-editor-send': {
        readonly zh: "发送";
        readonly en: "Send";
    };
    readonly 'input-expand-editor-collapse': {
        readonly zh: "收起";
        readonly en: "Collapse";
    };
    readonly 'input-expand-editor-hint-send': {
        readonly zh: "Ctrl+Enter 发送";
        readonly en: "Ctrl+Enter sends";
    };
    readonly 'input-expand-editor-hint-collapse': {
        readonly zh: "Esc 收起";
        readonly en: "Esc collapses";
    };
    readonly 'tool-tip-started': {
        readonly zh: "开始 {{time}}";
        readonly en: "started {{time}}";
    };
    readonly 'tool-tip-finished': {
        readonly zh: "结束 {{time}}";
        readonly en: "finished {{time}}";
    };
    readonly 'tool-tip-failed': {
        readonly zh: "失败 {{time}}";
        readonly en: "failed {{time}}";
    };
    readonly 'tool-tip-exit': {
        readonly zh: "退出码 {{code}}";
        readonly en: "exit {{code}}";
    };
    readonly 'tool-tip-signal': {
        readonly zh: "信号 {{name}}";
        readonly en: "signal {{name}}";
    };
    readonly 'sugg-commands-title': {
        readonly zh: "命令";
        readonly en: "commands";
    };
    readonly 'sugg-files-title': {
        readonly zh: "文件";
        readonly en: "files";
    };
    readonly 'sugg-count': {
        readonly zh: "共 {{n}} 项";
        readonly en: "{{n}} items";
    };
    readonly 'sugg-more-above': {
        readonly zh: "↑{{n}}";
        readonly en: "↑{{n}}";
    };
    readonly 'sugg-more-below': {
        readonly zh: "↓{{n}}";
        readonly en: "↓{{n}}";
    };
    readonly 'sugg-status-desc': {
        readonly zh: "显示当前选择";
        readonly en: "Show the current choice";
    };
    readonly 'sugg-lang-zh-desc': {
        readonly zh: "切换界面语言到中文";
        readonly en: "Switch the UI language to Chinese";
    };
    readonly 'sugg-lang-en-desc': {
        readonly zh: "切换界面语言到英文";
        readonly en: "Switch the UI language to English";
    };
    readonly 'sugg-theme-auto-desc': {
        readonly zh: "跟随终端背景自动切换";
        readonly en: "Follow the terminal background";
    };
    readonly 'sugg-theme-builtin-desc': {
        readonly zh: "内置主题";
        readonly en: "Built-in theme";
    };
    readonly 'sugg-theme-user-desc': {
        readonly zh: "用户主题（{{base}} 基底）";
        readonly en: "User theme ({{base}} base)";
    };
    readonly 'sugg-theme-plugin-desc': {
        readonly zh: "插件主题（{{base}} 基底）";
        readonly en: "Plugin theme ({{base}} base)";
    };
    readonly 'sugg-effort-level-desc': {
        readonly zh: "思考强度档位";
        readonly en: "Reasoning effort level";
    };
    readonly 'sugg-activity-frames-desc': {
        readonly zh: "列出或切换动画帧预设";
        readonly en: "List or switch frame presets";
    };
    readonly 'sugg-activity-frame-desc': {
        readonly zh: "动画帧预设";
        readonly en: "Animation frame preset";
    };
    readonly 'sugg-color-reset-desc': {
        readonly zh: "清除会话颜色，恢复主题默认";
        readonly en: "Clear the session color";
    };
    readonly 'sugg-color-name-desc': {
        readonly zh: "会话强调色";
        readonly en: "Session accent color";
    };
    readonly 'settings-fullscreen-restart': {
        readonly zh: "全屏设置已保存，重启 dsh-tui 后生效";
        readonly en: "Fullscreen preference saved — restart dsh-tui to apply";
    };
    readonly 'settings-terminal-images-restart': {
        readonly zh: "图片预览设置已保存，使用 /restart 重启 TUI 后生效";
        readonly en: "Image preview preference saved — use /restart to apply";
    };
    readonly 'settings-fullscreen-migrated': {
        readonly zh: "全屏已是出厂默认（已清除更新前的 inline 选择）；偏好 inline 可在 /settings 改回";
        readonly en: "Fullscreen is now the factory default (pre-update inline choice cleared); prefer inline? Switch back in /settings";
    };
    readonly 'help-for-commands': {
        readonly zh: "/ 查看命令";
        readonly en: "/ for commands";
    };
    readonly 'help-this-help': {
        readonly zh: "? 查看本帮助";
        readonly en: "? for this help";
    };
    readonly 'help-verbose-output': {
        readonly zh: "{{mod}}o 详细输出";
        readonly en: "{{mod}}o for verbose output";
    };
    readonly 'help-open-trajectory': {
        readonly zh: "{{mod}}t 打开会话轨迹";
        readonly en: "{{mod}}t to open trajectory";
    };
    readonly 'help-search-history': {
        readonly zh: "{{mod}}r 搜索历史";
        readonly en: "{{mod}}r to search history";
    };
    readonly 'help-interrupt': {
        readonly zh: "ctrl+c 打断";
        readonly en: "ctrl+c to interrupt";
    };
    readonly 'help-exit': {
        readonly zh: "ctrl+d 退出";
        readonly en: "ctrl+d to exit";
    };
    readonly 'help-redraw': {
        readonly zh: "{{mod}}l 重绘";
        readonly en: "{{mod}}l to redraw";
    };
    readonly 'help-clear-input': {
        readonly zh: "esc 清空输入";
        readonly en: "esc to clear input";
    };
    readonly 'help-history-nav': {
        readonly zh: "↑/↓ 历史";
        readonly en: "↑/↓ for history";
    };
    readonly 'help-move-cursor': {
        readonly zh: "←/→ 移动光标";
        readonly en: "←/→ to move cursor";
    };
    readonly 'help-word-jumps': {
        readonly zh: "{{mod}}←/→ 按词跳转";
        readonly en: "{{mod}}←/→ for word jumps";
    };
    readonly 'help-complete-command': {
        readonly zh: "tab 补全命令";
        readonly en: "tab to complete command";
    };
    readonly 'help-cycle-mode': {
        readonly zh: "shift+tab 切换模式";
        readonly en: "shift+tab to cycle mode";
    };
    readonly 'help-open-editor': {
        readonly zh: "ctrl+g 打开编辑器";
        readonly en: "ctrl+g to open editor";
    };
    readonly 'help-fold-todos': {
        readonly zh: "{{mod}}q 折叠待办";
        readonly en: "{{mod}}q to fold todos";
    };
    readonly 'goal-todo-fold-hint': {
        readonly zh: "{{mod}}q 折叠";
        readonly en: "{{mod}}q to fold";
    };
    readonly 'help-commands-title': {
        readonly zh: "命令：";
        readonly en: "commands:";
    };
    readonly 'help-scroll-hint': {
        readonly zh: "↑/↓ 滚动 · PgUp/PgDn 翻页 · Home/End 首尾 · Esc 关闭";
        readonly en: "↑/↓ scroll · PgUp/PgDn page · Home/End jump · Esc close";
    };
    readonly 'tips-title': {
        readonly zh: "使用技巧（快捷键 · 命令 · 工作流 · 个性化 · 避坑）";
        readonly en: "Usage tips (shortcuts · commands · workflow · display · gotchas)";
    };
    readonly 'tips-hint': {
        readonly zh: "↑/↓ 滚动 · Esc 关闭";
        readonly en: "↑/↓ scroll · Esc to close";
    };
    readonly 'interrupted-by-user': {
        readonly zh: "已打断 ";
        readonly en: "Interrupted ";
    };
    readonly 'interrupted-ask-next': {
        readonly zh: "· 接下来想让 DeepSeek 做什么？";
        readonly en: "· What should DeepSeek do instead?";
    };
    readonly 'load-earlier': {
        readonly zh: " ↑ 加载更早消息（会话日志完整，/export 导出全文） ";
        readonly en: " ↑ load earlier messages (full session log; /export for full text) ";
    };
    readonly 'show-previous-messages': {
        readonly zh: " ctrl+e 显示前 {{n}} 条消息 ";
        readonly en: " ctrl+e to show {{n}} previous messages ";
    };
    readonly 'resume-none-in-cwd': {
        readonly zh: "当前目录没有可恢复的历史会话";
        readonly en: "No resumable sessions in the current directory";
    };
    readonly 'resume-resumed': {
        readonly zh: "已恢复会话";
        readonly en: "Session resumed";
    };
    readonly 'resume-delete-confirm': {
        readonly zh: "删除「{{name}}」？会话日志将被永久移除。";
        readonly en: "Delete \"{{name}}\"? The session log is removed permanently.";
    };
    readonly 'resume-deleted': {
        readonly zh: "已删除会话「{{name}}」";
        readonly en: "Deleted session {{name}}";
    };
    readonly 'resume-delete-failed': {
        readonly zh: "无法删除会话「{{name}}」";
        readonly en: "Could not delete session {{name}}";
    };
    readonly 'resume-rename-placeholder': {
        readonly zh: "新的会话名称…";
        readonly en: "New session name…";
    };
    readonly 'resume-rename-failed': {
        readonly zh: "无法重命名会话「{{name}}」";
        readonly en: "Could not rename session {{name}}";
    };
    readonly 'resume-hint-delete': {
        readonly zh: "**Enter** 删除 · Esc 取消";
        readonly en: "**Enter** to delete · Esc to cancel";
    };
    readonly 'resume-hint-rename': {
        readonly zh: "**Enter** 保存 · Esc 取消";
        readonly en: "**Enter** to save · Esc to cancel";
    };
    readonly 'resume-title': {
        readonly zh: "恢复会话";
        readonly en: "Resume session";
    };
    readonly 'agentview-title': {
        readonly zh: "会话总览";
        readonly en: "Session overview";
    };
    readonly 'agentview-count-awaited': {
        readonly zh: "{{n}} 个等待输入";
        readonly en: "{{n}} awaiting input";
    };
    readonly 'agentview-count-working': {
        readonly zh: "{{n}} 个运行中";
        readonly en: "{{n}} working";
    };
    readonly 'agentview-count-completed': {
        readonly zh: "{{n}} 个已完成";
        readonly en: "{{n}} completed";
    };
    readonly 'agentview-count-failed': {
        readonly zh: "{{n}} 个失败";
        readonly en: "{{n}} failed";
    };
    readonly 'agentview-bg-notice': {
        readonly zh: "当前会话已转入后台 —— **Enter** 打开它 · **Esc** 返回它 · **Ctrl+C** 两次退出";
        readonly en: "Your conversation moved to the background — **Enter** opens it · **Esc** returns to it · **Ctrl+C** twice quits";
    };
    readonly 'agentview-current-session': {
        readonly zh: "当前会话";
        readonly en: "current session";
    };
    readonly 'agentview-untitled': {
        readonly zh: "未命名";
        readonly en: "untitled";
    };
    readonly 'agentview-summary-empty': {
        readonly zh: "输入提示词开始";
        readonly en: "send a prompt to start";
    };
    readonly 'agentview-none': {
        readonly zh: "没有会话。在下方输入任务描述并回车，派发第一个后台会话。";
        readonly en: "No sessions. Type a task below and press Enter to dispatch your first background session.";
    };
    readonly 'agentview-empty-prompt': {
        readonly zh: "派发内容不能为空";
        readonly en: "Dispatch prompt cannot be empty";
    };
    readonly 'agentview-dispatch-unavailable': {
        readonly zh: "无法派发后台会话——agent 服务不可用";
        readonly en: "Cannot dispatch a background session — the agent service is unavailable";
    };
    readonly 'agentview-dispatch-failed': {
        readonly zh: "后台会话创建失败 · {{err}}";
        readonly en: "Background session creation failed · {{err}}";
    };
    readonly 'agentview-dispatch-done': {
        readonly zh: "已派发新会话";
        readonly en: "Dispatched a new session";
    };
    readonly 'agentview-stopped': {
        readonly zh: "已停止会话";
        readonly en: "Session stopped";
    };
    readonly 'agentview-stop-failed': {
        readonly zh: "无法停止——该会话不是本 TUI 派发的后台会话";
        readonly en: "Cannot stop — this is not a background session dispatched by this TUI";
    };
    readonly 'agentview-stop-confirm': {
        readonly zh: "**Ctrl+X** 再次按下删除会话「{{name}}」，其他键取消";
        readonly en: "**Ctrl+X** again to delete \"{{name}}\", any other key cancels";
    };
    readonly 'agentview-deleted': {
        readonly zh: "已删除会话「{{name}}」";
        readonly en: "Deleted session \"{{name}}\"";
    };
    readonly 'agentview-delete-failed': {
        readonly zh: "无法删除会话「{{name}}」";
        readonly en: "Could not delete session \"{{name}}\"";
    };
    readonly 'agentview-attached': {
        readonly zh: "已切换到会话";
        readonly en: "Attached to session";
    };
    readonly 'agentview-attach-failed': {
        readonly zh: "切换失败 · {{err}}";
        readonly en: "Attach failed · {{err}}";
    };
    readonly 'agentview-current-marker': {
        readonly zh: "当前";
        readonly en: "attached";
    };
    readonly 'agentview-input-placeholder': {
        readonly zh: "输入任务并回车派发后台会话 · Shift+Enter 派发并立即切换";
        readonly en: "Type a task and press Enter to dispatch · Shift+Enter dispatch and attach";
    };
    readonly 'agentview-hint-list': {
        readonly zh: "**Enter**/→ 切换 · **Space** 预览 · **Ctrl+X** 停止（两次删除） · **Ctrl+R** 重命名 · **Esc** 退出 · **?** 帮助";
        readonly en: "**Enter**/→ attach · **Space** peek · **Ctrl+X** stop (twice: delete) · **Ctrl+R** rename · **Esc** exit · **?** help";
    };
    readonly 'agentview-hint-rename': {
        readonly zh: "**Enter** 保存 · Esc 取消";
        readonly en: "**Enter** to save · Esc to cancel";
    };
    readonly 'agentview-hint-peek': {
        readonly zh: "输入回复并按 **Enter** 发送 · **Esc** 关闭预览";
        readonly en: "Type a reply and press **Enter** to send · **Esc** close";
    };
    readonly 'agentview-reply-sent': {
        readonly zh: "已发送回复";
        readonly en: "Reply sent";
    };
    readonly 'agentview-reply-failed': {
        readonly zh: "回复发送失败 · {{err}}";
        readonly en: "Reply failed · {{err}}";
    };
    readonly 'agentview-reply-empty': {
        readonly zh: "回复内容为空";
        readonly en: "Reply is empty";
    };
    readonly 'agentview-reply-stopped': {
        readonly zh: "该会话未运行——回车切换进去后回复";
        readonly en: "This session is not running — press Enter to attach and reply";
    };
    readonly 'agentview-help-title': {
        readonly zh: "会话总览快捷键";
        readonly en: "Session overview shortcuts";
    };
    readonly 'agentview-help': {
        readonly zh: "↑/↓      移动 · PgUp/PgDn 翻页\nEnter/→  切换到选中会话（输入框有文字时：派发）；后台化打开时 **Enter** 打开当前会话\nShift+Enter  派发并立即切换\nSpace    打开/关闭预览 · 预览内可输入回复并 Enter 发送\nCtrl+X   停止会话 · 两秒内再次按下删除\nCtrl+R   重命名选中会话\nEsc      关闭预览 → 清空输入 → 退出；后台化打开时返回被转入后台的会话\nCtrl+C   清空输入 · 两次退出\n?        本帮助\n\n后台会话运行在本进程内：TUI 退出后停止，日志保留可 /resume 恢复。";
        readonly en: "↑/↓      move · PgUp/PgDn page\nEnter/→  attach to the selected session (with input text: dispatch); after backgrounding, **Enter** opens the current session\nShift+Enter  dispatch and attach\nSpace    toggle the peek panel · type a reply inside and Enter to send\nCtrl+X   stop the session · press again within 2s to delete\nCtrl+R   rename the selected session\nEsc      close peek → clear input → exit; after backgrounding, returns to the backgrounded session\nCtrl+C   clear input · twice to exit\n?        this help\n\nBackground sessions run inside this process: they stop when the TUI exits; their logs survive for /resume.";
    };
    readonly 'agentview-rename-placeholder': {
        readonly zh: "新的会话名称…";
        readonly en: "New session name…";
    };
    readonly 'agentview-renamed': {
        readonly zh: "已重命名「{{title}}」";
        readonly en: "Renamed \"{{title}}\"";
    };
    readonly 'agentview-rename-failed': {
        readonly zh: "重命名失败";
        readonly en: "Rename failed";
    };
    readonly 'agentview-hint-help': {
        readonly zh: "**Esc** 关闭帮助";
        readonly en: "**Esc** to close help";
    };
    readonly 'agentview-state-needs-input': {
        readonly zh: "等待输入";
        readonly en: "Needs input";
    };
    readonly 'agentview-state-working': {
        readonly zh: "运行中";
        readonly en: "Working";
    };
    readonly 'agentview-state-completed': {
        readonly zh: "已完成";
        readonly en: "Completed";
    };
    readonly 'agentview-state-failed': {
        readonly zh: "失败";
        readonly en: "Failed";
    };
    readonly 'agentview-state-idle': {
        readonly zh: "空闲";
        readonly en: "Idle";
    };
    readonly 'agentview-state-stopped': {
        readonly zh: "已停止";
        readonly en: "Stopped";
    };
    readonly 'approval-background-agent': {
        readonly zh: "来自后台会话 {{id}} 的审批请求";
        readonly en: "Approval request from background session {{id}}";
    };
    readonly 'input-background-hint-count': {
        readonly zh: "← {{n}} 个会话等待输入";
        readonly en: "← {{n}} agents";
    };
    readonly 'input-background-hint-idle': {
        readonly zh: "← 会话总览";
        readonly en: "← for agents";
    };
    readonly 'settings-title': {
        readonly zh: "插件设置";
        readonly en: "Plugin settings";
    };
    readonly 'settings-unavailable': {
        readonly zh: "设置服务未挂载——只读";
        readonly en: "settings service absent — read-only";
    };
    readonly 'settings-empty': {
        readonly zh: "没有可配置的插件设置（尚无插件注册设置区块）";
        readonly en: "No configurable plugin settings (no plugin has registered a section)";
    };
    readonly 'settings-group-empty': {
        readonly zh: "此分组没有可配置字段";
        readonly en: "No configurable fields in this group";
    };
    readonly 'settings-section-unavailable': {
        readonly zh: "命名空间未注册";
        readonly en: "namespace not served";
    };
    readonly 'settings-badge-restart': {
        readonly zh: "重启生效";
        readonly en: "applies on restart";
    };
    readonly 'settings-badge-dirty': {
        readonly zh: "未保存";
        readonly en: "unsaved";
    };
    readonly 'settings-badge-saving': {
        readonly zh: "保存中";
        readonly en: "saving";
    };
    readonly 'settings-badge-failed': {
        readonly zh: "保存失败";
        readonly en: "save failed";
    };
    readonly 'settings-field-customized': {
        readonly zh: "已自定义";
        readonly en: "customized";
    };
    readonly 'settings-field-empty': {
        readonly zh: "（未设置）";
        readonly en: "(unset)";
    };
    readonly 'settings-field-invalid': {
        readonly zh: "无效输入";
        readonly en: "invalid";
    };
    readonly 'settings-secret-set': {
        readonly zh: "●●●●●●（已配置）";
        readonly en: "●●●●●● (configured)";
    };
    readonly 'settings-secret-unset': {
        readonly zh: "（未配置）";
        readonly en: "(not configured)";
    };
    readonly 'settings-secret-staged': {
        readonly zh: "（待保存）";
        readonly en: "(pending save)";
    };
    readonly 'settings-saved': {
        readonly zh: "已保存 {{ns}}";
        readonly en: "Saved {{ns}}";
    };
    readonly 'settings-save-failed': {
        readonly zh: "保存 {{ns}} 失败——请重试";
        readonly en: "Saving {{ns}} failed — please retry";
    };
    readonly 'settings-secret-ref-reserved': {
        readonly zh: "凭据 {{ref}} 由宿主保留，写入被拒绝：第三方设置区块不能覆盖宿主共享凭据";
        readonly en: "Credential {{ref}} is reserved by the host; write rejected: third-party settings sections cannot overwrite host-shared credentials";
    };
    readonly 'settings-hint-list': {
        readonly zh: "**Enter** 进入/编辑/切换（改动即保存） · Esc 退出";
        readonly en: "**Enter** open/edit/toggle (auto-saves) · Esc exit";
    };
    readonly 'settings-hint-group': {
        readonly zh: "**Enter** 编辑/切换（改动即保存） · Esc 返回";
        readonly en: "**Enter** edit/toggle (auto-saves) · Esc back";
    };
    readonly 'settings-hint-edit': {
        readonly zh: "**Enter** 确认并保存 · Esc 取消";
        readonly en: "**Enter** to confirm & save · Esc to cancel";
    };
    readonly 'session-loading': {
        readonly zh: "正在读取会话…";
        readonly en: "Reading sessions…";
    };
    readonly 'session-list-failed': {
        readonly zh: "无法读取会话列表 · {{err}}";
        readonly en: "Could not read the session list · {{err}}";
    };
    readonly 'session-resume-failed': {
        readonly zh: "恢复会话失败 · {{err}}";
        readonly en: "Resuming the session failed · {{err}}";
    };
    readonly 'session-when-now': {
        readonly zh: "刚刚";
        readonly en: "just now";
    };
    readonly 'session-when-minutes': {
        readonly zh: "{{n}} 分钟前";
        readonly en: "{{n}}m ago";
    };
    readonly 'session-when-hours': {
        readonly zh: "{{n}} 小时前";
        readonly en: "{{n}}h ago";
    };
    readonly 'session-when-days': {
        readonly zh: "{{n}} 天前";
        readonly en: "{{n}}d ago";
    };
    readonly 'session-when-date': {
        readonly zh: "{{month}} 月 {{day}} 日";
        readonly en: "{{month}}/{{day}}";
    };
    readonly 'session-children': {
        readonly zh: "{{n}} 个子运行";
        readonly en: "{{n}} runs";
    };
    readonly 'session-kind-root': {
        readonly zh: "对话";
        readonly en: "Conversation";
    };
    readonly 'session-kind-fork': {
        readonly zh: "回溯分支";
        readonly en: "Rewound branch";
    };
    readonly 'session-kind-subagent': {
        readonly zh: "子 agent 运行";
        readonly en: "Sub-agent run";
    };
    readonly 'session-project-unknown': {
        readonly zh: "（未记录目录）";
        readonly en: "(no directory recorded)";
    };
    readonly 'session-scope-all': {
        readonly zh: "全部工作目录";
        readonly en: "all working directories";
    };
    readonly 'session-search-placeholder': {
        readonly zh: "输入以搜索 · {{scope}}";
        readonly en: "Type to search · {{scope}}";
    };
    readonly 'session-workspace-scope': {
        readonly zh: "工作目录";
        readonly en: "Working directory";
    };
    readonly 'session-workspace-switch': {
        readonly zh: "← 选择目录";
        readonly en: "← choose directory";
    };
    readonly 'session-workspace-select-title': {
        readonly zh: "选择工作目录";
        readonly en: "Choose working directory";
    };
    readonly 'session-workspace-search-placeholder': {
        readonly zh: "输入以搜索工作目录";
        readonly en: "Type to search working directories";
    };
    readonly 'session-workspace-all': {
        readonly zh: "全部工作目录";
        readonly en: "All working directories";
    };
    readonly 'session-workspace-current': {
        readonly zh: "当前";
        readonly en: "current";
    };
    readonly 'session-workspace-project-count': {
        readonly zh: "{{n}} 个目录";
        readonly en: "{{n}} directories";
    };
    readonly 'session-workspace-all-detail': {
        readonly zh: "跨目录浏览 · {{n}} 个会话";
        readonly en: "browse across directories · {{n}} sessions";
    };
    readonly 'session-workspace-empty': {
        readonly zh: "暂无历史会话";
        readonly en: "no history yet";
    };
    readonly 'session-workspace-no-match': {
        readonly zh: "没有匹配的工作目录";
        readonly en: "No matching working directory";
    };
    readonly 'resume-menu-open': {
        readonly zh: "打开";
        readonly en: "Open";
    };
    readonly 'resume-menu-pin': {
        readonly zh: "固定到顶部";
        readonly en: "Pin to top";
    };
    readonly 'resume-menu-unpin': {
        readonly zh: "取消固定";
        readonly en: "Unpin";
    };
    readonly 'resume-menu-rename': {
        readonly zh: "重命名";
        readonly en: "Rename";
    };
    readonly 'resume-menu-delete': {
        readonly zh: "删除";
        readonly en: "Delete";
    };
    readonly 'session-pinned-group': {
        readonly zh: "已固定";
        readonly en: "Pinned";
    };
    readonly 'resume-pinned': {
        readonly zh: "已固定 {{name}}";
        readonly en: "Pinned {{name}}";
    };
    readonly 'resume-unpinned': {
        readonly zh: "已取消固定 {{name}}";
        readonly en: "Unpinned {{name}}";
    };
    readonly 'resume-pin-save-failed': {
        readonly zh: "固定状态保存失败，未应用更改";
        readonly en: "Could not save pin; no change was applied";
    };
    readonly 'session-count-shown': {
        readonly zh: "{{n}} 个会话";
        readonly en: "{{n}} sessions";
    };
    readonly 'session-count-subagents': {
        readonly zh: "{{n}} 个子运行已折叠";
        readonly en: "{{n}} runs folded";
    };
    readonly 'session-count-empty': {
        readonly zh: "{{n}} 个空会话";
        readonly en: "{{n}} empty";
    };
    readonly 'session-clean-confirm': {
        readonly zh: "清理 {{n}} 个没有对话内容的会话？日志将被永久移除。";
        readonly en: "Remove {{n}} sessions that hold no conversation? Their logs are deleted permanently.";
    };
    readonly 'session-cleaned': {
        readonly zh: "已清理 {{n}} 个空会话";
        readonly en: "Removed {{n}} empty sessions";
    };
    readonly 'session-preview-times': {
        readonly zh: "创建于 {{created}} · 最后活动 {{updated}}";
        readonly en: "created {{created}} · last active {{updated}}";
    };
    readonly 'session-preview-loading': {
        readonly zh: "正在读取会话结尾…";
        readonly en: "Reading the end of this session…";
    };
    readonly 'session-preview-empty': {
        readonly zh: "这个会话没有可预览的往来消息";
        readonly en: "No exchanges to preview in this session";
    };
    readonly 'session-toggle-on': {
        readonly zh: "开";
        readonly en: "on";
    };
    readonly 'session-toggle-off': {
        readonly zh: "关";
        readonly en: "off";
    };
    readonly 'session-hint-list': {
        readonly zh: "**Enter** 恢复 · ← 工作目录 · Tab 预览 · 右键菜单 · {{mod}}a 全部目录（{{projects}}） · {{mod}}s 子运行（{{runs}}） · {{mod}}b 本分支 · {{mod}}r 重命名 · {{mod}}p 固定 · {{mod}}d 删除 · {{mod}}x 清空壳 · Esc 退出";
        readonly en: "**Enter** resume · ← directories · Tab preview · right-click menu · {{mod}}a all directories ({{projects}}) · {{mod}}s runs ({{runs}}) · {{mod}}b this branch · {{mod}}r rename · {{mod}}p pin · {{mod}}d delete · {{mod}}x clean · Esc exit";
    };
    readonly 'session-hint-list-mid': {
        readonly zh: "**Enter** 恢复 · ← 工作目录 · Tab 预览 · 右键菜单 · {{mod}}a 全部目录 · {{mod}}s 子运行 · {{mod}}r 重命名 · {{mod}}p 固定 · {{mod}}d 删除 · Esc 退出";
        readonly en: "**Enter** resume · ← directories · Tab preview · right-click menu · {{mod}}a all directories · {{mod}}s runs · {{mod}}r rename · {{mod}}p pin · {{mod}}d delete · Esc exit";
    };
    readonly 'session-hint-list-short': {
        readonly zh: "**Enter** 恢复 · {{mod}}p ★ · ← 目录 · Esc";
        readonly en: "**Enter** resume · {{mod}}p ★ · ← dirs · Esc";
    };
    readonly 'session-hint-workspaces': {
        readonly zh: "**Enter/→** 查看会话 · ↑/↓ 选择 · {{mod}}a 全部目录 · Esc 返回";
        readonly en: "**Enter/→** view sessions · ↑/↓ choose · {{mod}}a all directories · Esc back";
    };
    readonly 'session-hint-workspaces-short': {
        readonly zh: "**Enter/→** 查看 · Esc";
        readonly en: "**Enter/→** view · Esc";
    };
    readonly 'hint-confirm-exit': {
        readonly zh: "**Enter** 确认 · Esc 退出";
        readonly en: "**Enter** to confirm · Esc to exit";
    };
    readonly 'hint-select-exit': {
        readonly zh: "**Enter** 选择 · Esc 退出";
        readonly en: "**Enter** to select · Esc to exit";
    };
    readonly 'hint-fill-exit': {
        readonly zh: "**Enter** 填入命令 · Esc 退出";
        readonly en: "**Enter** to insert · Esc to exit";
    };
    readonly 'hint-rewind-back': {
        readonly zh: "**Enter** 回退 · Esc 返回";
        readonly en: "**Enter** to rewind · Esc to back";
    };
    readonly 'statusline-hint-select': {
        readonly zh: "esc 返回输入";
        readonly en: "esc to return to input";
    };
    readonly 'statusline-hint-working': {
        readonly zh: "esc 中断";
        readonly en: "esc to interrupt";
    };
    readonly 'statusline-hint-shortcuts': {
        readonly zh: "? 查看快捷键";
        readonly en: "? for shortcuts";
    };
    readonly 'status-detail-of-window': {
        readonly zh: "的窗口";
        readonly en: "of window";
    };
    readonly 'status-detail-session-id': {
        readonly zh: "会话日志目录与此 id 同名";
        readonly en: "the session log directory is named after this id";
    };
    readonly 'hint-ext-dialog-input': {
        readonly zh: "**Enter** 确认 · Esc 取消";
        readonly en: "**Enter** to confirm · Esc to cancel";
    };
    readonly 'hint-adjust-done': {
        readonly zh: "**←/→** 调整 · Enter/Esc 完成";
        readonly en: "**←/→** to adjust · Enter/Esc to done";
    };
    readonly 'hint-history-search': {
        readonly zh: "↑/↓ 选择 · **Enter** 确认 · Esc 取消";
        readonly en: "↑/↓ to navigate · **Enter** to select · Esc to cancel";
    };
    readonly 'hint-expand-ctrl-o': {
        readonly zh: "（ctrl+o 展开）";
        readonly en: "(ctrl+o to expand)";
    };
    readonly 'long-line-folded': {
        readonly zh: "… 已折叠 {{n}} 字符（点击或 ctrl+o 展开）";
        readonly en: "… {{n}} chars folded (click or ctrl+o to expand)";
    };
    readonly 'file-actions-title': {
        readonly zh: "文件操作";
        readonly en: "File actions";
    };
    readonly 'file-actions-open': {
        readonly zh: "打开文件";
        readonly en: "Open file";
    };
    readonly 'file-actions-open-dir': {
        readonly zh: "打开文件夹";
        readonly en: "Open folder";
    };
    readonly 'file-actions-reveal': {
        readonly zh: "打开所在文件夹";
        readonly en: "Reveal in folder";
    };
    readonly 'file-actions-copy': {
        readonly zh: "复制绝对路径";
        readonly en: "Copy absolute path";
    };
    readonly 'picker-title-model': {
        readonly zh: "模型";
        readonly en: "Model";
    };
    readonly 'picker-group-recent': {
        readonly zh: "最近使用";
        readonly en: "Recently used";
    };
    readonly 'picker-group-count': {
        readonly zh: "{{count}} 个模型";
        readonly en: "{{count}} models";
    };
    readonly 'hint-model-groups': {
        readonly zh: "**Enter** 查看模型 · Esc 退出";
        readonly en: "**Enter** to view models · Esc to exit";
    };
    readonly 'hint-model-back': {
        readonly zh: "**Enter** 切换模型 · Esc/⌫ 返回上级";
        readonly en: "**Enter** to switch · Esc/⌫ to go back";
    };
    readonly 'picker-title-skills': {
        readonly zh: "技能";
        readonly en: "Skills";
    };
    readonly 'skills-loading': {
        readonly zh: "正在加载技能";
        readonly en: "Loading skills";
    };
    readonly 'skills-loading-subtitle': {
        readonly zh: "正在查询技能注册表…";
        readonly en: "Querying the skill registry…";
    };
    readonly 'skills-empty': {
        readonly zh: "当前会话没有可用技能";
        readonly en: "No skills available in this session";
    };
    readonly 'skills-load-failed': {
        readonly zh: "技能列表加载失败";
        readonly en: "Failed to load the skill list";
    };
    readonly 'skills-unknown': {
        readonly zh: "未知技能「{{name}}」";
        readonly en: "Unknown skill \"{{name}}\"";
    };
    readonly 'skills-not-invocable': {
        readonly zh: "技能「{{name}}」不可直接调用";
        readonly en: "Skill \"{{name}}\" is not directly invocable";
    };
    readonly 'plugin-scene-crashed': {
        readonly zh: "插件场景「{{id}}」渲染崩溃：{{err}}（已自动关闭）";
        readonly en: "Plugin scene \"{{id}}\" crashed while rendering: {{err}} (closed)";
    };
    readonly 'skills-source-bundled': {
        readonly zh: "内置";
        readonly en: "built-in";
    };
    readonly 'skills-source-user': {
        readonly zh: "用户";
        readonly en: "user";
    };
    readonly 'skills-source-project': {
        readonly zh: "项目";
        readonly en: "project";
    };
    readonly 'skills-source-runtime': {
        readonly zh: "运行时";
        readonly en: "runtime";
    };
    readonly 'skills-source-custom': {
        readonly zh: "自定义";
        readonly en: "custom";
    };
    readonly 'picker-title-theme': {
        readonly zh: "颜色主题";
        readonly en: "Color theme";
    };
    readonly 'picker-title-activity': {
        readonly zh: "指示器预设";
        readonly en: "Indicator preset";
    };
    readonly 'picker-title-color': {
        readonly zh: "会话强调色";
        readonly en: "Session accent color";
    };
    readonly 'picker-title-effort': {
        readonly zh: "推理强度";
        readonly en: "Reasoning effort";
    };
    readonly 'model-loading': {
        readonly zh: "正在加载模型";
        readonly en: "Loading models";
    };
    readonly 'model-loading-subtitle': {
        readonly zh: "正在查询 provider…";
        readonly en: "Querying the provider…";
    };
    readonly 'model-switching': {
        readonly zh: "正在切换模型到 {{name}}…";
        readonly en: "Switching model to {{name}}…";
    };
    readonly 'model-switched': {
        readonly zh: "模型已切换为 {{name}}";
        readonly en: "Model switched to {{name}}";
    };
    readonly 'rewind-title': {
        readonly zh: "回退";
        readonly en: "Rewind";
    };
    readonly 'rewind-subtitle': {
        readonly zh: "选择一条消息，将对话回退到该处";
        readonly en: "Pick a message to rewind the conversation to";
    };
    readonly 'rewind-confirm-title': {
        readonly zh: "将对话回退到这条消息？";
        readonly en: "Rewind conversation to this message?";
    };
    readonly 'rewind-confirm-desc': {
        readonly zh: "对话从此处重新开始";
        readonly en: "conversation restarts here";
    };
    readonly 'rewind-empty': {
        readonly zh: "没有可回退的消息";
        readonly en: "No messages to rewind to";
    };
    readonly 'rewind-last-message': {
        readonly zh: "最近一条消息";
        readonly en: "last message";
    };
    readonly 'rewind-none': {
        readonly zh: "还没有可回退的消息";
        readonly en: "Nothing to rewind yet";
    };
    readonly 'rewind-done': {
        readonly zh: "已回退——编辑后按 Enter 重新发送";
        readonly en: "Rewound — edit and press Enter to resend";
    };
    readonly 'rewind-mode-default': {
        readonly zh: "仅回退会话";
        readonly en: "Conversation only";
    };
    readonly 'rewind-waiting-plugins': {
        readonly zh: "正在等待插件决定…（Esc 放弃等待）";
        readonly en: "Waiting for plugins… (Esc to stop waiting)";
    };
    readonly 'ext-action-cancelled': {
        readonly zh: "操作已被插件取消";
        readonly en: "Action cancelled by a plugin";
    };
    readonly 'ext-action-handled': {
        readonly zh: "输入已由插件处理";
        readonly en: "Input handled by a plugin";
    };
    readonly 'ext-decision-pending': {
        readonly zh: "正在等待插件决定（{{event}}）…";
        readonly en: "Waiting for a plugin decision ({{event}})…";
    };
    readonly 'ext-stale-dropped': {
        readonly zh: "等待插件期间会话已切换，该条输入已丢弃";
        readonly en: "Session switched while a plugin decided — the input was dropped";
    };
    readonly 'ext-compact-stale': {
        readonly zh: "等待插件期间会话已切换，压缩已取消";
        readonly en: "Session switched while a plugin decided — compaction abandoned";
    };
    readonly 'ext-shortcut-failed': {
        readonly zh: "插件快捷键 {{combo}} 执行失败";
        readonly en: "Plugin shortcut {{combo}} failed";
    };
    readonly 'command-invoke-denied': {
        readonly zh: "命令调用已被授权文件拒绝（commands.invoke 已撤销）";
        readonly en: "Command invocation denied by the grants file (commands.invoke revoked)";
    };
    readonly 'command-invoke-denied-owner': {
        readonly zh: "命令 \"/{{name}}\" 的调用已被拒绝——注册它的插件 \"{{owner}}\" 已被撤销 commands.invoke";
        readonly en: "Command \"/{{name}}\" invocation denied — its owner plugin \"{{owner}}\" lost commands.invoke";
    };
    readonly 'plugins-trust-banner': {
        readonly zh: "插件与宿主同进程运行：授权是行为约束而非安全隔离；通过校验 ≠ 插件安全（C-070）。";
        readonly en: "Plugins run in-process with the host: grants are behavioral constraints, not a security boundary; passing validation ≠ a safe plugin (C-070).";
    };
    readonly 'plugins-host-unavailable': {
        readonly zh: "plugin-host 行未挂载：Host Descriptor 与授权矩阵按无信息降级。";
        readonly en: "plugin-host row not mounted: Host Descriptor and grant matrix degraded to no-data.";
    };
    readonly 'plugins-contract-dropped': {
        readonly zh: "已剔除（vendored 哈希漂移）";
        readonly en: "dropped (vendored hash drift)";
    };
    readonly 'plugins-matrix-note': {
        readonly zh: "授权矩阵（✓ 允许 / · 拒绝；仅显示有足迹的插件——授权文件、效果台账与存储目录的并集）：";
        readonly en: "Grant matrix (✓ allowed / · denied; plugins with footprints only — union of the grants file, effect ledger, and storage directory):";
    };
    readonly 'plugins-matrix-no-registry': {
        readonly zh: "（权限注册表不可用）";
        readonly en: "(permission registry unavailable)";
    };
    readonly 'plugins-matrix-empty': {
        readonly zh: "（暂无插件足迹）";
        readonly en: "(no plugin footprints yet)";
    };
    readonly 'plugins-footprint-overflow': {
        readonly zh: "…另有 {{count}} 个插件未显示";
        readonly en: {
            readonly one: "…{{count}} more plugin not shown";
            readonly other: "…{{count}} more plugins not shown";
        };
    };
    readonly 'plugins-ledger-empty': {
        readonly zh: "效果台账为空。";
        readonly en: "The effect ledger is empty.";
    };
    readonly 'plugins-ledger-header': {
        readonly zh: "效果台账（{{file}}）尾 5 条：";
        readonly en: "Effect ledger ({{file}}), last 5 records:";
    };
    readonly 'plugins-unknown-subcommand': {
        readonly zh: "未知子命令：{{sub}}（支持：check <路径>）";
        readonly en: "Unknown subcommand: {{sub}} (supported: check <path>)";
    };
    readonly 'plugins-check-usage': {
        readonly zh: "用法：/plugins check <dsh-plugin.json 路径>";
        readonly en: "Usage: /plugins check <path-to-dsh-plugin.json>";
    };
    readonly 'plugins-check-not-found': {
        readonly zh: "文件不存在：{{path}}";
        readonly en: "File not found: {{path}}";
    };
    readonly 'plugins-check-invalid-json': {
        readonly zh: "不是可解析的 JSON：{{err}}";
        readonly en: "Not parseable JSON: {{err}}";
    };
    readonly 'plugins-check-spec-unavailable': {
        readonly zh: "vendored 规范数据不可用（dsh-ecosystem-spec/），无法校验。";
        readonly en: "Vendored spec data unavailable (dsh-ecosystem-spec/); cannot validate.";
    };
    readonly 'plugins-check-schema-failed': {
        readonly zh: "schema 校验失败：{{err}}";
        readonly en: "Schema validation failed: {{err}}";
    };
    readonly 'plugins-check-invalid': {
        readonly zh: "语义校验失败：{{err}}";
        readonly en: "Semantic validation failed: {{err}}";
    };
    readonly 'plugins-check-state': {
        readonly zh: "协商结果：{{state}}";
        readonly en: "Negotiation decision: {{state}}";
    };
    readonly 'plugins-grant-hint': {
        readonly zh: "授权方法：在 ~/.dsh-tui/extension-grants.json 的 \"grants\" 段为插件 id 添加规则（如 { \"name\": \"<权限>\", \"scope\": \"<范围>\" }），保存即生效、无需重启。";
        readonly en: "To grant: add a rule for the plugin id under \"grants\" in ~/.dsh-tui/extension-grants.json (e.g. { \"name\": \"<permission>\", \"scope\": \"<scope>\" }); saved changes apply immediately, no restart.";
    };
    readonly 'plugins-check-grant-hint': {
        readonly zh: "授权方法：在 ~/.dsh-tui/extension-grants.json 的 \"grants\" 段加入 \"{{id}}\": [{ \"name\": \"<权限>\", \"scope\": \"<范围>\" }]；待授权权限：{{perms}}。";
        readonly en: "To authorize: add \"{{id}}\": [{ \"name\": \"<permission>\", \"scope\": \"<scope>\" }] under \"grants\" in ~/.dsh-tui/extension-grants.json; pending permissions: {{perms}}.";
    };
    readonly 'plugins-check-dropped': {
        readonly zh: "（宿主描述符已剔除漂移契约：{{dropped}}）";
        readonly en: "(host descriptor dropped drifted contracts: {{dropped}})";
    };
    readonly 'plugins-check-host-unavailable': {
        readonly zh: "当前没有 live Host Descriptor；只做静态 manifest 校验，不进行协议支持声明/协商。";
        readonly en: "No live Host Descriptor is available; only static manifest validation was performed, no protocol support declaration/negotiation.";
    };
    readonly 'doctor-plugin-generation': {
        readonly zh: "插件运行时 generation：{{id}}";
        readonly en: "Plugin runtime generation: {{id}}";
    };
    readonly 'doctor-plugin-registry': {
        readonly zh: "插件规范注册表自检：{{state}}";
        readonly en: "Plugin-spec registry self-check: {{state}}";
    };
    readonly 'doctor-plugin-host-missing': {
        readonly zh: "plugin-host 行未挂载";
        readonly en: "plugin-host row not mounted";
    };
    readonly 'ext-dialog-yes': {
        readonly zh: "是";
        readonly en: "Yes";
    };
    readonly 'ext-dialog-no': {
        readonly zh: "否";
        readonly en: "No";
    };
    readonly 'thinking-title': {
        readonly zh: "思考过程显示";
        readonly en: "Thinking display";
    };
    readonly 'thinking-subtitle': {
        readonly zh: "只控制思考过程是否显示，不改变模型的思考行为。";
        readonly en: "Only controls whether reasoning is shown; it does not change model behavior.";
    };
    readonly 'thinking-enabled': {
        readonly zh: "显示";
        readonly en: "Shown";
    };
    readonly 'thinking-enabled-desc': {
        readonly zh: "在对话中显示 DeepSeek 的思考过程";
        readonly en: "Show DeepSeek's reasoning in the conversation";
    };
    readonly 'thinking-disabled': {
        readonly zh: "隐藏";
        readonly en: "Hidden";
    };
    readonly 'thinking-disabled-desc': {
        readonly zh: "隐藏思考过程；模型仍会照常思考";
        readonly en: "Hide reasoning; the model will still think as usual";
    };
    readonly 'thinking-label': {
        readonly zh: "思考";
        readonly en: "Thinking";
    };
    readonly 'history-search-title': {
        readonly zh: "搜索历史";
        readonly en: "Search history";
    };
    readonly 'history-search-placeholder': {
        readonly zh: "输入以搜索…";
        readonly en: "Type to search…";
    };
    readonly 'history-search-empty': {
        readonly zh: "没有匹配的命令";
        readonly en: "No matching commands";
    };
    readonly 'time-now': {
        readonly zh: "刚刚";
        readonly en: "now";
    };
    readonly 'time-minutes-ago': {
        readonly zh: "{{n}} 分钟前";
        readonly en: "{{n}}m ago";
    };
    readonly 'time-hours-ago': {
        readonly zh: "{{n}} 小时前";
        readonly en: "{{n}}h ago";
    };
    readonly 'time-days-ago': {
        readonly zh: "{{n}} 天前";
        readonly en: "{{n}}d ago";
    };
    readonly 'search-no-matches': {
        readonly zh: "无匹配";
        readonly en: "no matches";
    };
    readonly 'rename-usage': {
        readonly zh: "用法  /rename <新名称>";
        readonly en: "Usage  /rename <new title>";
    };
    readonly 'rename-current': {
        readonly zh: "当前名称  {{title}}";
        readonly en: "Current title  {{title}}";
    };
    readonly 'rename-done': {
        readonly zh: "已重命名为「{{title}}」";
        readonly en: "Renamed to \"{{title}}\"";
    };
    readonly 'compact-summary-folded': {
        readonly zh: "摘要已折叠";
        readonly en: "Summary folded";
    };
    readonly 'new-message': {
        readonly zh: "↓ {{n}} 条新消息";
        readonly en: "↓ 1 new message";
    };
    readonly 'new-messages': {
        readonly zh: "↓ {{n}} 条新消息";
        readonly en: "↓ {{n}} new messages";
    };
    readonly 'back-to-bottom': {
        readonly zh: "↓ 回到底部（Enter/End）";
        readonly en: "↓ back to bottom (Enter/End)";
    };
    readonly 'theme-builtin-base': {
        readonly zh: "内置 · {{name}} 基底";
        readonly en: "Built-in · {{name}} base";
    };
    readonly 'theme-auto-base': {
        readonly zh: "内置 · 跟随系统/终端背景自动选择 light/dark";
        readonly en: "Built-in · follows the system/terminal background (light/dark)";
    };
    readonly 'theme-user-base': {
        readonly zh: "{{base}} 基底 · ~/.dsh-tui/themes/{{name}}.json";
        readonly en: "{{base}} base · ~/.dsh-tui/themes/{{name}}.json";
    };
    readonly 'theme-plugin-base': {
        readonly zh: "插件 · {{base}} 基底 · {{name}}";
        readonly en: "Plugin · {{base}} base · {{name}}";
    };
    readonly 'context-unavailable': {
        readonly zh: "当前会话没有已加载的上下文";
        readonly en: "No loaded context is available for this session";
    };
    readonly 'context-panel-sections': {
        readonly zh: "系统提示词 · {{n}} 段";
        readonly en: "System prompt · {{n}} sections";
    };
    readonly 'context-panel-files': {
        readonly zh: "工作区指令 · {{n}} 个文件";
        readonly en: "Workspace instructions · {{n}} files";
    };
    readonly 'context-panel-runtime': {
        readonly zh: "运行时上下文 · {{n}} 项";
        readonly en: "Runtime context · {{n}} items";
    };
    readonly 'context-panel-skills': {
        readonly zh: "技能 · {{n}}";
        readonly en: "Skills · {{n}}";
    };
    readonly 'context-panel-tools': {
        readonly zh: "工具 · {{n}}";
        readonly en: "Tools · {{n}}";
    };
    readonly 'question-provider-occupied': {
        readonly zh: "⚠️ 问卷通道已被非宿主组件 {{id}} 占用，模型提问可能被代答（本界面未接入问卷）";
        readonly en: "⚠️ The questionnaire channel is held by a non-host component ({{id}}); model questions may be answered by it (this UI did not take the seat)";
    };
    readonly 'question-provider-occupied-unverified': {
        readonly zh: "⚠️ 问卷通道被一个自报为 {{id}} 的组件占用——身份未经宿主验证，模型提问可能被代答（本界面未接入问卷）";
        readonly en: "⚠️ The questionnaire channel is held by a component self-reporting as {{id}} — identity not host-verified; model questions may be answered by it (this UI did not take the seat)";
    };
    readonly 'question-provider-occupied-unknown': {
        readonly zh: "身份未知";
        readonly en: "identity unknown";
    };
    readonly 'question-select-or-answer': {
        readonly zh: "至少选择一个选项，或在最后一行输入回答";
        readonly en: "Select at least one option, or type an answer on the last line";
    };
    readonly 'question-answer-or-check': {
        readonly zh: "输入回答或勾选选项后再提交";
        readonly en: "Type an answer or check options before submitting";
    };
    readonly 'question-type-answer-first': {
        readonly zh: "先输入回答内容再提交";
        readonly en: "Type your answer before submitting";
    };
    readonly 'question-header-progress': {
        readonly zh: " 📋 提问 · 第 {{position}}/{{total}} 题{{remaining}} ";
        readonly en: " 📋 Question {{position}}/{{total}} {{remaining}} ";
    };
    readonly 'question-remaining-more': {
        readonly zh: " · 还剩 {{n}} 题";
        readonly en: " · {{n}} left";
    };
    readonly 'question-hint-type': {
        readonly zh: "输入回答";
        readonly en: "Type answer";
    };
    readonly 'question-hint-paste': {
        readonly zh: "Ctrl+V 粘贴";
        readonly en: "Ctrl+V paste";
    };
    readonly 'question-hint-enter': {
        readonly zh: "Enter 提交";
        readonly en: "Enter submit";
    };
    readonly 'question-hint-back': {
        readonly zh: "↑ 返回选项";
        readonly en: "↑ back to options";
    };
    readonly 'question-hint-esc': {
        readonly zh: "Esc 中断";
        readonly en: "Esc cancel";
    };
    readonly 'question-hint-previous': {
        readonly zh: "Esc 上一题";
        readonly en: "Esc previous question";
    };
    readonly 'question-hint-cancel': {
        readonly zh: "Ctrl+C 取消整批";
        readonly en: "Ctrl+C cancel batch";
    };
    readonly 'question-hint-selected': {
        readonly zh: "已选 {{n}}";
        readonly en: "Selected {{n}}";
    };
    readonly 'question-hint-select': {
        readonly zh: "↑/↓ 选择";
        readonly en: "↑/↓ select";
    };
    readonly 'question-hint-multi': {
        readonly zh: "Space 多选";
        readonly en: "Space multi-select";
    };
    readonly 'question-hint-attach': {
        readonly zh: "输入文字附带回答";
        readonly en: "Type text to attach an answer";
    };
    readonly 'question-custom-tab': {
        readonly zh: "自定义回答";
        readonly en: "Custom answer";
    };
    readonly 'question-attached-label': {
        readonly zh: "（附加：{{label}}）";
        readonly en: "(attached: {{label}})";
    };
    readonly 'question-direct-input': {
        readonly zh: "直接输入…";
        readonly en: "Type directly…";
    };
    readonly 'question-paste-not-text': {
        readonly zh: "剪贴板内容是图片或文件，无法作为文字粘贴";
        readonly en: "Clipboard holds an image or file — not pastable as text";
    };
    readonly 'question-paste-too-long': {
        readonly zh: "粘贴内容过长（最多 {{n}} 个字符），请精简后再试";
        readonly en: "Pasted content is too long (max {{n}} characters) — trim it and try again";
    };
    readonly 'approval-waiting': {
        readonly zh: " ⏳ 等待审批 · {{tool}} ";
        readonly en: " Awaiting approval · {{tool}} ";
    };
    readonly 'approval-external-hint': {
        readonly zh: "外部来源：该审批未关联当前会话的活跃工具调用，命令文本可能被伪造，请核实后再决定";
        readonly en: "External origin: this approval is not tied to a live tool call of this session — the command text may be forged; verify before deciding";
    };
    readonly 'approval-proceed': {
        readonly zh: "要允许这次操作吗？";
        readonly en: "Allow this operation?";
    };
    readonly 'approval-yes': {
        readonly zh: "允许（仅本次）";
        readonly en: "Yes, allow once";
    };
    readonly 'approval-no': {
        readonly zh: "拒绝";
        readonly en: "No";
    };
    readonly 'approval-hint': {
        readonly zh: "↑/↓ 选择 · Enter 确认 · Esc 拒绝";
        readonly en: "↑/↓ select · Enter confirm · Esc reject";
    };
    readonly 'subagent-model': {
        readonly zh: "模型";
        readonly en: "Model";
    };
    readonly 'subagent-duration': {
        readonly zh: "时长";
        readonly en: "Duration";
    };
    readonly 'subagent-status-label': {
        readonly zh: "状态";
        readonly en: "Status";
    };
    readonly 'subagent-status-cancelled': {
        readonly zh: "已取消";
        readonly en: "Cancelled";
    };
    readonly 'subagent-count-running': {
        readonly zh: "运行中";
        readonly en: "running";
    };
    readonly 'subagent-count-completed': {
        readonly zh: "已完成";
        readonly en: "completed";
    };
    readonly 'subagent-count-failed': {
        readonly zh: "失败";
        readonly en: "failed";
    };
    readonly 'subagent-started': {
        readonly zh: "开始时间";
        readonly en: "Started";
    };
    readonly 'subagent-completed': {
        readonly zh: "完成时间";
        readonly en: "Completed";
    };
    readonly 'subagent-error-label': {
        readonly zh: "错误";
        readonly en: "Error";
    };
    readonly 'subagent-output-label': {
        readonly zh: "输出";
        readonly en: "Output";
    };
    readonly 'subagent-no-output': {
        readonly zh: "暂无输出";
        readonly en: "No output yet";
    };
    readonly 'subagent-dashboard-title': {
        readonly zh: " 子代理面板 ";
        readonly en: " Subagent Dashboard ";
    };
    readonly 'subagent-dashboard-hint-basic': {
        readonly zh: "↑/↓ 浏览 · Esc 关闭";
        readonly en: "↑/↓ browse · Esc close";
    };
    readonly 'subagent-dashboard-hint-detail': {
        readonly zh: "↑/↓ 选择 · Enter 查看详情 · Esc 关闭";
        readonly en: "↑/↓ select · Enter view detail · Esc close";
    };
    readonly 'subagent-card-prefix': {
        readonly zh: "子代理：";
        readonly en: "Subagent: ";
    };
    readonly 'subagent-tab-summary': {
        readonly zh: "摘要";
        readonly en: "Summary";
    };
    readonly 'subagent-no-summary': {
        readonly zh: "暂无摘要";
        readonly en: "No summary yet";
    };
    readonly 'subagent-no-tools': {
        readonly zh: "暂无工具调用";
        readonly en: "No tool calls";
    };
    readonly 'subagent-hint-page': {
        readonly zh: "切页";
        readonly en: "page";
    };
    readonly 'subagent-hint-scroll': {
        readonly zh: "滚动";
        readonly en: "scroll";
    };
    readonly 'subagent-hint-back': {
        readonly zh: "返回";
        readonly en: "back";
    };
    readonly 'subagent-empty-hint': {
        readonly zh: "让主代理发起 Task 后，子代理会出现在这里";
        readonly en: "Subagents appear here once the main agent starts Task delegations";
    };
    readonly 'jobs-card-prefix': {
        readonly zh: "任务：";
        readonly en: "job: ";
    };
    readonly 'jobs-status-running': {
        readonly zh: "运行中";
        readonly en: "running";
    };
    readonly 'jobs-status-stopping': {
        readonly zh: "停止中";
        readonly en: "stopping";
    };
    readonly 'jobs-status-completed': {
        readonly zh: "已完成";
        readonly en: "completed";
    };
    readonly 'jobs-status-failed': {
        readonly zh: "失败";
        readonly en: "failed";
    };
    readonly 'jobs-status-killed': {
        readonly zh: "已停止";
        readonly en: "killed";
    };
    readonly 'jobs-panel-title': {
        readonly zh: " 后台任务 ";
        readonly en: " Background Jobs ";
    };
    readonly 'jobs-panel-count-running': {
        readonly zh: "运行中";
        readonly en: "running";
    };
    readonly 'jobs-panel-count-completed': {
        readonly zh: "已完成";
        readonly en: "completed";
    };
    readonly 'jobs-panel-count-failed': {
        readonly zh: "失败";
        readonly en: "failed";
    };
    readonly 'jobs-panel-empty': {
        readonly zh: "当前会话暂无后台任务";
        readonly en: "No background jobs in the current session";
    };
    readonly 'jobs-panel-empty-hint': {
        readonly zh: "后台运行的命令（run_in_background）会出现在这里";
        readonly en: "Commands the agent runs in the background appear here";
    };
    readonly 'jobs-panel-hint': {
        readonly zh: "↑/↓ 选择（聚焦行显示详情）· k 停止选中任务 · Esc 关闭";
        readonly en: "↑/↓ select (focused row shows details) · k kill focused job · Esc close";
    };
    readonly 'jobs-panel-started': {
        readonly zh: "开始";
        readonly en: "started";
    };
    readonly 'jobs-panel-finished': {
        readonly zh: "结束";
        readonly en: "finished";
    };
    readonly 'jobs-panel-command': {
        readonly zh: "命令";
        readonly en: "command";
    };
    readonly 'jobs-panel-output-at': {
        readonly zh: "输出更新于";
        readonly en: "output updated";
    };
    readonly 'jobs-panel-no-output-yet': {
        readonly zh: "（暂无镜像输出——agent 读取后显示）";
        readonly en: "(no mirrored output yet — appears when the agent reads it)";
    };
    readonly 'jobs-toast-completed': {
        readonly zh: "后台任务完成：{{label}}（{{id}} · 用时 {{duration}}）";
        readonly en: "Background job completed: {{label}} ({{id}} · {{duration}})";
    };
    readonly 'jobs-toast-failed': {
        readonly zh: "后台任务失败：{{label}}（{{id}} · {{detail}}）";
        readonly en: "Background job failed: {{label}} ({{id}} · {{detail}})";
    };
    readonly 'jobs-toast-killed': {
        readonly zh: "后台任务已停止：{{label}}（{{id}} · 用时 {{duration}}）";
        readonly en: "Background job killed: {{label}} ({{id}} · {{duration}})";
    };
    readonly 'jobs-kill-failed': {
        readonly zh: "无法停止任务 {{id}}（任务不存在或任务服务未挂载）";
        readonly en: "Could not kill job {{id}} (unknown job or jobs service not mounted)";
    };
    readonly 'jobs-steer-killed': {
        readonly zh: "我通过 /jobs 面板停止了后台任务 {{id}}（{{label}}）";
        readonly en: "I killed background job {{id}} ({{label}}) via the /jobs panel";
    };
    readonly 'plan-review-fallback-header': {
        readonly zh: "计划评审";
        readonly en: "Plan review";
    };
    readonly 'plan-review-feedback-placeholder': {
        readonly zh: "输入反馈，告诉模型要改什么…";
        readonly en: "Tell the model what to change…";
    };
    readonly 'plan-review-approve-needs-empty': {
        readonly zh: "请先清空反馈再批准（或在输入行回车提交反馈）";
        readonly en: "Clear the feedback to approve (or press Enter on the input row to send it)";
    };
    readonly 'plan-review-hint': {
        readonly zh: "↑/↓ 选择 · 1/2 快选 · 打字输入反馈 · Ctrl+V 粘贴 · Enter 提交 · Esc 打断评审";
        readonly en: "↑/↓ select · 1/2 quick-pick · type feedback · Ctrl+V paste · Enter submit · Esc dismiss";
    };
    readonly 'provider-unavailable': {
        readonly zh: "/provider 需要经 dsh profile 启动（settings / credentials / llm-pi-ai 服务未挂载）";
        readonly en: "/provider requires starting through a dsh profile (settings / credentials / llm-pi-ai services not mounted)";
    };
    readonly 'provider-q-mode': {
        readonly zh: "要添加哪种模型提供方？";
        readonly en: "Which kind of model provider do you want to add?";
    };
    readonly 'provider-opt-catalog': {
        readonly zh: "内置 provider";
        readonly en: "Built-in provider";
    };
    readonly 'provider-opt-catalog-desc': {
        readonly zh: "openai、anthropic、deepseek 等内置目录，自动继承端点与协议";
        readonly en: "Built-in catalog such as openai, anthropic, deepseek — endpoint and protocol inherited";
    };
    readonly 'provider-opt-custom': {
        readonly zh: "自定义 API 端点";
        readonly en: "Custom API endpoint";
    };
    readonly 'provider-opt-custom-desc': {
        readonly zh: "OpenAI / Anthropic 兼容的网关或自建服务";
        readonly en: "An OpenAI/Anthropic-compatible gateway or self-hosted server";
    };
    readonly 'provider-q-catalog': {
        readonly zh: "选择 provider";
        readonly en: "Choose a provider";
    };
    readonly 'provider-opt-other-route': {
        readonly zh: "其他（手动输入路由名）";
        readonly en: "Other (enter a route name)";
    };
    readonly 'provider-opt-other-route-desc': {
        readonly zh: "目录里没列出的 catalog 路由";
        readonly en: "A catalog route not listed above";
    };
    readonly 'provider-q-route-id': {
        readonly zh: "输入路由名";
        readonly en: "Enter a route name";
    };
    readonly 'provider-q-route-id-detail': {
        readonly zh: "小写字母开头，可含数字与连字符，如 my-gateway";
        readonly en: "Lowercase letter first, digits and dashes allowed, e.g. my-gateway";
    };
    readonly 'provider-route-id-invalid': {
        readonly zh: "路由名不合法：须以小写字母开头，仅含小写字母 / 数字 / 连字符";
        readonly en: "Invalid route name: must start with a lowercase letter, only lowercase letters / digits / dashes";
    };
    readonly 'provider-q-apikey': {
        readonly zh: "输入 API key";
        readonly en: "Enter the API key";
    };
    readonly 'provider-q-apikey-detail': {
        readonly zh: "密钥将写入 ~/.dsh/.credentials.yaml（权限 0600），不会出现在会话记录中";
        readonly en: "The key is stored in ~/.dsh/.credentials.yaml (mode 0600) and never shown in the transcript";
    };
    readonly 'provider-q-baseurl-choice': {
        readonly zh: "是否覆盖默认 API 端点（baseURL）？";
        readonly en: "Override the default API endpoint (baseURL)?";
    };
    readonly 'provider-opt-baseurl-skip': {
        readonly zh: "跳过，使用默认端点";
        readonly en: "Skip — use the default endpoint";
    };
    readonly 'provider-opt-baseurl-input': {
        readonly zh: "现在输入 baseURL";
        readonly en: "Enter a baseURL now";
    };
    readonly 'provider-q-baseurl': {
        readonly zh: "输入 baseURL";
        readonly en: "Enter the baseURL";
    };
    readonly 'provider-q-protocol': {
        readonly zh: "选择 API 协议";
        readonly en: "Choose the wire protocol";
    };
    readonly 'provider-protocol-completions-desc': {
        readonly zh: "OpenAI Chat Completions 兼容（大多数网关）";
        readonly en: "OpenAI Chat Completions compatible (most gateways)";
    };
    readonly 'provider-protocol-responses-desc': {
        readonly zh: "OpenAI Responses API";
        readonly en: "OpenAI Responses API";
    };
    readonly 'provider-protocol-anthropic-desc': {
        readonly zh: "Anthropic Messages API";
        readonly en: "Anthropic Messages API";
    };
    readonly 'provider-discovery-running': {
        readonly zh: "正在探测该端点公布的模型…";
        readonly en: "Discovering the models this endpoint advertises…";
    };
    readonly 'provider-discovery-failed': {
        readonly zh: "模型探测失败，改为手动输入模型 id";
        readonly en: "Model discovery failed — enter model ids manually instead";
    };
    readonly 'provider-q-models': {
        readonly zh: "选择要启用的模型（可在输入行逗号分隔补充）";
        readonly en: "Select the models to enable (add more comma-separated on the input row)";
    };
    readonly 'provider-q-models-fallback': {
        readonly zh: "输入模型 id（逗号分隔）";
        readonly en: "Enter model ids (comma-separated)";
    };
    readonly 'provider-models-required': {
        readonly zh: "自定义端点至少需要一个模型 id";
        readonly en: "A custom endpoint needs at least one model id";
    };
    readonly 'provider-q-confirm': {
        readonly zh: "确认写入该 provider 配置？";
        readonly en: "Write this provider configuration?";
    };
    readonly 'provider-route-exists-warning': {
        readonly zh: "⚠ 该路由已有配置，写入将覆盖现有设置";
        readonly en: "⚠ This route is already configured — writing overwrites it";
    };
    readonly 'provider-opt-confirm-write': {
        readonly zh: "写入并启用";
        readonly en: "Write and enable";
    };
    readonly 'provider-opt-confirm-cancel': {
        readonly zh: "取消";
        readonly en: "Cancel";
    };
    readonly 'provider-line-route': {
        readonly zh: "路由：{{route}}";
        readonly en: "Route: {{route}}";
    };
    readonly 'provider-line-keyref': {
        readonly zh: "密钥引用：{{ref}}（已写入 ~/.dsh/.credentials.yaml）";
        readonly en: "Key ref: {{ref}} (stored in ~/.dsh/.credentials.yaml)";
    };
    readonly 'provider-line-keyref-env': {
        readonly zh: "密钥引用：{{ref}}（进程环境已提供同名变量，跳过写入）";
        readonly en: "Key ref: {{ref}} (already in the process environment, write skipped)";
    };
    readonly 'provider-line-baseurl': {
        readonly zh: "baseURL：{{url}}";
        readonly en: "baseURL: {{url}}";
    };
    readonly 'provider-line-protocol': {
        readonly zh: "协议：{{api}}";
        readonly en: "Protocol: {{api}}";
    };
    readonly 'provider-line-models': {
        readonly zh: "模型：{{models}}";
        readonly en: "Models: {{models}}";
    };
    readonly 'provider-line-models-catalog': {
        readonly zh: "模型：整个 catalog（未收窄）";
        readonly en: "Models: the whole catalog (not narrowed)";
    };
    readonly 'provider-rollback-ok': {
        readonly zh: "已回滚刚写入的密钥";
        readonly en: "Rolled back the just-written key";
    };
    readonly 'provider-rollback-failed': {
        readonly zh: "密钥回滚失败，请手动检查 ~/.dsh/.credentials.yaml";
        readonly en: "Key rollback failed — check ~/.dsh/.credentials.yaml manually";
    };
    readonly 'provider-write-failed': {
        readonly zh: "provider 配置写入失败 · {{{err}}}";
        readonly en: "Failed to write the provider configuration · {{{err}}}";
    };
    readonly 'provider-cancelled': {
        readonly zh: "已取消添加 provider";
        readonly en: "Provider setup cancelled";
    };
    readonly 'provider-success': {
        readonly zh: "provider {{route}} 已添加";
        readonly en: "Provider {{route}} added";
    };
    readonly 'provider-switch-hint': {
        readonly zh: "运行 /model 可切换到新 provider 的模型";
        readonly en: "Run /model to switch to the new provider’s models";
    };
    readonly 'provider-q-switch': {
        readonly zh: "立即切换到新 provider？";
        readonly en: "Switch to the new provider now?";
    };
    readonly 'provider-opt-switch-now': {
        readonly zh: "切换到 {{model}}";
        readonly en: "Switch to {{model}}";
    };
    readonly 'provider-opt-switch-keep': {
        readonly zh: "保持当前模型";
        readonly en: "Keep the current model";
    };
    readonly 'provider-opt-oauth': {
        readonly zh: "订阅账号登录（OAuth）";
        readonly en: "Subscription sign-in (OAuth)";
    };
    readonly 'provider-opt-oauth-desc': {
        readonly zh: "用 ChatGPT / Claude / Grok 等官方订阅账号登录，无需 API key";
        readonly en: "Sign in with an official subscription (ChatGPT / Claude / Grok) — no API key";
    };
    readonly 'provider-q-oauth': {
        readonly zh: "登录哪个订阅账号？";
        readonly en: "Sign in to which subscription?";
    };
    readonly 'provider-oauth-state-in': {
        readonly zh: "已登录 · 令牌到期 {{time}}";
        readonly en: "Signed in · token expires {{time}}";
    };
    readonly 'provider-oauth-state-expired': {
        readonly zh: "已登录但令牌已过期，重新登录即可恢复";
        readonly en: "Signed in but the token expired — sign in again to restore";
    };
    readonly 'provider-q-oauth-signed': {
        readonly zh: "{{provider}} 已登录，接下来？";
        readonly en: "{{provider}} is signed in — what next?";
    };
    readonly 'provider-opt-oauth-relogin': {
        readonly zh: "重新登录";
        readonly en: "Sign in again";
    };
    readonly 'provider-opt-oauth-relogin-desc': {
        readonly zh: "更换账号或刷新已有凭据";
        readonly en: "Switch accounts or refresh the stored credential";
    };
    readonly 'provider-opt-oauth-logout': {
        readonly zh: "登出";
        readonly en: "Sign out";
    };
    readonly 'provider-opt-oauth-logout-desc': {
        readonly zh: "删除本地保存的 OAuth 凭据";
        readonly en: "Remove the locally stored OAuth credential";
    };
    readonly 'provider-oauth-none': {
        readonly zh: "没有可 OAuth 登录的 provider（检查 dsh-auth 插件是否挂载）";
        readonly en: "No OAuth-capable providers (check whether the dsh-auth plugin is mounted)";
    };
    readonly 'provider-oauth-login-ok': {
        readonly zh: "{{provider}} 登录成功";
        readonly en: "Signed in to {{provider}}";
    };
    readonly 'provider-oauth-login-failed': {
        readonly zh: "OAuth 登录失败 · {{{err}}}";
        readonly en: "OAuth sign-in failed · {{{err}}}";
    };
    readonly 'provider-oauth-logout-ok': {
        readonly zh: "{{provider}} 已登出";
        readonly en: "Signed out of {{provider}}";
    };
    readonly 'provider-line-oauth-provider': {
        readonly zh: "路由：{{provider}}";
        readonly en: "Route: {{provider}}";
    };
    readonly 'provider-line-oauth-flow': {
        readonly zh: "登录方式：{{flow}}";
        readonly en: "Sign-in: {{flow}}";
    };
    readonly 'provider-line-oauth-expires': {
        readonly zh: "令牌到期：{{time}}";
        readonly en: "Token expires: {{time}}";
    };
    readonly 'provider-line-oauth-out': {
        readonly zh: "已登出，本地 OAuth 凭据已删除";
        readonly en: "Signed out — the stored OAuth credential was removed";
    };
    readonly 'provider-q-action': {
        readonly zh: "要做什么？";
        readonly en: "What do you want to do?";
    };
    readonly 'provider-opt-action-add': {
        readonly zh: "添加新 provider";
        readonly en: "Add a new provider";
    };
    readonly 'provider-opt-action-add-desc': {
        readonly zh: "内置目录或自定义 API 端点";
        readonly en: "Built-in catalog or a custom API endpoint";
    };
    readonly 'provider-opt-action-edit': {
        readonly zh: "编辑已有 provider";
        readonly en: "Edit an existing provider";
    };
    readonly 'provider-opt-action-edit-desc': {
        readonly zh: "修改密钥、端点、协议、模型，或删除该 provider";
        readonly en: "Change the key, endpoint, protocol, or models — or delete the provider";
    };
    readonly 'provider-q-edit': {
        readonly zh: "选择要编辑的 provider";
        readonly en: "Choose a provider to edit";
    };
    readonly 'provider-none-configured': {
        readonly zh: "没有已配置的 provider，先用「添加新 provider」创建";
        readonly en: "No configured providers — create one with “Add a new provider” first";
    };
    readonly 'provider-row-models': {
        readonly zh: "{{n}} 个模型";
        readonly en: "{{n}} models";
    };
    readonly 'provider-row-catalog': {
        readonly zh: "整个 catalog";
        readonly en: "whole catalog";
    };
    readonly 'provider-row-key-shadowed': {
        readonly zh: "密钥来自环境变量";
        readonly en: "key from the environment";
    };
    readonly 'provider-q-edit-menu': {
        readonly zh: "{{route}} 要编辑哪一项？";
        readonly en: "What would you like to change for {{route}}?";
    };
    readonly 'provider-opt-edit-key': {
        readonly zh: "编辑 API Key";
        readonly en: "Edit API Key";
    };
    readonly 'provider-opt-edit-baseurl': {
        readonly zh: "编辑 Base URL";
        readonly en: "Edit Base URL";
    };
    readonly 'provider-opt-edit-protocol': {
        readonly zh: "编辑 wire protocol";
        readonly en: "Edit wire protocol";
    };
    readonly 'provider-opt-edit-models': {
        readonly zh: "编辑模型列表";
        readonly en: "Edit model list";
    };
    readonly 'provider-opt-edit-delete': {
        readonly zh: "删除该 provider";
        readonly en: "Delete this provider";
    };
    readonly 'provider-opt-edit-delete-desc': {
        readonly zh: "移除配置与 API key";
        readonly en: "Remove the configuration and the API key";
    };
    readonly 'provider-key-env-not-editable': {
        readonly zh: "{{route}} 的 API key 来自环境变量（{{ref}}），无法在此修改";
        readonly en: "{{route}}’s API key comes from the environment ({{ref}}) and cannot be edited here";
    };
    readonly 'provider-key-no-ref': {
        readonly zh: "{{route}} 未配置密钥引用（没有可持久化的 API key），无法在此修改";
        readonly en: "{{route}} has no credential ref (no persisted API key) and cannot be edited here";
    };
    readonly 'provider-line-key-none': {
        readonly zh: "密钥：未配置（无密钥引用，环境提供时按需读取）";
        readonly en: "Key: none configured (no credential ref; resolved from environment when present)";
    };
    readonly 'provider-key-empty': {
        readonly zh: "API key 不能为空，未作修改";
        readonly en: "API key cannot be empty — no change made";
    };
    readonly 'provider-q-key-overwrite-confirm': {
        readonly zh: "密钥 {{ref}} 被多个 provider 共用，确认覆盖？";
        readonly en: "Key ref {{ref}} is shared by several providers — overwrite it?";
    };
    readonly 'provider-opt-key-overwrite-yes': {
        readonly zh: "覆盖共用密钥";
        readonly en: "Overwrite the shared key";
    };
    readonly 'provider-key-overwrite-warning': {
        readonly zh: "⚠ 该密钥还被 {{routes}} 使用，写入新 key 会同时替换它们的凭据";
        readonly en: "⚠ This key is also used by {{routes}}; writing a new one rotates the credential for all of them";
    };
    readonly 'provider-row-model-missing': {
        readonly zh: "本次未发现（保留现有配置）";
        readonly en: "not found in this discovery (kept as configured)";
    };
    readonly 'provider-edit-no-changes': {
        readonly zh: "没有做任何修改";
        readonly en: "No changes made";
    };
    readonly 'provider-line-key-kept': {
        readonly zh: "密钥：保持不变（{{ref}}）";
        readonly en: "Key: unchanged ({{ref}})";
    };
    readonly 'provider-line-key-updated': {
        readonly zh: "密钥引用：{{ref}}（已更新）";
        readonly en: "Key ref: {{ref}} (updated)";
    };
    readonly 'provider-edit-current': {
        readonly zh: "当前值：{{value}}";
        readonly en: "Current: {{value}}";
    };
    readonly 'provider-edit-success': {
        readonly zh: "provider {{route}} 已更新";
        readonly en: "Provider {{route}} updated";
    };
    readonly 'provider-edit-cancelled': {
        readonly zh: "已取消编辑 provider";
        readonly en: "Provider edit cancelled";
    };
    readonly 'provider-q-delete-confirm': {
        readonly zh: "确认删除 provider {{route}}？";
        readonly en: "Delete provider {{route}}?";
    };
    readonly 'provider-opt-delete-yes': {
        readonly zh: "删除配置和密钥";
        readonly en: "Delete config and key";
    };
    readonly 'provider-delete-cancelled': {
        readonly zh: "已取消删除 provider";
        readonly en: "Provider deletion cancelled";
    };
    readonly 'provider-delete-success': {
        readonly zh: "provider {{route}} 已删除";
        readonly en: "Provider {{route}} deleted";
    };
    readonly 'provider-delete-failed': {
        readonly zh: "删除失败 · {{{err}}}";
        readonly en: "Failed to delete · {{{err}}}";
    };
    readonly 'provider-line-deleted-key': {
        readonly zh: "已删除密钥引用 {{ref}}";
        readonly en: "Removed key ref {{ref}}";
    };
    readonly 'provider-line-deleted-key-shadowed': {
        readonly zh: "密钥引用 {{ref}} 来自环境变量，未删除";
        readonly en: "Key ref {{ref}} comes from the environment; not removed";
    };
    readonly 'provider-delete-shared-warning': {
        readonly zh: "⚠ 密钥 {{ref}} 与 {{routes}} 共用，删除本 provider 不会移除该密钥";
        readonly en: "⚠ Key ref {{ref}} is shared with {{routes}}; deleting this provider keeps the key";
    };
    readonly 'provider-line-deleted-key-shared': {
        readonly zh: "密钥引用 {{ref}} 仍被 {{routes}} 使用，未删除";
        readonly en: "Key ref {{ref}} is still used by {{routes}}; not removed";
    };
    readonly 'provider-line-deleted-key-reserved': {
        readonly zh: "密钥引用 {{ref}} 属于宿主保留命名空间，未删除";
        readonly en: "Key ref {{ref}} is in the host-reserved credential namespace; not removed";
    };
    readonly 'provider-unknown-ref-users': {
        readonly zh: "（引用查询不可用）";
        readonly en: "(ref query unavailable)";
    };
    readonly 'provider-line-deleted-key-cleanup-failed': {
        readonly zh: "密钥引用 {{ref}} 清理失败，请手动检查 ~/.dsh/.credentials.yaml";
        readonly en: "Failed to remove key ref {{ref}} — check ~/.dsh/.credentials.yaml manually";
    };
    readonly 'provider-delete-key-cleanup-failed': {
        readonly zh: "provider {{route}} 已删除，但密钥 {{ref}} 清理失败，请手动处理";
        readonly en: "Provider {{route}} deleted, but removing key {{ref}} failed — clean it up manually";
    };
    readonly 'cmd-desc-new': {
        readonly zh: "新开会话";
    };
    readonly 'cmd-desc-clear': {
        readonly zh: "清空当前会话";
    };
    readonly 'cmd-desc-compact': {
        readonly zh: "压缩会话历史";
    };
    readonly 'cmd-desc-resume': {
        readonly zh: "恢复历史会话";
    };
    readonly 'cmd-desc-agentview': {
        readonly zh: "打开会话总览";
    };
    readonly 'cmd-desc-bg': {
        readonly zh: "当前会话转入后台并打开总览";
    };
    readonly 'cmd-desc-background': {
        readonly zh: "当前会话转入后台并打开总览";
    };
    readonly 'cmd-desc-rename': {
        readonly zh: "重命名当前会话";
    };
    readonly 'cmd-desc-recap': {
        readonly zh: "生成最近会话活动摘要（可应用建议标题）";
    };
    readonly 'cmd-desc-quit': {
        readonly zh: "退出 dsh-tui";
    };
    readonly 'cmd-desc-q': {
        readonly zh: "退出 dsh-tui";
    };
    readonly 'cmd-desc-rewind': {
        readonly zh: "回退会话到历史消息";
    };
    readonly 'cmd-desc-tree': {
        readonly zh: "浏览会话分叉树（回退/分叉/切分支）";
    };
    readonly 'cmd-desc-fork': {
        readonly zh: "把当前会话分叉为可恢复副本";
    };
    readonly 'cmd-desc-export': {
        readonly zh: "导出会话为 Markdown 文件";
    };
    readonly 'cmd-desc-context': {
        readonly zh: "查看已加载的上下文明细";
    };
    readonly 'cmd-desc-status': {
        readonly zh: "查看会话状态";
    };
    readonly 'cmd-desc-cost': {
        readonly zh: "查看会话 token 用量";
    };
    readonly 'cmd-desc-balance': {
        readonly zh: "查看 DeepSeek 账户余额";
    };
    readonly 'cmd-desc-config': {
        readonly zh: "查看 dsh-tui 配置来源";
    };
    readonly 'cmd-desc-reload': {
        readonly zh: "重读偏好文件并立即生效";
    };
    readonly 'cmd-desc-settings': {
        readonly zh: "查看和编辑插件设置";
    };
    readonly 'cmd-desc-doctor': {
        readonly zh: "运行环境检查";
    };
    readonly 'cmd-desc-init': {
        readonly zh: "在工作目录创建 AGENTS.md";
    };
    readonly 'cmd-desc-agents': {
        readonly zh: "查看本会话的子代理";
    };
    readonly 'cmd-desc-jobs': {
        readonly zh: "查看本会话的后台任务";
    };
    readonly 'cmd-desc-activity': {
        readonly zh: "切换工作状态指示器预设";
    };
    readonly 'cmd-desc-preset': {
        readonly zh: "切换 Agent 预设（含梁神模式）";
    };
    readonly 'cmd-desc-theme': {
        readonly zh: "切换配色主题（auto 跟随系统，或内置/静态 JSON/插件主题）";
    };
    readonly 'cmd-desc-color': {
        readonly zh: "设置当前会话强调色（输入框边框与会话标签）";
    };
    readonly 'cmd-desc-lang': {
        readonly zh: "切换界面语言（en / zh）";
    };
    readonly 'cmd-desc-model': {
        readonly zh: "查看当前模型";
    };
    readonly 'cmd-desc-thinking': {
        readonly zh: "显示或隐藏思考过程";
    };
    readonly 'cmd-desc-tokens': {
        readonly zh: "查看会话 token 用量";
    };
    readonly 'cmd-desc-provider': {
        readonly zh: "添加、编辑或删除模型提供方（内置目录或自定义 API 端点）";
    };
    readonly 'cmd-desc-login': {
        readonly zh: "查看 API 凭证状态";
    };
    readonly 'cmd-desc-logout': {
        readonly zh: "清除 API 凭证";
    };
    readonly 'cmd-desc-add-dir': {
        readonly zh: "查看文件系统策略范围";
    };
    readonly 'cmd-desc-hooks': {
        readonly zh: "查看 hooks 状态";
    };
    readonly 'cmd-desc-mcp': {
        readonly zh: "查看 MCP 状态";
    };
    readonly 'cmd-desc-skills': {
        readonly zh: "列出所有可用技能";
    };
    readonly 'cmd-desc-plugins': {
        readonly zh: "显示插件契约、授权与台账诊断";
    };
    readonly 'cmd-desc-update': {
        readonly zh: "更新 dsh-tui 并重启";
    };
    readonly 'cmd-desc-vim': {
        readonly zh: "切换 vim 模式";
    };
    readonly 'cmd-desc-terminal-setup': {
        readonly zh: "查看终端配置建议";
    };
    readonly 'cmd-desc-connect': {
        readonly zh: "连接远程机器";
    };
    readonly 'cmd-desc-workspace': {
        readonly zh: "切换、重命名或打开工作区";
    };
    readonly 'cmd-desc-workspace-resume': {
        readonly zh: "切换到另一个工作区";
        readonly en: "Switch to another workspace";
    };
    readonly 'cmd-desc-workspace-rename': {
        readonly zh: "重命名当前工作区";
        readonly en: "Rename the current workspace";
    };
    readonly 'cmd-desc-workspace-open': {
        readonly zh: "打开路径或工作区 URI";
        readonly en: "Open a path or workspace URI";
    };
    readonly 'cmd-desc-help': {
        readonly zh: "查看快捷键与命令";
    };
    readonly 'cmd-desc-restart': {
        readonly zh: "重启 dsh-tui 并恢复当前会话";
    };
    readonly 'cmd-desc-exit': {
        readonly zh: "退出 dsh-tui";
    };
    readonly 'cmd-desc-plan': {
        readonly zh: "切换计划模式（/plan off 退出）";
    };
    readonly 'cmd-desc-goal': {
        readonly zh: "设置或查看会话目标";
    };
    readonly 'cmd-desc-feedback': {
        readonly zh: "提交使用反馈";
    };
    readonly 'lang-current': {
        readonly zh: "当前语言  {{lang}}";
        readonly en: "Current language  {{lang}}";
    };
    readonly 'lang-switch-hint': {
        readonly zh: "切换      /lang en | /lang zh";
        readonly en: "Switch      /lang en | /lang zh";
    };
    readonly 'lang-persist-hint': {
        readonly zh: "持久化    ~/.dsh-tui/lang.json（重启后仍生效；DSH_TUI_LANG 优先）";
        readonly en: "Persisted    ~/.dsh-tui/lang.json (survives restart; DSH_TUI_LANG wins)";
    };
    readonly 'lang-switched': {
        readonly zh: "语言已切换：{{lang}}（已保存）";
        readonly en: "Language switched: {{lang}} (saved)";
    };
    readonly 'lang-unknown': {
        readonly zh: "未知语言「{{lang}}」· /lang 查看全部（en / zh）";
        readonly en: "Unknown language \"{{lang}}\" · /lang to view all (en / zh)";
    };
    readonly 'lang-switch-failed': {
        readonly zh: "语言「{{lang}}」切换失败（无法写入 ~/.dsh-tui/lang.json）";
        readonly en: "Language \"{{lang}}\" switch failed (cannot write ~/.dsh-tui/lang.json)";
    };
    readonly 'lang-picker-title': {
        readonly zh: "界面语言";
        readonly en: "UI language";
    };
    readonly 'lang-zh-desc': {
        readonly zh: "简体中文（默认）";
        readonly en: "Simplified Chinese (default)";
    };
    readonly 'lang-en-desc': {
        readonly zh: "English（英文）";
        readonly en: "English";
    };
    readonly 'status-cache-label': {
        readonly zh: "缓存 ";
        readonly en: "cache ";
    };
    readonly 'traj-title': {
        readonly zh: "轨迹";
        readonly en: "Trajectory";
    };
    readonly 'traj-totals': {
        readonly zh: "{{turns}} 轮 · {{steps}} 步";
        readonly en: "{{turns}} turns · {{steps}} rows";
    };
    readonly 'traj-errors': {
        readonly zh: "{{n}} 错";
        readonly en: "{{n}} failed";
    };
    readonly 'traj-retries': {
        readonly zh: "{{n}} 重试";
        readonly en: "{{n}} retries";
    };
    readonly 'traj-matches': {
        readonly zh: "{{n}}/{{total}} 匹配";
        readonly en: "{{n}}/{{total}} matched";
    };
    readonly 'traj-tab-timeline': {
        readonly zh: "时序";
        readonly en: "Timeline";
    };
    readonly 'traj-tab-hotspot': {
        readonly zh: "热点";
        readonly en: "Hotspot";
    };
    readonly 'traj-hot-tools': {
        readonly zh: "工具";
        readonly en: "Tools";
    };
    readonly 'traj-hot-model': {
        readonly zh: "模型";
        readonly en: "Model";
    };
    readonly 'traj-hot-turns': {
        readonly zh: "轮次";
        readonly en: "Turns";
    };
    readonly 'traj-sort-duration': {
        readonly zh: "按耗时";
        readonly en: "by duration";
    };
    readonly 'traj-sort-count': {
        readonly zh: "按次数";
        readonly en: "by count";
    };
    readonly 'traj-sort-tokens': {
        readonly zh: "按 token";
        readonly en: "by tokens";
    };
    readonly 'traj-proj-sequence': {
        readonly zh: "序号等宽";
        readonly en: "even";
    };
    readonly 'traj-proj-time': {
        readonly zh: "真实墙钟";
        readonly en: "wall-clock";
    };
    readonly 'traj-proj-compressed': {
        readonly zh: "压缩空闲";
        readonly en: "compressed";
    };
    readonly 'traj-hint-timeline': {
        readonly zh: "**↑/↓** 移动 · **←/→** 视图 · **[ ]** 跳错 · **{ }** 跳轮 · **/** 查询 · **m** 投影 · **enter** 详情 · **q** 退出";
        readonly en: "**↑/↓** move · **←/→** view · **[ ]** failures · **{ }** turns · **/** query · **m** projection · **enter** detail · **q** exit";
    };
    readonly 'traj-hint-hotspot': {
        readonly zh: "**↑/↓** 移动 · **←/→** 视图 · **t** 排序 · **enter** 回时序定位 · **q** 退出";
        readonly en: "**↑/↓** move · **←/→** view · **t** sort · **enter** locate in timeline · **q** exit";
    };
    readonly 'traj-hint-query': {
        readonly zh: "**tool:** **kind:** **turn:** **err:** **run:** **>10s** **tok>1k** · 裸词全文 · **enter** 确认 · **esc** 清除";
        readonly en: "**tool:** **kind:** **turn:** **err:** **run:** **>10s** **tok>1k** · bare word = full text · **enter** apply · **esc** clear";
    };
    readonly 'traj-hint-expanded': {
        readonly zh: "**j/k** 翻页 · **enter/esc** 收起 · **q** 退出";
        readonly en: "**j/k** page · **enter/esc** collapse · **q** exit";
    };
    readonly 'traj-hint-failure': {
        readonly zh: "{{key}} 看完整轨迹";
        readonly en: "{{key}} for the full trajectory";
    };
};
export type I18nKey = keyof typeof dict;
export type I18nParams = Record<string, string | number>;
/** Emitted on every language switch so React screens can re-render. */
type Listener = () => void;
/** Subscribe to language switches (mirrors themePrefs subscription style). */
export declare function subscribeLang(listener: Listener): () => void;
/** The currently active language. */
export declare function getLang(): Lang;
/** Switch the active language and notify subscribers. */
export declare function setLang(lang: Lang): void;
/** Is a string a valid shipped language code? */
export declare function isLang(value: unknown): value is Lang;
/**
 * Translate a dictionary key into the active language, substituting
 * `{{name}}` placeholders with params. Missing keys render the key itself
 * so a typo is visible instead of silently blank.
 * @param key - Dictionary key (see dict).
 * @param params - Placeholder values.
 */
export declare function t(key: I18nKey, params?: I18nParams): string;
/**
 * Translate a runtime-computed key (e.g. `cmd-desc-${name}`), falling back
 * to the given text when the key is missing or has no entry in the active
 * language — unlike {@link t}, which renders the key itself. Used where the
 * fallback holds the authoritative text (command descriptions: the en copy
 * lives in `LOCAL_COMMANDS` / the DSH registry, the dict carries zh only).
 * @param key - Dictionary key, computed at runtime so it is not type-checked.
 * @param fallback - Text used when no translation exists.
 * @param params - Placeholder values substituted into whichever text wins.
 */
export declare function tOr(key: string, fallback: string, params?: I18nParams): string;
/** Read-only view of the dictionary for audits (scripts/verify-i18n.ts). */
export declare const i18nDict: Readonly<Record<string, {
    readonly zh?: I18nText;
    readonly en?: I18nText;
}>>;
/**
 * Parse a persisted `{ lang }` value; anything else yields undefined.
 * @param text - Raw file contents.
 */
export declare function parseLangPref(text: string): Lang | undefined;
/** The persisted `/lang` choice, or undefined when unset or invalid. */
export declare function readLangPref(dir?: string): Lang | undefined;
/** Persist the chosen language (best effort). */
export declare function writeLangPref(lang: Lang, dir?: string): boolean;
/**
 * Guess the user's language from the OS locale (`LC_ALL`, `LC_MESSAGES`,
 * `LANG`). Only consulted when nothing else (env var, cordis.yml `lang`,
 * persisted `/lang` choice) pinned a language. `zh*` maps to zh; every
 * other stated locale (en, but also fr/de/ja/…) maps to en — English is
 * the lingua-franca fallback for a locale we don't ship, and a German
 * user must not get a Chinese UI. The POSIX/C locale means "no locale
 * selected" and conventionally maps to English — importantly it is what
 * CI runners (LANG=C.UTF-8) report, so tests asserting English UI copy
 * stay deterministic. Only an ABSENT locale (typical on Windows, where
 * these POSIX vars don't exist and imply nothing about the user) keeps
 * the zh default.
 */
export declare function detectLocaleLang(): Lang;
/**
 * Resolve the startup language: `DSH_TUI_LANG` when it holds a valid value
 * (pinned at process start — the repro/verify scripts rely on this for
 * deterministic UI copy), else the persisted `/lang` choice, else the OS
 * locale guess, else `zh` (the original hard-coded language). The
 * cordis.yml `lang` precedence lives in plugin.apply.
 */
export declare function resolveStartupLang(): Lang;
export {};
//# sourceMappingURL=i18n.d.ts.map
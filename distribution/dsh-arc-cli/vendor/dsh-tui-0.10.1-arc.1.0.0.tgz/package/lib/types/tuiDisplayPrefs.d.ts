import type { ToolBackground, ScrollGutterMode, PageMarginSetting, PageMarginMode, PageMarginSpec, StatusBarConfig } from './adapter/ports/channel-display.js';
export type { ToolBackground, ScrollGutterMode, PageMarginSetting, PageMarginMode, PageMarginSpec, StatusBarConfig } from './adapter/ports/channel-display.js';
/** Defaults keep the essential route/context information visible. */
export declare const DEFAULT_STATUS_BAR: Readonly<StatusBarConfig>;
/** Normalize untrusted/config-layer values without mutating the input. */
export declare function normalizeToolBackground(value: unknown): ToolBackground;
/** Same normalize contract as toolBackground; `timeline` is the default. */
export declare function normalizeScrollGutter(value: unknown): ScrollGutterMode;
/** Merge a partial settings value over the stable status-bar defaults. */
export declare function normalizeStatusBar(value: unknown): StatusBarConfig;
/**
 * Format context-window usage for future status-line consumers.
 * Invalid or unavailable inputs intentionally produce no field.
 */
export declare function formatContextUsage(used: number | undefined, contextWindow: number | undefined, compact?: boolean): string | undefined;
/** Page inset per preset: `{ x }` = blank columns per side, `{ y }` = blank
 *  rows top/bottom. `normal` is the default and matches the original
 *  hard-coded inset (2 columns / 1 row). */
export declare const PAGE_MARGIN_PRESETS: Readonly<Record<PageMarginMode, {
    readonly x: number;
    readonly y: number;
}>>;
export declare const DEFAULT_PAGE_MARGIN: PageMarginMode;
/** Custom-spec bounds: beyond this a layout is either useless (a 40-col
 *  terminal would starve) or pure waste. */
export declare const PAGE_MARGIN_MAX_X = 8;
export declare const PAGE_MARGIN_MAX_Y = 4;
export declare function isPageMarginMode(value: string): value is PageMarginMode;
/** Parse a custom spec (canonicalizes `N` → `Nx1`); undefined when invalid
 *  or out of bounds. */
export declare function parsePageMarginSpec(text: string): PageMarginSpec | undefined;
/** Normalize untrusted/config-layer values without mutating the input:
 *  preset names and valid custom specs pass through, everything else falls
 *  back to the default preset. */
export declare function normalizePageMargin(value: unknown): PageMarginSetting;
/** Resolve a stored setting to its geometry (presets via the table, custom
 *  specs via their numbers; anything unparseable → the default preset). */
export declare function resolvePageMargin(setting: PageMarginSetting): {
    readonly x: number;
    readonly y: number;
};
/** Subscribe to page-margin setting changes; returns the unsubscribe fn. */
export declare function subscribePageMargin(listener: () => void): () => void;
/** Current applied setting (normalized; safe for useSyncExternalStore —
 *  a primitive string identity is stable). */
export declare function getPageMarginSetting(): PageMarginSetting;
/** Apply a new setting (normalized, no-op when unchanged). Returns the
 *  value that ended up applied — useful for the plugin to mirror the
 *  channel. */
export declare function applyPageMargin(setting: unknown): PageMarginSetting;
//# sourceMappingURL=tuiDisplayPrefs.d.ts.map
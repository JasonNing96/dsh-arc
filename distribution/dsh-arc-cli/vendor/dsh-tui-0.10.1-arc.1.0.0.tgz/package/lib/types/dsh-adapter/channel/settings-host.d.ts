import type { Context } from '@deepseek-ai/cordis';
import type { ChannelState } from '../channel/types.js';
export declare function createSettingsHosts(ctx: Context, assertActive?: () => void): Pick<ChannelState, 'settingsHost' | 'providerSetup' | 'oauthProviderStatuses'>;
//# sourceMappingURL=settings-host.d.ts.map
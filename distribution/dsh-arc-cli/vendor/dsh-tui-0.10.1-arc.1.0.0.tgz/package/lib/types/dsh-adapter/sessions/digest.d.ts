import type { PreviewEntry, SessionDigest, SessionTitle } from './types.js';
/** Head window budget. Eight times the measured worst-case prompt offset. */
export declare const HEAD_WINDOW_BYTES: number;
/** Head frame ceiling — a cost bound independent of how the bytes compress. */
export declare const HEAD_MAX_FRAMES = 128;
/** Tail window budget. Wider than the head: trailing frames carry payloads. */
export declare const TAIL_WINDOW_BYTES: number;
/**
 * Read both windows of one session log.
 *
 * @param path - Absolute artifact path.
 * @param cwd - Working directory, for the last-resort title.
 * @returns The digest. An unreadable log still yields a usable record: the
 *   title falls back to the directory basename and says so through its source.
 */
export declare function digestSession(path: string, cwd: string): SessionDigest;
export interface SessionTitleRecovery {
    readonly title: SessionTitle | undefined;
    /** False means a damaged/oversized frame prevented a conclusive answer. */
    readonly complete: boolean;
    /** Known only when a full no-title scan then reached/ruled out the prompt. */
    readonly hasPrompt?: boolean;
}
/** Scan from a known frame boundary through an append-only suffix. */
export declare function recoverAppendedTitle(path: string, start: number, end: number, signal?: AbortSignal): Promise<{
    title: SessionTitle | undefined;
    complete: boolean;
}>;
/**
 * Recover the authoritative display title for one immutable file snapshot:
 * reverse scan for the LAST title, then (only when none exists) forward scan
 * for the FIRST human prompt. Both directions page on verified frame boundaries.
 */
export declare function recoverSessionTitle(path: string, bytes: number, signal?: AbortSignal): Promise<SessionTitleRecovery>;
/** Hash the previous EOF neighborhood before carrying title evidence forward. */
export declare function sessionTitleAnchor(path: string, bytes: number, signal?: AbortSignal): Promise<string | undefined>;
/**
 * The last exchanges of a session, for the browser's preview pane.
 *
 * Bounded like everything else here: the preview shows the end of the
 * conversation because that is what the tail window holds, and because the end
 * is what tells you whether this is the session you meant.
 *
 * @param path - Absolute artifact path.
 * @param limit - How many entries to keep, newest last.
 * @returns Entries in log order.
 */
export declare function previewSession(path: string, limit: number): PreviewEntry[];
//# sourceMappingURL=digest.d.ts.map
import { type foldBack as FoldBack } from './transcript.js';
import type { ChannelState, ToolViewPresenter } from './types.js';
type Shell = {
    resolve(request: {
        command: string;
        workdir?: string;
        timeoutMs: number;
    }): unknown;
    run(spec: unknown): Promise<{
        stdout: {
            text: string;
        };
        stderr: {
            text: string;
        };
        timedOut: boolean;
    }>;
};
/** Owns local-only transcript mutations, shell output, and live subagent queries. */
export declare function createLocalActions(deps: {
    ctx: {
        get(name: string): unknown;
    };
    owner: {
        current(): boolean;
    };
    binding: {
        capture(): unknown;
        isCurrent(capture: unknown): boolean;
        readonly agent: {
            session: unknown;
            followup(message: unknown): void;
        };
    };
    state: ChannelState;
    rowIds: {
        value: number;
    };
    projector: {
        reset(): void;
        presentCallView: NonNullable<ToolViewPresenter>['call'];
        presentResultView: NonNullable<ToolViewPresenter>['result'];
    };
    subagents: {
        dropRows(): void;
    };
    jobs: {
        dropRows(): void;
    };
    foldBack: typeof FoldBack;
    workspace: {
        describe(cwd: string): {
            kind: string;
            badge: string;
            label: string;
        };
        commandShell(cwd: string): Promise<Shell | undefined>;
    };
    shell?: Shell;
    notify: ChannelState['notify'];
}): {
    loadOlder(): number;
    clear(): void;
    pushLocal(title: string, lines: readonly string[]): void;
    setActivityFrames(name: string): boolean;
    listSubagents(): Promise<string[]>;
    runLocalCommand(command: string, includeInContext: boolean): Promise<void>;
};
export {};
//# sourceMappingURL=local-actions.d.ts.map
import type { Context } from '@deepseek-ai/cordis';
import type { SessionExecutionDriver } from './session-execution.js';
/** The external UI intentionally has no Agent-shaped object or host controls. */
export declare function mountExternalExecutionTui(ctx: Context, driver: SessionExecutionDriver, release: () => Promise<void>, onRevoked: (listener: () => void) => () => void, options?: {
    fullscreen?: boolean;
    terminalImages?: boolean;
    onUserExit?: (code: number) => Promise<void>;
}): Promise<void>;
//# sourceMappingURL=external-execution-tui.d.ts.map
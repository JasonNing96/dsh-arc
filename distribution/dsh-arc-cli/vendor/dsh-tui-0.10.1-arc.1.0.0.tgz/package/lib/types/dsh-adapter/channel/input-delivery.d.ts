import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { type UserMessage } from '@deepseek-ai/dsh-llm';
import { type ComposerImages } from './composer-images.js';
import type { ChannelOwner } from './owner.js';
import type { ChannelImageBlock, ChannelState, ComposerImageRef, MentionAttachments, MentionFs, PendingMessage, StagedImageInput } from './types.js';
/** One submission's enqueue-time world: the session it was typed in, the
 *  services that resolve its references, and the capabilities live then. */
interface UserTextOrigin {
    readonly agent: Agent;
    readonly agentId: string;
    readonly generation: number;
    readonly cwd: string;
    readonly fs: MentionFs | undefined;
    readonly attachments: MentionAttachments | undefined;
    readonly stagedImages: ReadonlyMap<string, ChannelImageBlock['attachment']>;
}
/** Input FIFO, staged attachments and decision notice timers share one lifetime. */
export declare function createInputDelivery(ctx: Context, owner: ChannelOwner, binding: {
    readonly agent: Agent;
}, state: () => Pick<ChannelState, 'cwd' | 'agentId' | 'agentBindingGeneration'>, notify: ChannelState['notify'], trackPending: (message: {
    id: string;
    text: string;
    images?: readonly ComposerImageRef[];
}, placement: PendingMessage['placement']) => void, untrackPending: (id: string) => void, composer: ComposerImages): {
    dispatchUserText: (text: string, placement: PendingMessage["placement"], images?: readonly ComposerImageRef[], attach?: UserMessage) => void;
    deliverUserText: (text: string, placement: PendingMessage["placement"], images?: readonly ComposerImageRef[], attach?: UserMessage) => void;
    claimAttachments: (messages: readonly UserMessage[]) => UserMessage[];
    retireAttachment: (messageId: string) => void;
    withDecisionPending: <T>(name: string, pending: Promise<T>, origin?: UserTextOrigin) => Promise<T>;
    clearStagedImages: () => void;
    stageImage: (input: StagedImageInput) => Promise<string>;
    stagedImages: () => ReadonlyMap<string, ChannelImageBlock["attachment"]>;
    composer: ComposerImages;
};
export {};
//# sourceMappingURL=input-delivery.d.ts.map
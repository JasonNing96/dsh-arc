import type { Agent, AssistantStreamFrame } from '@deepseek-ai/dsh-agent';
import { SubagentActivityStore } from '../subagents.js';
import type { ChannelState, SubagentControl } from './types.js';
/** Current-session subagent store, row projection and frame-batched stream
 * bridge. The owning channel installs transport subscriptions; this module
 * only accepts scoped events and never captures a replaceable agent itself. */
export declare function createSubagentProjection(getState: () => Pick<ChannelState, 'rows' | 'subagents' | 'emit' | 'emitStream'>, deps: {
    rowIds: {
        value: number;
    };
    agent(): Agent;
    subagents(): {
        interrupt?(target: string, reason: unknown): void;
    } | undefined;
    /** Optional child metadata lookup; failures must not suppress spawning. */
    lookupChild(id: string): {
        session?: unknown;
        options?: {
            provider?: string;
            model?: string;
        };
    } | undefined;
}): {
    store: SubagentActivityStore;
    control: SubagentControl;
    pendingTaskDescriptions: string[];
    onSessionEvent: (session: unknown, event: {
        type?: string;
    }) => boolean;
    onStreamFrame: (agent: unknown, frame: AssistantStreamFrame) => boolean;
    onStart: (info: {
        id: string;
        runId?: string;
        provider: string;
        local?: boolean;
    }) => void;
    onEnd: (info: {
        id: string;
        stopReason: string;
        lastAssistantMessage?: unknown[];
    }) => void;
    syncNow: () => void;
    flush: () => boolean;
    dropRows: () => void;
    reset: () => void;
};
//# sourceMappingURL=subagent-projection.d.ts.map
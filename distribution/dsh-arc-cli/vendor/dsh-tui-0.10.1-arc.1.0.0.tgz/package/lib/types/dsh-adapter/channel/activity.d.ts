import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { ChannelOwner } from './owner.js';
import type { ActivityStatus, ChannelState } from './types.js';
/**
 * Owns the optional working-activity sidecar. It has no transcript authority:
 * callers route durable events to the sole projector separately, while this
 * object derives only a presentational status line and its 500ms clock.
 */
export declare function createChannelActivity(ctx: Context, state: ChannelState, owner: ChannelOwner, enabled: boolean): {
    start: (agent: Agent) => void;
    stop: () => void;
    onAgentStatus: (status: Agent["status"]) => ActivityStatus | undefined;
    onSessionEvent: (event: SessionEvent) => ActivityStatus | undefined;
    onModelSwitch(model: string): import("../../adapter/ports/channel-view.js").ActivityState | undefined;
    onCompact(): import("../../adapter/ports/channel-view.js").ActivityState | undefined;
    onGitBranch(branch: string): import("../../adapter/ports/channel-view.js").ActivityState | undefined;
};
//# sourceMappingURL=activity.d.ts.map
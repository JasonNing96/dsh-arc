import type { AgentHandle } from '@deepseek-ai/dsh-agent';
import type { SessionModeSpec } from '../../sessionModes.js';
import { type PageMarginSetting, type ScrollGutterMode, type StatusBarConfig, type ToolBackground } from '../../tuiDisplayPrefs.js';
import type { ChannelState } from './types.js';
/** Launch configuration belongs to channel construction, not the composition root. */
export interface ChannelLaunchOptions {
    model: string;
    cwd: string;
    provider: string;
    effort?: string;
    activity?: boolean;
    activityFrames?: string;
    diffLayout?: 'auto' | 'split' | 'unified';
    thinkingFold?: 'preview' | 'full';
    toolBackground?: ToolBackground;
    scrollGutter?: ScrollGutterMode;
    pageMargin?: PageMarginSetting;
    foldTerminalCommand?: boolean;
    promptSessionLabel?: boolean;
    expandEditor?: boolean;
    smoothStreaming?: boolean;
    statusBar?: Partial<StatusBarConfig>;
    whale?: boolean;
    whaleIdle?: boolean;
    minimal?: boolean;
    contextBar?: boolean;
    configuredPreset?: string;
    configuredProvider?: string;
    configuredModel?: string;
    configuredLang?: string;
    configuredActivityFrames?: string;
    agentPreset?: string;
    modes?: readonly SessionModeSpec[];
    handle?: AgentHandle;
}
/**
 * Neutral observable fields only. Behaviour is assembled explicitly by the
 * composition root after each specialist owner exists, so this factory cannot
 * acquire services, subscribe, or create a second authority bag.
 */
export declare function createInitialChannelView(options: ChannelLaunchOptions, input: {
    agentId: string;
    mode: ChannelState['mode'];
    cwdDescription: string;
}): Pick<ChannelState, 'effortLevels' | 'version' | 'rows' | 'status' | 'sessionTitle' | 'sessionColor' | 'agentId' | 'agentBindingGeneration' | 'model' | 'provider' | 'tokens' | 'cwd' | 'displayCwd' | 'gitBranch' | 'working' | 'cancelPending' | 'spinnerMode' | 'responseChars' | 'activeToolCount' | 'turnStart' | 'lastUserText' | 'notifications' | 'contextWindow' | 'reasoningEffort' | 'mode' | 'modeIndex' | 'workingActivity' | 'activityFrames' | 'configuredProvider' | 'configuredModel' | 'configuredPreset' | 'configuredActivityFrames' | 'configuredLang' | 'diffLayout' | 'thinkingFold' | 'toolBackground' | 'scrollGutter' | 'pageMargin' | 'foldTerminalCommand' | 'promptSessionLabel' | 'expandEditor' | 'smoothStreaming' | 'statusBar' | 'whale' | 'whaleIdle' | 'minimal' | 'activityEnabled' | 'contextBarEnabled' | 'agentPreset' | 'goal' | 'todos' | 'loadedContext' | 'pending' | 'commandList' | 'lastUsage' | 'tps' | 'tpsSamples' | 'contextSegments' | 'subagents' | 'backgroundJobs'>;
//# sourceMappingURL=state.d.ts.map
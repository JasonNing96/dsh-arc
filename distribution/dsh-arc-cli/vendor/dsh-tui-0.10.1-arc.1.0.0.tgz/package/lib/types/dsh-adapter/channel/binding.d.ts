import type { Agent, AgentHandle } from '@deepseek-ai/dsh-agent';
import type { ChannelOwner } from './owner.js';
export interface BindingCapture {
    readonly agent: Agent;
    readonly generation: number;
}
export interface BindingCommit {
    readonly agent: Agent;
    readonly handle: AgentHandle | undefined;
    readonly generation: number;
}
type PreviousDisposition = 'dispose' | 'park';
/**
 * Sole writer of the attached Agent/handle identity and binding generation.
 *
 * A prepared handle remains owned by this cell until its synchronous adoption
 * tail returns.  The tail is deliberately callback-shaped: it cannot leave a
 * committed identity waiting for a microtask watchdog to infer whether setup
 * completed, and a throw always revokes the transaction immediately.
 */
export declare function createChannelBinding(initial: Agent, handle: AgentHandle | undefined, owner: ChannelOwner): {
    readonly agent: Agent;
    readonly handle: AgentHandle | undefined;
    readonly generation: number;
    capture(): BindingCapture;
    isCurrent(capture: BindingCapture): boolean;
    /** Create a candidate without giving it authority over the live binding. */
    prepare(capture: BindingCapture, create: () => Promise<AgentHandle>): Promise<AgentHandle>;
    /** Dispose an uncommitted candidate exactly once. Live handles are inert. */
    abandon(candidate: AgentHandle): Promise<void>;
    /** Perform one explicit synchronous prepared-handle adoption transaction. */
    adopt: <T>(candidate: AgentHandle, capture: BindingCapture, tail: (previous: BindingCommit, disposition: (next: PreviousDisposition) => void) => T) => T;
    /** Perform one explicit synchronous already-live-agent adoption transaction. */
    switchTo: <T>(agent: Agent, nextHandle: AgentHandle | undefined, tail: (previous: BindingCommit, disposition: (next: PreviousDisposition) => void) => T) => T;
    bind(): number;
    subscribe(dispose: () => void): void;
    clearSubscriptions: (afterEach?: () => void) => unknown;
};
export type ChannelBinding = ReturnType<typeof createChannelBinding>;
export {};
//# sourceMappingURL=binding.d.ts.map
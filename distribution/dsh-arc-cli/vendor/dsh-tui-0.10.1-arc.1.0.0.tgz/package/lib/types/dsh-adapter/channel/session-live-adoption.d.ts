import type { Agent, AgentHandle } from '@deepseek-ai/dsh-agent';
import { resetSessionProjection } from './session-reset.js';
import type { createChannelBinding } from './binding.js';
import type { ChannelState, ResumeResult } from './types.js';
type Binding = ReturnType<typeof createChannelBinding>;
type LiveAdoptionState = Pick<ChannelState, 'status' | 'agentId' | 'cwd' | 'displayCwd' | 'agentPreset' | 'provider' | 'model' | 'loadedContext' | 'contextWindow' | 'effortLevels' | 'reasoningEffort' | 'tps' | 'tpsSamples' | 'lastUsage' | 'workingActivity' | 'working' | 'emit'> & Parameters<typeof resetSessionProjection>[0];
/** Adopt an already-live agent, preserving a meaningful previous handle in the background ledger. */
export declare function createLiveAgentAdoption(state: LiveAdoptionState, deps: {
    binding: Pick<Binding, 'switchTo'>;
    backgroundHandles: Map<string, AgentHandle>;
    rowIds: {
        value: number;
    };
    resetProjector(): void;
    resetSubagents(): void;
    resetJobs(): void;
    replay(events: readonly import('@deepseek-ai/dsh-session').SessionEvent[]): void;
    settleReplay(): void;
    describeWorkspace(cwd: string): {
        description?: string;
    };
    refreshGitBranch(): void;
    bindAgent(): void;
    refreshCommands(): void;
    refreshLoadedContext(): Promise<void>;
    refreshSkillCommands(): Promise<void>;
    clearStagedImages(): void;
    notifySessionSwitched(kind: 'agent-view', sessionId: string, previousSessionId: string): void;
    notifyAgentView(): void;
}): (target: Agent) => Promise<ResumeResult>;
export {};
//# sourceMappingURL=session-live-adoption.d.ts.map
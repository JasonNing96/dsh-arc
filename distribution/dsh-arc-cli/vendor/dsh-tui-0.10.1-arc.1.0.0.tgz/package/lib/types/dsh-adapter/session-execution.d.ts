/** Public, renderer-free external execution driver contract. */
import type { Context } from '@deepseek-ai/cordis';
export type SessionExecutionPermissionOutcome = 'allow' | 'deny';
export declare const SESSION_EXECUTION_API_VERSION = 1;
/** A detached projection; durable state remains owned by the driver. */
export interface SessionExecutionRow {
    readonly id: number;
    readonly kind: 'user' | 'assistant' | 'reasoning' | 'notice' | 'tool';
    readonly text: string;
    readonly time: number;
    readonly streaming?: boolean;
    readonly tool?: {
        readonly callId: string;
        readonly name: string;
        readonly status: 'running' | 'ok' | 'error';
        readonly resultText?: string;
    };
}
export type SessionExecutionCommandOutcome = {
    readonly kind: 'success';
    readonly text: string;
    readonly consumeDraft: true;
} | {
    readonly kind: 'error';
    readonly text: string;
    readonly consumeDraft: boolean;
};
export interface SessionExecutionSnapshot {
    readonly uiSessionId: string;
    readonly executionSessionId: string;
    readonly title: string;
    readonly working: boolean;
    /** Current text projection for initial mount or recovery. */
    readonly text?: string;
    readonly rows?: readonly SessionExecutionRow[];
    readonly cwd?: string;
    readonly model?: string;
    readonly draft?: string;
}
export type SessionExecutionEvent = 
/** Idle/transition updates have their own monotonic generation, not a fake prompt. */
{
    readonly type: 'session';
    readonly generation: number;
    readonly snapshot: SessionExecutionSnapshot;
} | {
    readonly type: 'snapshot';
    readonly turnId: string;
    readonly snapshot: SessionExecutionSnapshot;
} | {
    readonly type: 'text';
    readonly turnId: string;
    readonly delta: string;
} | {
    readonly type: 'permission';
    readonly turnId: string;
    readonly requestId: string;
    readonly title: string;
};
export interface SessionExecutionDriver {
    readonly id: string;
    readonly capabilities: ReadonlySet<'submit' | 'cancel' | 'permission-reply' | 'commands' | 'draft'>;
    readonly commands?: readonly {
        readonly name: string;
        readonly description: string;
    }[];
    command?(name: string, rawInput: string): Promise<SessionExecutionCommandOutcome | undefined>;
    /** Synchronous editor observation; the driver persists through its own queue. */
    updateDraft?(text: string): void;
    snapshot(): SessionExecutionSnapshot;
    subscribe(listener: (event: SessionExecutionEvent) => void): () => void;
    submit(text: string, turnId: string): boolean;
    cancel(): Promise<void>;
    replyPermission(requestId: string, outcome: SessionExecutionPermissionOutcome): Promise<void>;
    close(): Promise<void>;
}
export interface TuiSessionExecutionRegistry {
    register(pluginCtx: Context, driver: SessionExecutionDriver): () => Promise<void>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        tuiSessionExecution: TuiSessionExecutionRegistry;
    }
}
//# sourceMappingURL=session-execution.d.ts.map
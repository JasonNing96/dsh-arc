import type { Agent } from '@deepseek-ai/dsh-agent';
import type { Context } from '@deepseek-ai/cordis';
import type { ChannelOwner } from './owner.js';
import type { ChannelState } from './types.js';
type CompactionState = Pick<ChannelState, 'agentId' | 'cwd' | 'working'>;
type Notify = ChannelState['notify'];
/** Owns the one manual compaction transaction that must settle before a switch. */
export declare function createManualCompaction(ctx: Context, state: CompactionState, deps: {
    owner: Pick<ChannelOwner, 'current' | 'signal' | 'own'>;
    agent(): Agent;
    withDecisionPending<T>(name: string, pending: Promise<T>): Promise<T>;
    notify: Notify;
    onComplete(): void;
}): {
    compact: () => void;
    settle: () => Promise<void>;
};
export {};
//# sourceMappingURL=compaction.d.ts.map
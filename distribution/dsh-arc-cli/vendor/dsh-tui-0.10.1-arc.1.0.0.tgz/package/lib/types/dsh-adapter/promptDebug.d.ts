import type { Context } from '@deepseek-ai/cordis';
export declare const PROMPT_DEBUG_FILENAME = ".dsh-prompt-debug.json";
export declare function registerPromptDebug(ctx: Context): void;
//# sourceMappingURL=promptDebug.d.ts.map
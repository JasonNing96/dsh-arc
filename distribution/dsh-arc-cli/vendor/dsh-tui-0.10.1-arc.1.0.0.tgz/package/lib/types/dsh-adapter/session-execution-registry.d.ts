/** Cordis-owned registry for optional, renderer-free session drivers. */
import { Context, Service } from '@deepseek-ai/cordis';
import type { SessionExecutionDriver, TuiSessionExecutionRegistry } from './session-execution.js';
export interface HostSessionExecutionSelection {
    readonly driver: SessionExecutionDriver;
    release(): Promise<void>;
    /** Fires synchronously when the owner unloads or this lease is released. */
    onRevoked(listener: () => void): () => void;
}
export interface HostSessionExecution {
    acquire(id: string): HostSessionExecutionSelection | undefined;
}
export declare class TuiSessionExecutionRuntime extends Service implements TuiSessionExecutionRegistry {
    constructor(ctx: Context);
    register(_pluginCtx: Context, driver: SessionExecutionDriver): () => Promise<void>;
}
/** Host-only lookup; plugins cannot list or retrieve another driver's object. */
export declare function getHostSessionExecution(runtime: TuiSessionExecutionRegistry | undefined): HostSessionExecution | undefined;
//# sourceMappingURL=session-execution-registry.d.ts.map
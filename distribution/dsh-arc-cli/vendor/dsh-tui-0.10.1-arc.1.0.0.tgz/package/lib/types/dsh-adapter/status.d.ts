/**
 * Keyed status contributions above the prompt.
 *
 * `set(key, text)` remains pi's scalar `ctx.ui.setStatus` seam: the host
 * sanitizes and joins every text contribution into one line. `registerView`
 * is the bounded rich companion for compact, pointer-only surfaces that need
 * host React and themed cells (for example a progress card). It deliberately
 * receives no input, channel, or raw-terminal capability.
 *
 * Same split as the dialogs seam: a cordis-free store the chat screen
 * subscribes to, and a thin cordis service validating untrusted input.
 */
import type React from 'react';
import { Context, Service } from '@deepseek-ai/cordis';
/** One rendered contribution. */
export interface TuiStatusEntry {
    readonly key: string;
    readonly text: string;
}
/** Maximum height a rich status contribution may request. */
export type TuiStatusViewMaxRows = 1 | 2 | 3;
type TuiStatusViewForbiddenBoxProps = 'ref' | 'tabIndex' | 'autoFocus' | 'onContextMenu' | 'onFocus' | 'onFocusCapture' | 'onBlur' | 'onBlurCapture' | 'onKeyDown' | 'onKeyDownCapture' | 'onWheel';
type TuiStatusViewBoxProps = Omit<React.ComponentProps<typeof import('../ui.js').Box>, TuiStatusViewForbiddenBoxProps>;
type TuiStatusViewTextProps = Omit<React.ComponentProps<typeof import('../ui.js').Text>, 'ref'>;
type TuiStatusViewImageProps = React.ComponentProps<typeof import('../ui.js').Image>;
/** Pointer-only host kit passed to rich status components. `Box` keeps local
 * click, hover, and captured-drag handlers, but cannot take focus, keyboard,
 * context-menu, wheel, or ref props. Raw-terminal APIs are absent. */
export interface TuiStatusViewUi {
    readonly Box: React.ComponentType<TuiStatusViewBoxProps>;
    readonly Image: React.ComponentType<TuiStatusViewImageProps>;
    readonly Text: React.ComponentType<TuiStatusViewTextProps>;
    readonly useTerminalSize: typeof import('../ui.js').useTerminalSize;
}
/** Props for a rich status component. Hooks and elements must use the host
 * React instance, following the same single-React rule as plugin scenes. */
export interface TuiStatusViewProps {
    readonly React: typeof React;
    readonly ui: TuiStatusViewUi;
}
/** Cleanup handle returned for an admitted rich status registration. */
export type TuiStatusViewDisposer = () => void;
/** One compact status view rendered above the prompt. Keyboard input is not
 * exposed; pointer interaction is available through `Box` click/hover/drag
 * handlers and should be paired with a slash command or separately registered
 * `tuiShortcuts` action. */
export interface TuiStatusViewDescriptor {
    readonly key: string;
    /** Defaults to one row; the host clips every view at three rows. */
    readonly maxRows?: TuiStatusViewMaxRows;
    readonly component: React.ComponentType<TuiStatusViewProps>;
}
/** Host-side normalized registration. Kept out of the plugin export shim. */
export interface TuiStatusViewEntry {
    readonly key: string;
    readonly maxRows: TuiStatusViewMaxRows;
    readonly component: React.ComponentType<TuiStatusViewProps>;
    /** Remounts the error boundary after a dispose + same-key re-registration. */
    readonly registrationId: number;
}
/** Cordis-free text + view store. Render order is first-set/register order
 * (Map insertion order), so plugin contributions do not jump on updates. */
export declare class TuiStatusStore {
    private readonly onViewError?;
    private readonly listeners;
    private readonly entries;
    private readonly views;
    private snapshot;
    private viewSnapshot;
    constructor(onViewError?: ((key: string, error: Error) => void) | undefined);
    /** Set or clear (undefined/empty) one key. */
    set(key: string, text: string | undefined, token?: number, owner?: object): void;
    /** Current contributions, first-set first (stable between changes). */
    getSnapshot(): readonly TuiStatusEntry[];
    /** Current rich contributions, first-registration first and referentially
     * stable between mutations for `useSyncExternalStore`. */
    getViewSnapshot(): readonly TuiStatusViewEntry[];
    /** Host runtime uses this to enforce that one activation cannot rewrite or
     * clear another activation's keyed contribution. */
    ownerOf(key: string): object | undefined;
    viewOwnerOf(key: string): object | undefined;
    addView(view: TuiStatusViewEntry, token: number, owner: object): void;
    clearViewIf(key: string, token: number, owner?: object): boolean;
    /** Called only by the host-side error boundary. */
    reportViewError(key: string, error: Error): void;
    /** Clear `key` only while it still holds the write tagged `token` — a
     *  stale disposer must not wipe a newer contribution (even one with
     *  identical text). Returns true when this call actually cleared. */
    clearIf(key: string, token: number, owner?: object): boolean;
    /** Drop everything (teardown). */
    clear(): void;
    subscribe(listener: () => void): () => void;
    private emit;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        tuiStatus: TuiStatusRuntime;
    }
}
/**
 * `ctx.tuiStatus` — plugin-facing status contributions. Invalid keys and
 * oversized text are rejected with a logger warning instead of throwing:
 * a status contribution must never take the TUI down.
 */
export declare class TuiStatusRuntime extends Service {
    constructor(ctx: Context);
    /**
     * Set (or clear with `undefined`) the contribution for `key`. Keys are
     * plugin-namespaced by convention (`my-plugin`, `my-plugin:detail`);
     * control chars are stripped and text is capped at 200 cells. Text is
     * scalar-only: string/number/boolean are coerced to string, anything else
     * is refused with a warning (never rendered as "[object Object]", never
     * silently treated as a clear).
     *
     * Returns a disposer that clears the contribution IF the key still holds
     * exactly this write (a later set — even of identical text — wins over a
     * stale disposer). The host also removes that disposer from the caller's
     * Cordis effect list when it is invoked explicitly. Clearing with
     * `undefined` or empty text happens immediately and returns a no-op without
     * registering an owner effect.
     *
     * The optional trailing `identity` (the plugin's own ctx) only feeds the
     * effect ledger's pluginId — omitting it records `undeclared`, never a
     * guess (C-060 honest identity).
     */
    set(key: string, text: string | number | boolean | undefined, identity?: Context): () => void;
    /**
     * Register a compact React view above the prompt. The component receives
     * the host's React plus a pointer-only UI kit; it owns its live data via an
     * external store and is clipped by the host to `maxRows` (one by default,
     * three at most). Registrations share the text key namespace, preserve
     * first-registration order, and consume a six-row aggregate budget.
     *
     * Successful registrations return a cleanup-aware disposer. Refused
     * registrations warn and return `undefined`, so feature-detecting callers
     * can distinguish admission from rejection. The optional identity has the
     * same attribution-only meaning as `set()`.
     */
    registerView(descriptor: TuiStatusViewDescriptor, identity?: Context): TuiStatusViewDisposer | undefined;
    /**
     * Subscribe to status-line changes. Kept on the plugin-visible service so
     * the shadow-policy gate covers this subscription effect too.
     */
    subscribe(listener: () => void): () => void;
}
export declare function getHostStatusStore(runtime: TuiStatusRuntime | undefined): TuiStatusStore | undefined;
export default TuiStatusRuntime;
//# sourceMappingURL=status.d.ts.map
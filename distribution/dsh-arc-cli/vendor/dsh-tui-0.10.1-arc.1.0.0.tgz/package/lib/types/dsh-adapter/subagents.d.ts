import type { AssistantStreamFrame } from '@deepseek-ai/dsh-agent';
import type { SubagentState, SubagentOutputKind, SubagentToolCall } from '../adapter/ports/channel-view.js';
export type { SubagentState, SubagentStatus, SubagentOutputLine, SubagentOutputKind, SubagentToolCall, SubagentTokenUsage } from '../adapter/ports/channel-view.js';
export declare class SubagentActivityStore {
    private states;
    private sessionToAgent;
    private listeners;
    private streams;
    private commitLine;
    private pushLine;
    onSpawned(agentId: string, provider?: string, model?: string, info?: Partial<SubagentState>): void;
    linkSession(agentId: string, session: unknown): void;
    getSubagentIdBySession(session: unknown): string | undefined;
    appendOutput(agentId: string, text: string, kind?: SubagentOutputKind): void;
    /** Mark the streaming tail line complete (run settlement). */
    flushOutput(agentId: string): void;
    /** 0.1.5 live stream: transient attempt frames replace `assistant/chunk`
     *  session events (the durable settlement keeps flowing as session events). */
    onStreamFrame(agentId: string, frame: AssistantStreamFrame): void;
    private restoreAttempt;
    private settleAssistant;
    onSessionEvent(agentId: string, event: unknown): void;
    /** Merge partial updates (model discovery, session id) into one subagent. */
    patch(agentId: string, partial: Partial<SubagentState>): void;
    /** One-line preview of a tool-result content block (text or item list). */
    private previewOf;
    recordTool(agentId: string, input: Partial<SubagentToolCall> & {
        name?: string;
    }): void;
    setTokens(agentId: string, usage: {
        inputTokens?: number;
        outputTokens?: number;
        input?: number;
        output?: number;
        total?: number;
        context?: number;
    }): void;
    onCompleted(agentId: string, summary?: string, stopReason?: string): void;
    onFailed(agentId: string, error: string): void;
    onCancelled(agentId: string, reason?: string, summary?: string): void;
    private finish;
    /** Drop all tracked subagents and session links (session swap: the old
     * session's children were disposed with their parent — nothing may keep
     * routing events of a session the channel no longer projects). */
    reset(): void;
    snapshot(): SubagentState[];
    get(agentId: string): SubagentState | undefined;
    subscribe(listener: () => void): () => void;
    private notify;
}
//# sourceMappingURL=subagents.d.ts.map
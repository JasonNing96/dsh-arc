/** Status words shown while a DSH turn is running. */
export declare const SPINNER_VERBS: string[];
//# sourceMappingURL=spinnerVerbs.d.ts.map
export { name, TuiSettingsSectionsRuntime } from './dsh-adapter/settings-sections.js';
export type { TuiSettingsFieldKind, TuiSettingsFieldOption, TuiSettingsGroup, TuiSettingsFieldWrite, TuiSettingsField, TuiSettingsSection, } from './dsh-adapter/settings-sections.js';
export { default } from './dsh-adapter/settings-sections.js';
//# sourceMappingURL=settings-sections.d.ts.map
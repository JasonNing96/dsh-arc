# dsh-arc-acp

DSH 的可选 ACP 集成 Bundle，要求同一 Profile 已包含标准 ACP app 和匹配版本的 `dsh-arc`。

安装后禁用原 `acp` 条目、插入 `arc-acp`，并读取原条目的配置。模型路由继续在原 `acp.config` 配置。卸载本 Bundle 时，这两项配置覆盖一并消失，原版 ACP 恢复，不需要手工清理 ARC 配置行。

会话仍由 DSH 持久保存；卸载集成后客户端应使用原版 ACP 能力。

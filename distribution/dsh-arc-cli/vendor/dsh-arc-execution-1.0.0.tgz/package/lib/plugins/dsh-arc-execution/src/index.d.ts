/** Optional execution owner. TUI imports only the public session-driver contract. */
import { type Context } from '@deepseek-ai/cordis';
import { type SessionExecutionDriver, type SessionExecutionEvent, type SessionExecutionSnapshot, type SessionExecutionCommandOutcome } from '@deepseek-harness-tui/dsh-tui/session-execution';
import { type Connector } from '../../../tui/src/arc-controller.js';
import { type RuntimeConfig } from '../../../tui/src/runtime-config.js';
import { type RemoteConfig } from '../../../tui/src/remote-config.js';
export declare const name = "arc-execution";
export declare const inject: string[];
export interface Config {
    readonly local: {
        readonly cwd: string;
        readonly dshHome: string;
        readonly stateDir: string;
        readonly dshExecutable: string;
        readonly arcProfile: string;
    };
    readonly remoteConfig?: string;
    readonly fresh?: boolean;
    readonly switchShortcut?: string;
    readonly reconnectShortcut?: string;
}
/** The same driver is exercised with deterministic ACP transports in acceptance. */
export declare class ArcExecutionDriver implements SessionExecutionDriver {
    readonly id = "arc";
    readonly capabilities: SessionExecutionDriver['capabilities'];
    readonly commands: {
        name: string;
        description: string;
    }[];
    private readonly controller;
    private readonly listeners;
    private activeTurn;
    private generation;
    private lastPermission;
    private closed;
    private closePromise;
    private draftTimer;
    constructor(config: RuntimeConfig, remote: RemoteConfig | undefined, connector?: Connector);
    start(fresh?: boolean): Promise<void>;
    private emit;
    private changed;
    snapshot(): SessionExecutionSnapshot;
    subscribe(listener: (event: SessionExecutionEvent) => void): () => void;
    submit(text: string, turnId: string): boolean;
    cancel(): Promise<void>;
    replyPermission(requestId: string, outcome: 'allow' | 'deny'): Promise<void>;
    updateDraft(text: string): void;
    command(name: string, rawInput: string): Promise<SessionExecutionCommandOutcome | undefined>;
    close(): Promise<void>;
}
export declare function apply(ctx: Context, config: Config): Promise<void>;

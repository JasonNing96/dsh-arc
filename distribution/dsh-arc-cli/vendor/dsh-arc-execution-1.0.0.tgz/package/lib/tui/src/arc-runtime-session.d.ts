import type { AcpClient, AcpEventHandlers, RequestPermissionRequest, RequestPermissionResponse } from './acp-client.js';
import type { ArcConversationMirror, ArcInputState, ArcSession } from './arc-session-port.js';
import type { StateStore, TranscriptEntry } from './state-store.js';
interface PendingPermission {
    readonly id: string;
    readonly title: string;
    readonly request: RequestPermissionRequest;
    readonly settle: (response: RequestPermissionResponse) => void;
}
interface LiveBlock {
    readonly kind: 'assistant' | 'thought';
    text: string;
}
export declare class ArcRuntimeSession implements ArcSession {
    private readonly client;
    private readonly store;
    readonly config: {
        readonly cwd: string;
        readonly location: string;
    };
    private currentId;
    private conversationId;
    private entries;
    private input;
    private active;
    private closing;
    private closePromise;
    private state;
    private error;
    private unsaved;
    private transition;
    private abortTransition;
    private readonly listeners;
    private writes;
    private promptTask;
    private promptAbort;
    private promptSent;
    private stopping;
    private permission;
    private liveAttempt;
    private readonly live;
    constructor(client: AcpClient, store: StateStore, config: {
        readonly cwd: string;
        readonly location: string;
    });
    get sessionId(): string | undefined;
    get conversation(): string | undefined;
    get running(): ArcSession['running'];
    get pendingPermission(): PendingPermission | undefined;
    get errorText(): string;
    get unsavedWarning(): string;
    get transitionText(): string;
    get uiState(): ArcInputState;
    get inputComplete(): boolean;
    get transcript(): readonly TranscriptEntry[];
    /** Transient preview is separate from the durable ACP transcript. */
    get preview(): readonly LiveBlock[];
    onChange(listener: () => void): void;
    private changed;
    setActive(active: boolean): void;
    showError(text: string): void;
    setTransition(text: string, cancel?: () => void): void;
    restoreInput(state: ArcInputState): void;
    flushInput(signal?: AbortSignal): Promise<void>;
    private persist;
    private record;
    saveDraftNow(): Promise<void>;
    exportConversationMirror(): Promise<ArcConversationMirror>;
    adoptConversation(sessionId: string, source: ArcConversationMirror): Promise<void>;
    private install;
    createSession(): Promise<boolean>;
    resumeSession(sessionId: string): Promise<boolean>;
    submit(text: string): boolean;
    private runPrompt;
    waitForIdle(): Promise<void>;
    cancel(): Promise<void>;
    private stopPrompt;
    private drainPrompt;
    replyPermission(id: string, outcome: 'allow' | 'deny'): void;
    private denyPermission;
    readonly clientHandlers: Required<AcpEventHandlers>;
    close(): Promise<void>;
    private doClose;
}
export {};

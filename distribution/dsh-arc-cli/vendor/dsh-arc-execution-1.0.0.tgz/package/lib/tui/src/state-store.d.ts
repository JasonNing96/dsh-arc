/**
 * TUI-owned state: transcript mirrors and drafts.
 *
 * Layout under the state directory, namespaced by runtime identity so a
 * demo runtime, two different dsh homes, or a future remote endpoint never
 * share session mirrors:
 *
 * ```text
 * <stateDir>/runtimes/<runtimeId>/sessions/<safeId>.json   transcript mirror
 * <stateDir>/runtimes/<runtimeId>/lock.json                exclusive lock
 * <stateDir>/runtimes/<runtimeId>/drafts/<safeId>.txt      per-session draft
 * ```
 *
 * Writes are atomic (temp file + rename) with owner-only permissions.
 * Protocol session IDs are opaque strings, never used as filesystem paths:
 * each is hashed to a safe filename while the original stays inside the
 * JSON payload. An exclusive-create lock file prevents two live writers; existing
 * locks are refused, including stale/partially-written locks, to avoid races.
 *
 * @module personal-dsh-tui/state-store
 */
/** One transcript entry as rendered by the UI. */
export interface TranscriptEntry {
    /** Monotonic sequence within the mirror. */
    readonly seq: number;
    /** Wall-clock time the entry was recorded (ms since epoch). */
    readonly time: number;
    readonly kind: 'user' | 'assistant' | 'thought' | 'tool' | 'tool_result' | 'usage' | 'status' | 'error' | 'permission';
    /** Human-readable content already rendered from ACP updates. */
    readonly text: string;
    /** For tool entries: the protocol tool call id. */
    readonly toolCallId?: string;
    /** For tool entries: in_progress / completed / failed. */
    readonly toolStatus?: 'in_progress' | 'completed' | 'failed';
}
/** A persisted session mirror. */
export interface SessionMirror {
    readonly conversationId?: string;
    /** Protocol session ID (kept verbatim; never a filesystem path). */
    readonly sessionId: string;
    /** Absolute workspace cwd the session runs in. */
    readonly cwd: string;
    /** When the mirror was created (ms since epoch). */
    readonly createdAt: number;
    /** When the mirror was last written (ms since epoch). */
    readonly updatedAt: number;
    /** Ordered transcript entries. */
    readonly entries: TranscriptEntry[];
    /** Set once this client has observed a genuine ACP resume of the session. */
    readonly resumedAt: number | null;
    /** Set when the runtime reported the session cannot be resumed. */
    readonly unresumableReason?: string;
    /**
     * Set for sessions that existed in the runtime before this client ever
     * recorded them: history display is unavailable, not silently empty.
     */
    readonly historyUnavailable?: boolean;
}
/**
 * Storage for one runtime endpoint's TUI-owned state.
 *
 * Concurrency: `open` acquires an exclusive lock with O_EXCL create. A live
 * process holding the lock is refused; a stale lock needs manual removal. All writes serialize through an in-process chain, and
 * {@link close} releases only the lock this instance created.
 */
export declare class StateStore {
    /** Runtime-namespaced root directory. */
    readonly root: string;
    private readonly lockToken;
    private writeChain;
    private lockHeld;
    private constructor();
    /** Mark this instance as the live lock holder. */
    private markLocked;
    /**
     * Open (or create) the store for one runtime identity under `stateDir`.
     * @throws when another live process holds the lock for this runtime.
     */
    static open(stateDir: string, runtimeId: string): Promise<StateStore>;
    /** Absolute root directory of this store (tests, diagnostics). */
    get directory(): string;
    /** Path of the mirror file for a protocol session ID. */
    private mirrorPath;
    /** Path of the draft file for a protocol session ID. */
    private draftPath;
    /** Load the mirror for a session, or null when this client never recorded it. */
    loadMirror(sessionId: string): Promise<SessionMirror | null>;
    /** All mirrors this client recorded, newest activity first. */
    listMirrors(): Promise<SessionMirror[]>;
    /** Create or replace a mirror wholesale (first record, external adoption). */
    writeMirror(mirror: SessionMirror): Promise<void>;
    /**
     * Append one transcript entry to a mirror, creating it on first use.
     * Resolves to the stored mirror after the append is durably on disk.
     */
    append(sessionId: string, cwd: string, entry: Omit<TranscriptEntry, 'seq' | 'time'>): Promise<SessionMirror>;
    /** Mark a mirror as genuinely resumed through ACP. */
    markResumed(sessionId: string): Promise<void>;
    /** Record that the runtime refused to resume this session. */
    markUnresumable(sessionId: string, reason: string): Promise<void>;
    /** Save the current draft for a session (empty string removes it). */
    saveDraft(sessionId: string, text: string): Promise<void>;
    /** Load the saved draft for a session ('' when none). */
    loadDraft(sessionId: string): Promise<string>;
    /**
     * Release the lock on clean shutdown. Only removes the lock this instance
     * wrote; a recovered-then-stolen lock is never removed by its old owner.
     */
    close(): Promise<void>;
    /** Test seam: whether this instance believes it holds the lock. */
    get locked(): boolean;
    private loadMirrorUnchecked;
    private enqueue;
}
/**
 * Map an opaque protocol session ID to a filesystem-safe segment.
 *
 * Injective for practical inputs (full hex sha-256); never contains path
 * separators, `..`, or NUL, so an arbitrary session ID cannot escape storage.
 */
export declare function safeSegment(sessionId: string): string;
/**
 * Write `data` to `path` atomically: a sibling temp file with owner-only
 * permissions, fsync, then rename over the target.
 */
export declare function atomicWrite(path: string, data: string): Promise<void>;

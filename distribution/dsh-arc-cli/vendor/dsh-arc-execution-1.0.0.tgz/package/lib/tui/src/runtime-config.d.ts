/**
 * Runtime launch configuration and identity.
 *
 * The TUI never spawns a shell: it starts one pinned `dsh --profile acp`
 * subprocess with an explicit argv and an explicit environment. The runtime
 * home defaults to a dedicated directory that is NOT `~/.dsh`, so the user's
 * global installation and its data stay untouched.
 *
 * @module personal-dsh-tui/runtime-config
 */
/** The pinned upstream runtime this project is developed against. */
export declare const EXPECTED_DSH_VERSION = "0.1.5-rc.1";
/** Default dedicated runtime home (DSH_HOME for the spawned runtime). */
export declare const DEFAULT_RUNTIME_HOME: string;
/** Default TUI-owned UI state directory (transcripts, drafts, session index). */
export declare const DEFAULT_STATE_DIR: string;
/** Resolved launch configuration for one TUI process. */
export interface RuntimeConfig {
    /** Opt into an installed ARC ACP profile; its runtime starts without the legacy module hook. */
    readonly arcProfile?: string;
    /** How the runtime is launched. */
    readonly mode: 'dsh' | 'demo';
    /** Absolute workspace path passed as the ACP session cwd. */
    readonly cwd: string;
    /** Absolute DSH_HOME for the runtime (dsh mode only). */
    readonly dshHome: string;
    /** Absolute directory holding TUI-owned state. */
    readonly stateDir: string;
    /** Absolute workspace default when the user passed none. */
    readonly workspace: string;
    /**
     * Explicit dsh executable to launch (dsh mode only). When omitted the TUI
     * spawns the project-local pinned `node_modules/.bin/dsh`.
     */
    readonly dshExecutable: string | undefined;
}
/** Parsed command-line options relevant to runtime configuration. */
export interface CliRuntimeOptions {
    readonly arcProfile?: string;
    readonly demo: boolean;
    readonly cwd: string | undefined;
    readonly dshHome: string | undefined;
    readonly stateDir: string | undefined;
    readonly dshExecutable: string | undefined;
}
/**
 * Resolve one launch configuration from parsed options.
 *
 * Every path is expanded (`~` allowed) and made absolute; an empty string is
 * rejected because an accidental empty `--cwd` would silently become the TUI's
 * own process directory.
 */
export declare function resolveRuntimeConfig(options: CliRuntimeOptions): RuntimeConfig;
/**
 * Stable identity for one runtime endpoint, used to namespace stored state.
 *
 * Two different runtime homes (or a demo runtime versus a real one) must never
 * share session mirrors even when the workspace is identical, so reconnecting
 * cannot mix sessions across runtimes.
 */
export declare function runtimeIdentity(config: RuntimeConfig): string;

export interface RemoteConfig {
    readonly arcProfile?: string;
    readonly host: string;
    readonly cwd: string;
    readonly dshHome: string;
    readonly node: string;
    readonly entry: string;
    /** Host paths for container execution through SSH; ACP paths stay inside the container. */
    readonly docker?: {
        readonly image: string;
        readonly workspace: string;
        readonly dataDir: string;
        readonly user: string;
        readonly envFile?: string;
    };
}
export declare function parseRemoteConfig(value: unknown): RemoteConfig;
export declare function loadRemoteConfig(path: string, optional?: boolean): Promise<RemoteConfig | undefined>;
export declare function remoteIdentity(remote: RemoteConfig): string;
/** SSH invokes a remote shell; quote every variable as one literal shell word. */
export declare function shellQuote(value: string): string;
export declare function remoteSshArgs(remote: RemoteConfig): string[];

/** Versioned portable context: model messages, never files, policies or pending work. */
import { Session } from '@deepseek-ai/dsh-session';
import { type Message } from '@deepseek-ai/dsh-llm';
export interface Checkpoint {
    version: 1;
    sourceCwd: string;
    messages: Message[];
}
export declare const MAX_CHECKPOINT_BYTES: number;
export declare function validateCheckpoint(value: unknown): Checkpoint;
/** Keep the current model-visible surface, including existing compaction/recall. */
export declare function exportCheckpoint(session: Session): Checkpoint;
/** Build a balanced native seed. No inbox input or tool execution is replayed. */
export declare function checkpointSeed(value: unknown, cwd: string): readonly import("@deepseek-ai/dsh-session").SessionEvent[];

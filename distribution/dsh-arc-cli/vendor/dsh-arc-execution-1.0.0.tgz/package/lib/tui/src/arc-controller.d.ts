/** One conversation handed between independent runtimes at idle checkpoints. */
import { AcpClient, type AcpEventHandlers } from './acp-client.js';
import { type RuntimeConfig } from './runtime-config.js';
import { type RemoteConfig } from './remote-config.js';
import { StateStore } from './state-store.js';
import type { ArcSession } from './arc-session-port.js';
export type Location = 'local' | 'remote';
export type Connector = (location: Location, id: string, handlers: AcpEventHandlers, signal: AbortSignal) => Promise<AcpClient>;
/** Session factory has no terminal, input-byte or rendering dependency. */
export type SessionFactory<V extends ArcSession> = (client: AcpClient, store: StateStore, options: {
    cwd: string;
    mode: 'dsh' | 'demo';
    location: string;
    remote: boolean;
    onSwitch: () => void;
    onReconnect: () => void;
}) => V;
export declare class ArcController<V extends ArcSession> {
    private readonly config;
    private readonly remote;
    private readonly sessionFactory;
    private readonly connector?;
    private readonly endpoints;
    private location;
    private transition;
    private controller;
    private closing;
    private closePromise;
    private starting;
    private readonly retiredClients;
    private readonly retiredStores;
    constructor(config: RuntimeConfig, remote: RemoteConfig | undefined, sessionFactory: SessionFactory<V>, connector?: Connector | undefined);
    get currentLocation(): Location;
    get activeUi(): V | undefined;
    get switching(): boolean;
    get activeSession(): V | undefined;
    cancelTransition(): void;
    private indexStore;
    private head;
    private headChain;
    private headError;
    private readonly changeHooks;
    onChange(hook: () => void): () => void;
    get connected(): boolean;
    get model(): string;
    get home(): Location;
    private changed;
    private persistHead;
    start(fresh?: boolean): Promise<void>;
    private doStart;
    /** Ctrl+R switches; Ctrl+G reconnects this endpoint after transport loss. */
    switchRuntime(reconnect?: boolean): Promise<boolean>;
    private performSwitch;
    /** Failed cleanup remains owned and is attempted again during shutdown. */
    private releaseResources;
    private connect;
    close(): Promise<void>;
    private doClose;
}

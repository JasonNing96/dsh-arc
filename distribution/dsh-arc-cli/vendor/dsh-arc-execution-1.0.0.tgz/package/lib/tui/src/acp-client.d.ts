/**
 * ACP client for one runtime endpoint.
 *
 * Owns the runtime subprocess, the JSON-RPC connection, and per-session
 * bookkeeping. Session updates and permission requests are surfaced through
 * callbacks; protocol failures are mapped to typed {@link AcpError}s that
 * keep the wire `data` payload (DSH puts actionable details in `data.details`,
 * e.g. quota errors from the model provider).
 *
 * @module personal-dsh-tui/acp-client
 */
import type { Checkpoint } from './handoff.js';
import type { AssistantStreamFrame } from '@deepseek-ai/dsh-agent';
import { type RemoteConfig } from './remote-config.js';
import { type Stream } from '@agentclientprotocol/sdk';
import type { PromptResponse, RequestPermissionRequest, RequestPermissionResponse, SessionNotification } from '@agentclientprotocol/sdk';
export type { PromptResponse, RequestPermissionRequest, RequestPermissionResponse };
/** A protocol- or lifecycle-level failure with a user-presentable message. */
export declare class AcpError extends Error {
    /** Protocol error code when the failure came from a JSON-RPC error. */
    readonly code: number | undefined;
    /** Structured `data` payload from the wire, if any. */
    readonly data: unknown;
    constructor(message: string, 
    /** Protocol error code when the failure came from a JSON-RPC error. */
    code: number | undefined, 
    /** Structured `data` payload from the wire, if any. */
    data?: unknown);
}
/** One entry of a `session/list` result. */
export interface SessionListEntry {
    readonly sessionId: string;
    readonly cwd: string;
    readonly title: string | null;
    readonly updatedAt: string | null;
}
/** Runtime events the UI needs to render beyond prompt completion. */
export interface AcpEventHandlers {
    onStream?: (sessionId: string, frame: AssistantStreamFrame) => void;
    /** Called for every `session/update` notification. */
    onUpdate: (sessionId: string, update: SessionNotification['update']) => void;
    /**
     * Called when the runtime asks for a permission decision. The returned
     * settle function must eventually be called with an explicit user choice;
     * there is no automatic approval. Call it with `cancelled` to deny.
     */
    onRequestPermission: (sessionId: string, request: RequestPermissionRequest, settle: (response: RequestPermissionResponse) => void) => void;
    /** Called at most once when the connection drops or the process dies. */
    onDisconnect: (reason: string) => void;
}
/** Connection state used for status display. */
export type ConnectionState = 'starting' | 'ready' | 'disconnected';
/**
 * A connected ACP client owning one runtime subprocess.
 *
 * Lifecycle: spawn, initialize, then create the user's session. Only the
 * known provider-registration startup race is retried, for at most 2 seconds.
 */
export declare class AcpClient {
    /** Identity of the runtime endpoint, for state namespacing. */
    readonly runtimeId: string;
    private readonly handlers;
    private connection;
    private child;
    private state;
    private readonly pendingPermissions;
    private stderrTail;
    private disposed;
    private disconnectEmitted;
    private nextPermissionKey;
    private readonly sessionModels;
    private constructor();
    /**
     * Spawn the pinned dsh runtime in ACP mode and initialize.
     *
     * The subprocess argv is fully explicit — no shell interpolation. Its
     * `DSH_HOME` points at the dedicated runtime home so the global `~/.dsh`
     * stays untouched. The workspace `cwd` becomes both the process cwd (DSH's
     * sandbox policy derives `workspaceRoot` from `process.cwd()`) and the
     * default ACP session cwd.
     */
    static connect(runtimeId: string, executable: string, dshHome: string, cwd: string, handlers: AcpEventHandlers, signal?: AbortSignal, arcProfile?: string): Promise<AcpClient>;
    /**
     * Spawn the bundled demo runtime as a subprocess and initialize. No
     * credentials, no network, no model: clearly labeled demo.
     */
    static connectDemo(runtimeId: string, cwd: string, handlers: AcpEventHandlers): Promise<AcpClient>;
    /** SSH owns this ACP connection. Reconnection creates a new runtime process. */
    static connectRemote(runtimeId: string, remote: RemoteConfig, handlers: AcpEventHandlers, signal?: AbortSignal): Promise<AcpClient>;
    /** Common subprocess wiring for the real and demo runtimes. */
    private static spawnRuntime;
    /**
     * Create a client over an already-established stream (tests). Runs
     * `initialize` over that stream.
     */
    static connectStream(runtimeId: string, stream: Stream, handlers: AcpEventHandlers): Promise<AcpClient>;
    private attach;
    private handleDisconnect;
    private wireProcessEvents;
    private initialize;
    /** Current connection state for status display. */
    get connectionState(): ConnectionState;
    /** Whether a live connection exists. */
    get connected(): boolean;
    private requireConnection;
    /** Create a new session in the runtime at `cwd`. */
    private adapterVersion;
    private arcPluginVersion;
    private requireArcPlugin;
    exportCheckpoint(sessionId: string): Promise<Checkpoint>;
    newSession(cwd?: string, checkpoint?: Checkpoint): Promise<string>;
    /**
     * Resume a persisted session. The runtime verifies the workspace matches
     * the session's canonical cwd; a mismatch is a caller-visible error.
     */
    resumeSession(sessionId: string, cwd: string): Promise<void>;
    /** List persisted, resumable sessions; optionally filtered by workspace. */
    listSessions(cwd?: string): Promise<SessionListEntry[]>;
    /**
     * Send one prompt. Resolves with the turn's stop reason after committed
     * updates drain. One prompt at a time per session is the runtime's
     * contract; the UI enforces it.
     */
    prompt(sessionId: string, text: string, cancellationSignal?: AbortSignal): Promise<PromptResponse>;
    /**
     * Cancel the in-flight prompt (or autonomous work) of a session. A no-op
     * when nothing is running.
     */
    cancel(sessionId: string): Promise<void>;
    /** Explicitly close a session; the runtime persists it for later resume. */
    closeSession(sessionId: string): Promise<void>;
    modelFor(sessionId: string | undefined): string;
    private rememberModel;
    private launchCwd;
    /** Workspace cwd the subprocess was launched in. */
    get workspaceCwd(): string;
    private guard;
    /**
     * Tear down: close the connection, deny pending permissions, and stop the
     * subprocess within a bounded window. Safe to call more than once.
     */
    private disposal;
    dispose(): Promise<void>;
    private doDispose;
}
/** Convert any thrown value into an {@link AcpError} with a readable message. */
export declare function toAcpError(error: unknown, what: string): AcpError;
/** Human-safe rendering of an unknown thrown value. */
export declare function errorText(error: unknown): string;
/** Temporary directory helper for tests. */
export declare function makeTempDir(prefix: string): Promise<string>;
/** Recursive removal that never throws for a missing path. */
export declare function removeDir(path: string): Promise<void>;
